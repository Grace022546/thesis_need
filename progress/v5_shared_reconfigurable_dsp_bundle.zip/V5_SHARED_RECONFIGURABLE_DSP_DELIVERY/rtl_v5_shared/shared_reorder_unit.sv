`timescale 1ns/1ps
import cgra_rtl_pkg::*;

// One shared registered permutation/pack unit for FFT, MM, FIR and QR.
module shared_reorder_unit #(
  parameter int P_VECTOR_W=VECTOR_W,
  parameter int P_N_PE=N_PE
)(
  input logic clk_i,input logic rst_ni,
  input logic in_valid_i,output logic in_ready_o,
  input logic [2:0] mode_i,
  input logic [P_N_PE*P_VECTOR_W-1:0] in_vectors_i,
  output logic out_valid_o,input logic out_ready_i,
  output logic [1:0][P_VECTOR_W-1:0] out_vectors_o
);
  logic valid_q; logic [1:0][P_VECTOR_W-1:0] data_q;
  assign in_ready_o=!valid_q || out_ready_i;
  assign out_valid_o=valid_q; assign out_vectors_o=data_q;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if(!rst_ni) begin valid_q<=1'b0; data_q<='0; end
    else begin
      if(valid_q && out_ready_i) valid_q<=1'b0;
      if(in_valid_i && in_ready_o) begin
        valid_q<=1'b1; data_q<='0;
        case(mode_i)
          3'd0: begin // scalar pack: lane p from PE p lane0
            for(int p=0;p<P_N_PE;p++) data_q[0][p*LANE_W +: LANE_W] <= in_vectors_i[p*P_VECTOR_W +: LANE_W];
          end
          3'd1: begin // FFT: PE p lanes0:1 -> vec0, lanes2:3 -> vec1
            for(int p=0;p<P_N_PE;p++) begin
              data_q[0][(2*p+0)*LANE_W +: LANE_W] <= in_vectors_i[p*P_VECTOR_W + 0*LANE_W +: LANE_W];
              data_q[0][(2*p+1)*LANE_W +: LANE_W] <= in_vectors_i[p*P_VECTOR_W + 1*LANE_W +: LANE_W];
              data_q[1][(2*p+0)*LANE_W +: LANE_W] <= in_vectors_i[p*P_VECTOR_W + 2*LANE_W +: LANE_W];
              data_q[1][(2*p+1)*LANE_W +: LANE_W] <= in_vectors_i[p*P_VECTOR_W + 3*LANE_W +: LANE_W];
            end
          end
          default: begin data_q[0]<=in_vectors_i[0 +: P_VECTOR_W]; data_q[1]<=in_vectors_i[P_VECTOR_W +: P_VECTOR_W]; end
        endcase
      end
    end
  end
endmodule
