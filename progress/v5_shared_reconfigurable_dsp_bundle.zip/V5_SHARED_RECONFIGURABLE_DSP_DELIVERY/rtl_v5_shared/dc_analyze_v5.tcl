# Synopsys DC syntax/elaboration check for V5 single-cluster architecture.
set TOP_MODULE single_cluster_integration_top
set FILELIST [file normalize ./v5_single_cluster.f]
set fp [open $FILELIST r]
set rtl_files {}
while {[gets $fp line] >= 0} {
  set line [string trim $line]
  if {$line eq "" || [string match "#*" $line]} { continue }
  lappend rtl_files [file normalize $line]
}
close $fp
foreach f $rtl_files {
  puts "ANALYZE $f"
  analyze -format sverilog $f
}
elaborate $TOP_MODULE
current_design $TOP_MODULE
link
check_design > ./v5_check_design.rpt
report_reference > ./v5_report_reference.rpt
puts "V5_ANALYZE_ELABORATE_DONE"
