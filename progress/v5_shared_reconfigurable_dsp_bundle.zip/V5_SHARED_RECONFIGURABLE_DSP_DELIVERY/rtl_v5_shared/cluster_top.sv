`timescale 1ns/1ps
import cgra_rtl_pkg::*;
module cluster_top #(
  parameter int CLUSTER_ID = 0,
  parameter int XBAR_FIFO_DEPTH = 1,
  // Current headline FFT/MM/FIR/QR mappings do not issue DIR_PE_RING or
  // CORDIC-to-PE broadcast traffic.  Set to 0 for the workload-frozen area
  // build; unsupported local-forwarding instructions fault explicitly.
  parameter bit ENABLE_LOCAL_XBAR = 1'b1
) (
  input  logic clk_i,
  input  logic rst_ni,

  // Program/configuration ports.
  input  logic                  imem_wr_en_i,
  input  logic [PC_W-1:0]       imem_wr_addr_i,
  input  logic [63:0]           imem_wr_data_i,
  input  logic                  ctx_wr_en_i,
  input  logic [CTX_ADDR_W-1:0] ctx_wr_addr_i,
  input  logic [CTX_W-1:0]      ctx_wr_data_i,
  input  logic                  start_i,
  input  logic [PC_W:0]         program_words_i,

  output logic                  done_o,
  output logic                  active_o,
  output logic                  fault_o,
  output logic [7:0]            fault_code_o,

  // Global barrier interface.
  output logic                  barrier_req_o,
  output logic [15:0]           barrier_token_o,
  input  logic                  barrier_release_i,

  // Direct DMA request to the SMU/DMA engine.
  output logic                  dma_req_valid_o,
  input  logic                  dma_req_ready_i,
  output logic [CLUSTER_ID_W-1:0] dma_src_cluster_o,
  output logic [CLUSTER_ID_W-1:0] dma_dst_cluster_o,
  output logic [LOCAL_ADDR_W-1:0] dma_src_local_o,
  output logic [LOCAL_ADDR_W-1:0] dma_dst_local_o,
  output logic [7:0]            dma_len_vec_o,
  output logic [1:0]            dma_requester_pe_o,
  output logic [2:0]            dma_tag_o,
  input  logic                  dma_idle_i,

  // Shared local SRAM Port-A client used by explicit QR pivot preload.
  output logic                  qr_mem_req_valid_o,
  input  logic                  qr_mem_req_ready_i,
  output logic                  qr_mem_req_write_o,
  output logic [LOCAL_ADDR_W-1:0] qr_mem_req_addr_o,
  input  logic                  qr_mem_rsp_valid_i,
  input  logic [VECTOR_W-1:0]   qr_mem_rsp_data_i,

  // PE issue and completion interface. Arithmetic cores are intentionally
  // separate modules so Python/RTL cycle equivalence can be established per PE.
  output logic                  pe_issue_valid_o,
  input  logic                  pe_issue_ready_i,
  output logic [35:0]           pe_slots_o,
  output logic [PARAM_ID_W-1:0] pe_param_id_o,
  output logic [2:0]            pe_legacy_ctx_id_o,
  output logic [EXEC_IMM_W-1:0] pe_immediate_o,
  output logic [CTX_W-1:0]      pe_context_o,
  output logic                  pe_param_valid_o,
  output logic [VECTOR_W-1:0]   pe_param_vector_o,
  output logic [PARAM_TAG_W-1:0] pe_param_tag_o,
  // Narrow FIR-only address generator controls; the generic AGU is absent.
  output logic                  fir_agu_active_o,
  output logic [7:0]            fir_k_group_o,
  output logic [7:0]            fir_k_group_limit_o,
  output logic [N_PE*LANES-1:0] fir_x_valid_o,
  output logic [N_PE*LANES*FIR_INDEX_W-1:0] fir_x_index_o,
  output logic [LANES-1:0]      fir_h_valid_o,
  output logic [LANES*FIR_TAPS_W-1:0] fir_h_index_o,
  output logic [N_PE*FIR_SAMPLES_W-1:0] fir_sample_index_o,
  input  logic [N_PE-1:0]       pe_busy_i,
  input  logic                  ru_busy_i,

  // QR target landing buffer populated from accepted WBQ->SRAM commits in
  // the integration wrapper: vectors [0:1]=R, [2:3]=Q^T.
  input  logic [QR_TARGET_INPUT_VECS-1:0] qr_target_valid_i,
  input  logic [QR_TARGET_INPUT_VECS*VECTOR_W-1:0] qr_target_vectors_i,
  output logic                  qr_target_reset_o,
  output logic                  qr_pe_pairs_valid_o,
  input  logic                  qr_pe_pairs_ready_i,
  output logic [N_PE*VECTOR_W-1:0] qr_pe_pairs_o,
  output logic                  cordic_qr_pair_valid_o,
  output logic signed [LANE_W-1:0] cordic_qr_pivot_o,
  output logic signed [LANE_W-1:0] cordic_qr_target_o,

  // Local CORDIC interface. mode_twiddle=1 uses j/m rotation mode; 0 uses the
  // ordinary vectoring/one-pass control encoded by context/immediate.
  output logic                  cordic_req_valid_o,
  input  logic                  cordic_req_ready_i,
  output logic                  cordic_mode_twiddle_o,
  output logic [15:0]           cordic_twiddle_j_o,
  output logic [3:0]            cordic_twiddle_m_log2_o,
  output logic [PARAM_ID_W-1:0] cordic_param_id_o,
  output logic [EXEC_IMM_W-1:0] cordic_immediate_o,
  output logic [CTX_W-1:0]      cordic_context_o,
  input  logic                  cordic_rsp_valid_i,
  input  logic [VECTOR_W-1:0]   cordic_rsp_vector_i,
  input  logic signed [LANE_W-1:0] cordic_rsp_cos_i,
  input  logic signed [LANE_W-1:0] cordic_rsp_sin_i,
  input  logic                  cordic_idle_i,

  // Additional parameter producer, e.g. PARAM_LOAD from landed SRAM.
  input  logic                  ext_param_wr_valid_i,
  output logic                  ext_param_wr_ready_o,
  input  param_write_op_e       ext_param_wr_op_i,
  input  logic [PARAM_ID_W-1:0] ext_param_wr_pid_i,
  input  logic [VECTOR_W-1:0]   ext_param_wr_data_i,
  input  logic [LANE_W-1:0]     ext_param_wr_pair_c_i,
  input  logic [LANE_W-1:0]     ext_param_wr_pair_s_i,
  input  logic [PARAM_TAG_W-1:0] ext_param_wr_tag_i,

  // Local PE/CORDIC forwarding fabric.
  input  logic [N_PE-1:0]       pe_result_valid_i,
  output logic [N_PE-1:0]       pe_result_ready_o,
  input  logic [N_PE*VECTOR_W-1:0] pe_result_data_i,
  input  logic [N_PE*PARAM_ID_W-1:0] pe_result_pid_i,

  // PE results whose context downstream is MEM/WRITEBACK.  The external
  // SMU/WBQ consumes these with the original issue immediate retained per PE.
  output logic [N_PE-1:0]       pe_writeback_valid_o,
  input  logic [N_PE-1:0]       pe_writeback_ready_i,
  output logic [N_PE*VECTOR_W-1:0] pe_writeback_data_o,
  output logic [N_PE*PARAM_ID_W-1:0] pe_writeback_pid_o,
  output logic [N_PE*EXEC_IMM_W-1:0] pe_writeback_immediate_o,

  input  logic                  cordic_broadcast_valid_i,
  output logic                  cordic_broadcast_ready_o,
  input  logic [VECTOR_W-1:0]   cordic_broadcast_data_i,
  input  logic [PARAM_ID_W-1:0] cordic_broadcast_pid_i,
  output logic [N_PE-1:0]       xbar_dst_valid_o,
  input  logic [N_PE-1:0]       xbar_dst_pop_i,
  output logic [N_PE*VECTOR_W-1:0] xbar_dst_data_o,

  // Storage-free QR controller connections.
  output logic shared_qr_preload_start_o,
  output logic [QR_ROT_W-1:0] shared_qr_rotation_o,
  output logic [QR_ROW_W-1:0] shared_qr_pivot_row_o,
  input logic shared_qr_preload_ready_i,shared_qr_preload_busy_i,shared_qr_preload_valid_i,
  input logic [QR_ROT_W-1:0] shared_qr_preload_rotation_i,
  output logic shared_qr_pair_req_o,output logic [QR_ROW_W-1:0] shared_qr_column_o,
  output logic shared_qr_crot_req_o,shared_qr_crot_entity_qt_o,shared_qr_crot_ready_o,
  input logic shared_qr_crot_rows_valid_i,
  input logic [N_PE*VECTOR_W-1:0] shared_qr_crot_pivot_rows_i,shared_qr_crot_target_rows_i,
  input logic shared_qr_cordic_pair_valid_i,
  input logic signed [LANE_W-1:0] shared_qr_cordic_pivot_i,shared_qr_cordic_target_i,

  // Shared physical resource client ports.
  input shared_stage_role_e stage_role_i,
  input logic fft_svrf_wr_valid_i,output logic fft_svrf_wr_ready_o,
  input logic [PARAM_ID_W-1:0] fft_svrf_wr_pid_i,input logic [VECTOR_W-1:0] fft_svrf_wr_data_i,
  input logic fft_svrf_rd_valid_i,input logic [PARAM_ID_W-1:0] fft_svrf_rd_pid_i,
  output logic fft_svrf_rd_ready_o,output logic [VECTOR_W-1:0] fft_svrf_rd_data_o,
  output logic fft_svrf_rd_data_valid_o,
  input logic [N_PE-1:0] fft_stage_wr_valid_i,input logic [N_PE-1:0] fft_stage_wr_entry_i,
  input logic [N_PE-1:0][VECTOR_W-1:0] fft_stage_wr_data_i,output logic [N_PE-1:0] fft_stage_wr_ready_o,
  input logic [N_PE-1:0] mm_stage_wr_valid_i,input logic [N_PE-1:0] mm_stage_wr_entry_i,
  input logic [N_PE-1:0][VECTOR_W-1:0] mm_stage_wr_data_i,output logic [N_PE-1:0] mm_stage_wr_ready_o,
  input logic [N_PE-1:0] qr_stage_wr_valid_i,input logic [N_PE-1:0] qr_stage_wr_entry_i,
  input logic [N_PE-1:0][VECTOR_W-1:0] qr_stage_wr_data_i,output logic [N_PE-1:0] qr_stage_wr_ready_o,
  input logic [N_PE-1:0] ext_stage_wr_valid_i,input logic [N_PE-1:0] ext_stage_wr_entry_i,
  input logic [N_PE-1:0][VECTOR_W-1:0] ext_stage_wr_data_i,output logic [N_PE-1:0] ext_stage_wr_ready_o,
  input logic [N_PE-1:0] stage_rd_valid_i,input logic [N_PE-1:0] stage_rd_entry_i,
  input logic [N_PE-1:0] stage_rd_consume_i,output logic [N_PE-1:0] stage_rd_ready_o,
  output logic [N_PE-1:0] stage_rd_data_valid_o,output logic [N_PE-1:0][VECTOR_W-1:0] stage_rd_data_o,
  output logic [N_PE-1:0][1:0] stage_peek_valid_o,
  output logic [N_PE-1:0][1:0][VECTOR_W-1:0] stage_peek_data_o,
  input logic stage_invalidate_all_i,output logic stage_empty_o,
  input logic shared_ru_in_valid_i,output logic shared_ru_in_ready_o,input logic [2:0] shared_ru_mode_i,
  input logic [N_PE*VECTOR_W-1:0] shared_ru_in_vectors_i,
  output logic shared_ru_out_valid_o,input logic shared_ru_out_ready_i,
  output logic [1:0][VECTOR_W-1:0] shared_ru_out_vectors_o
);
  logic [PARAM_ID_W-1:0] svrf_rd_pid_o;
  logic svrf_rd_expected_tag_valid_o;
  logic [PARAM_TAG_W-1:0] svrf_rd_expected_tag_o;
  logic svrf_rd_ready_i;
  logic [VECTOR_W-1:0] svrf_rd_data_i;
  logic [PARAM_TAG_W-1:0] svrf_rd_tag_i;
  logic svrf_rd_valid_i;
  logic svrf_wr_valid_o,svrf_wr_ready_i;
  param_write_op_e svrf_wr_op_o;
  logic [PARAM_ID_W-1:0] svrf_wr_pid_o;
  logic [VECTOR_W-1:0] svrf_wr_data_o;
  logic [LANE_W-1:0] svrf_wr_c_o,svrf_wr_s_o;
  logic [1:0] svrf_wr_pair_slot_o;
  logic [PARAM_TAG_W-1:0] svrf_wr_tag_o;

  cluster_control #(.CLUSTER_ID(CLUSTER_ID),.XBAR_FIFO_DEPTH(XBAR_FIFO_DEPTH),.ENABLE_LOCAL_XBAR(ENABLE_LOCAL_XBAR)) u_control (.*);

  cluster_shared_resources u_resources (
    .clk_i(clk_i),.rst_ni(rst_ni),.stage_role_i(stage_role_i),
    .svrf_rd_pid_i(svrf_rd_pid_o),.svrf_rd_expected_tag_valid_i(svrf_rd_expected_tag_valid_o),
    .svrf_rd_expected_tag_i(svrf_rd_expected_tag_o),.svrf_rd_ready_o(svrf_rd_ready_i),
    .svrf_rd_data_o(svrf_rd_data_i),.svrf_rd_tag_o(svrf_rd_tag_i),.svrf_rd_valid_o(svrf_rd_valid_i),
    .fft_rd_valid_i(fft_svrf_rd_valid_i),.fft_rd_pid_i(fft_svrf_rd_pid_i),
    .fft_rd_ready_o(fft_svrf_rd_ready_o),.fft_rd_data_o(fft_svrf_rd_data_o),
    .fft_rd_data_valid_o(fft_svrf_rd_data_valid_o),
    .ctrl_wr_valid_i(svrf_wr_valid_o),.ctrl_wr_ready_o(svrf_wr_ready_i),.ctrl_wr_op_i(svrf_wr_op_o),
    .ctrl_wr_pid_i(svrf_wr_pid_o),.ctrl_wr_data_i(svrf_wr_data_o),.ctrl_wr_c_i(svrf_wr_c_o),
    .ctrl_wr_s_i(svrf_wr_s_o),.ctrl_wr_pair_slot_i(svrf_wr_pair_slot_o),.ctrl_wr_tag_i(svrf_wr_tag_o),
    .fft_wr_valid_i(fft_svrf_wr_valid_i),.fft_wr_ready_o(fft_svrf_wr_ready_o),
    .fft_wr_pid_i(fft_svrf_wr_pid_i),.fft_wr_data_i(fft_svrf_wr_data_i),
    .ext_wr_valid_i(1'b0),.ext_wr_ready_o(),.ext_wr_op_i(PRF_WRITE_NONE),.ext_wr_pid_i('0),
    .ext_wr_data_i('0),.ext_wr_c_i('0),.ext_wr_s_i('0),.ext_wr_tag_i('0),
    .fft_stage_wr_valid_i(fft_stage_wr_valid_i),.fft_stage_wr_entry_i(fft_stage_wr_entry_i),
    .fft_stage_wr_data_i(fft_stage_wr_data_i),.fft_stage_wr_ready_o(fft_stage_wr_ready_o),
    .mm_stage_wr_valid_i(mm_stage_wr_valid_i),.mm_stage_wr_entry_i(mm_stage_wr_entry_i),
    .mm_stage_wr_data_i(mm_stage_wr_data_i),.mm_stage_wr_ready_o(mm_stage_wr_ready_o),
    .qr_stage_wr_valid_i(qr_stage_wr_valid_i),.qr_stage_wr_entry_i(qr_stage_wr_entry_i),
    .qr_stage_wr_data_i(qr_stage_wr_data_i),.qr_stage_wr_ready_o(qr_stage_wr_ready_o),
    .ext_stage_wr_valid_i(ext_stage_wr_valid_i),.ext_stage_wr_entry_i(ext_stage_wr_entry_i),
    .ext_stage_wr_data_i(ext_stage_wr_data_i),.ext_stage_wr_ready_o(ext_stage_wr_ready_o),
    .stage_rd_valid_i(stage_rd_valid_i),.stage_rd_entry_i(stage_rd_entry_i),
    .stage_rd_consume_i(stage_rd_consume_i),.stage_rd_ready_o(stage_rd_ready_o),
    .stage_rd_data_valid_o(stage_rd_data_valid_o),.stage_rd_data_o(stage_rd_data_o),
    .stage_peek_valid_o(stage_peek_valid_o),.stage_peek_data_o(stage_peek_data_o),
    .stage_invalidate_all_i(stage_invalidate_all_i),.stage_empty_o(stage_empty_o),
    .ru_in_valid_i(shared_ru_in_valid_i),.ru_in_ready_o(shared_ru_in_ready_o),.ru_mode_i(shared_ru_mode_i),
    .ru_in_vectors_i(shared_ru_in_vectors_i),.ru_out_valid_o(shared_ru_out_valid_o),
    .ru_out_ready_i(shared_ru_out_ready_i),.ru_out_vectors_o(shared_ru_out_vectors_o));
endmodule : cluster_top
