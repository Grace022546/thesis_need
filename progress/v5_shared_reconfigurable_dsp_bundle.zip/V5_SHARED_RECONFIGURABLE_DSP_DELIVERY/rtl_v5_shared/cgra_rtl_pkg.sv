`timescale 1ns/1ps
package cgra_rtl_pkg;
  // V5 architecture-purity freeze: one shared vector RF and one shared
  // transient operand staging structure per cluster. No MM-only operand RAM
  // and no FFT-only twiddle expansion multiplier.
  parameter bit ARCH_HAS_MM_OPERAND_BUFFER = 1'b0;
  parameter bit ARCH_HAS_FFT_TEU = 1'b0;
  parameter bit ARCH_HAS_SHARED_VECTOR_RF = 1'b1;
  parameter bit ARCH_HAS_SHARED_OPERAND_STAGING = 1'b1;
  parameter int N_CLUSTERS = 16;
  parameter int GRID_ROWS = 4;
  parameter int GRID_COLS = 4;
  parameter int N_PE = 4;
  parameter int LANES = 8;
  parameter int LANE_W = 32;
  parameter int VECTOR_W = LANES * LANE_W;
  parameter int VECTOR_BYTES = VECTOR_W / 8;

  parameter int PC_W = 11;
  parameter int IMEM_DEPTH = 1 << PC_W;
  parameter int CTX_ADDR_W = 5;
  parameter int CTX_DEPTH = 1 << CTX_ADDR_W;
  parameter int CTX_W = 94;
  parameter int EXEC_IMM_W = 39;
  parameter int FRONTEND_Q_DEPTH = 8;
  parameter int LOOP_COUNT = 4;

  parameter int PARAM_ENTRIES = 16;
  parameter int SHARED_VECTOR_RF_ENTRIES = PARAM_ENTRIES;
  parameter int SHARED_OPERAND_BANKS = 4;
  parameter int SHARED_OPERAND_ENTRIES_PER_BANK = 2;
  typedef enum logic [2:0] {
    STAGE_ROLE_GENERIC   = 3'd0,
    STAGE_ROLE_FFT_INPUT = 3'd1,
    STAGE_ROLE_MM_B      = 3'd2,
    STAGE_ROLE_FIR_X     = 3'd3,
    STAGE_ROLE_QR_ROWS   = 3'd4
  } shared_stage_role_e;
  parameter int PARAM_ID_W = 4;
  parameter int PARAM_TAG_W = 8;
  // ParamRF and local-forwarding payloads carry signed Q1.15 values in
  // 32-bit architectural lane containers.  Production storage keeps only the
  // significant 16 bits and sign-extends at the module boundary.
  parameter int PARAM_VALUE_W = 16;
  parameter int LOCAL_XBAR_VALUE_W = 16;

  parameter int LOCAL_BANKS = 4;
  parameter int LOCAL_BANK_W = 2;
  parameter int LOCAL_ADDR_W = 15;
  parameter int CLUSTER_ID_W = 4;
  parameter int GLOBAL_ADDR_W = CLUSTER_ID_W + LOCAL_ADDR_W;

  parameter int FIR_TAPS_W = 9;
  parameter int FIR_SAMPLES_W = 10;
  parameter int FIR_BATCH_W = 10;
  parameter int FIR_INDEX_W = 10;

  parameter int QR_ROW_W = 4;
  parameter int QR_ROT_W = 8;
  parameter int QR_ROW_VECS = 2;
  parameter int QR_R_BASE_VEC = 0;
  parameter int QR_QT_BASE_VEC = 2;
  // Latest QR mapping gives each logical row a unique 8-vector local slot.
  parameter int QR_ROW_SLOT_STRIDE_VECS = 8;
  // Four-vector landing buffer used by the final QR mapping:
  //   [0:1] target R, [2:3] target Q^T.
  parameter int QR_TARGET_INPUT_BASE_VEC = 248;
  parameter int QR_TARGET_INPUT_VECS = 4;
  parameter int QR_RU_INTERLEAVE_STAGES = 1;

  // V4: 16-entry ParamRF is logically split into two 8-entry ping-pong banks.
  parameter int SHARED_VECTOR_RF_BANKS = 2;
  parameter int PARAM_RF_BANKS = SHARED_VECTOR_RF_BANKS;
  parameter int SHARED_VECTOR_RF_ENTRIES_PER_BANK = 8;
  parameter int PARAM_RF_ENTRIES_PER_BANK = SHARED_VECTOR_RF_ENTRIES_PER_BANK;
  parameter int CORDIC_ITER = 18;

  typedef enum logic [5:0] {
    ISA_NOP             = 6'h00,
    ISA_RESERVED_01     = 6'h01,
    ISA_CFG_LOOP        = 6'h02,
    ISA_EXEC_CONTEXT    = 6'h10,
    ISA_EXEC_CORDIC     = 6'h11,
    ISA_RESERVED_12     = 6'h12,
    ISA_EXEC_SYNC       = 6'h13,
    ISA_EXEC_DMA_DIRECT = 6'h14,
    ISA_HALT            = 6'h3f
  } isa_opcode_e;

  typedef enum logic [1:0] {
    SYNC_NONE                 = 2'd0,
    SYNC_WAIT_DMA_DONE        = 2'd1,
    SYNC_WAIT_LOCAL_QUIESCENT = 2'd2,
    SYNC_GLOBAL_BARRIER       = 2'd3
  } sync_flag_e;

  typedef enum logic [2:0] {
    PE_NOP     = 3'd0,
    PE_PASS    = 3'd1,
    PE_MAC     = 3'd2,
    PE_CMUL    = 3'd3,
    PE_ADD     = 3'd4,
    PE_CVEC_RSVD = 3'd5,
    PE_CROT    = 3'd6,
    PE_RU_PACK = 3'd7
  } pe_op_e;

  typedef enum logic [2:0] {
    DIR_MEM        = 3'd0,
    DIR_PE_LOCAL   = 3'd1,
    DIR_PE_RING    = 3'd2,
    DIR_PARAM_RF   = 3'd3,
    DIR_SCALE      = 3'd4,
    DIR_RESERVED   = 3'd5,
    DIR_ACC        = 3'd6,
    DIR_OPERAND_RF = 3'd7 // deprecated encoding: MM A aliases SharedVectorRF
  } pe_dir_e;

  typedef enum logic [4:0] {
    M_NONE                 = 5'd0,
    M_FFT_LOAD             = 5'd1,
    M_FFT_BFLY             = 5'd2,
    M_FFT_PACK             = 5'd3,
    M_FIR_X_WINDOW         = 5'd4,
    M_QR_LOAD              = 5'd5,
    M_QR_CORDIC            = 5'd6,
    M_QR_CROT              = 5'd7,
    M_QR_PACK              = 5'd8,
    M_FFT_PARAM_LOAD       = 5'd9,
    M_FIR_AGU_START        = 5'd10,
    M_FIR_H_VECTOR         = 5'd11,
    M_FFT_SCATTER          = 5'd12,
    M_QR_WRITEBACK         = 5'd13,
    M_FIR_MAC              = 5'd14,
    M_FIR_REDUCE           = 5'd15,
    M_FIR_PACK             = 5'd16,
    M_MM_A_LOAD            = 5'd17,
    M_MM_A_LATCH           = 5'd18,
    M_MM_B_LOAD            = 5'd19,
    M_MM_MAC               = 5'd20,
    M_MM_REDUCE            = 5'd21,
    M_MM_PACK              = 5'd22,
    M_RESERVED_23          = 5'd23,
    M_FFT_TWIDDLE_FILL     = 5'd24, // deprecated centralized twiddle-fill encoding; illegal in V4
    M_FFT_OPT_CACHE_SEED   = 5'd25,
    M_FFT_OPT_CACHE_STEP   = 5'd26,
    M_FFT_OPT_FUSED_BFLY   = 5'd27,
    M_FFT_OPT_GROUP_COMMIT = 5'd28,
    M_QR_TOKEN_ACQUIRE     = 5'd29,
    M_QR_TOKEN_ROTATE      = 5'd30,
    M_QR_TOKEN_FLUSH       = 5'd31
  } micro_kind_e;

  typedef enum logic [2:0] {
    DEP_NONE   = 3'd0,
    DEP_RAW    = 3'd1,
    DEP_WAW    = 3'd2,
    DEP_PARAM  = 3'd3,
    DEP_LAYOUT = 3'd4
  } dependency_e;

  typedef enum logic [2:0] {
    PRF_WRITE_NONE        = 3'd0,
    PRF_WRITE_VECTOR      = 3'd1,
    PRF_RESERVE_TAG       = 3'd2,
    PRF_WRITE_TAGGED_PAIR = 3'd3,
    PRF_INVALIDATE        = 3'd4,
    PRF_WRITE_PAIR_SLOT   = 3'd5
  } param_write_op_e;

  localparam logic [3:0] MICRO_FLAG_RESET_INPUT      = 4'b0001;
  localparam logic [3:0] MICRO_FLAG_QR_PIVOT_PRELOAD = 4'b0010;
  // Workload-local interpretations of the same four context flag bits.
  localparam logic [3:0] MICRO_FLAG_MM_PINGPONG = 4'b0010;
  localparam logic [3:0] MICRO_FLAG_MM_BUFFER1 = 4'b0100;
  localparam logic [3:0] MICRO_FLAG_MM_B_RESIDENT = 4'b1000;

  // Context RAM bit positions exactly match ContextRAMEntry.encode() in Python.
  localparam int CTX_PE0_LSB = 0;
  localparam int CTX_PE1_LSB = 9;
  localparam int CTX_PE2_LSB = 18;
  localparam int CTX_PE3_LSB = 27;
  localparam int CTX_PARAM_LSB = 36;
  localparam int CTX_CORDIC_EN_BIT = 40;
  localparam int CTX_CORDIC_PARAM_LSB = 41;
  localparam int CTX_CORDIC_SRC_LSB = 45;
  localparam int CTX_CORDIC_DST_LSB = 47;
  localparam int CTX_LEGACY_CTX_LSB = 49;
  localparam int CTX_KIND_LSB = 52;
  localparam int CTX_DEP_LSB = 57;
  localparam int CTX_FLAGS_LSB = 60;
  localparam int CTX_ROUND_LSB = 64;
  localparam int CTX_SAT_BIT = 66;
  localparam int CTX_ACC_BIT = 67;
  localparam int CTX_RSVD_AGU_LSB = 68;
  localparam int CTX_DMA_SRC_LSB = 71;
  localparam int CTX_DMA_DST_LSB = 75;
  localparam int CTX_DMA_LEN_LSB = 79;
  localparam int CTX_DMA_REQPE_LSB = 87;
  localparam int CTX_DMA_TAG_LSB = 89;
  localparam int CTX_IS_DMA_BIT = 93;

  function automatic logic [8:0] ctx_pe_slot(
      input logic [CTX_W-1:0] ctx,
      input int unsigned pe_id
  );
    ctx_pe_slot = ctx[pe_id*9 +: 9];
  endfunction

  function automatic logic pe_slot_active(input logic [8:0] slot);
    pe_slot_active = (slot[8:6] != PE_NOP);
  endfunction

  function automatic logic [LOCAL_BANK_W-1:0] local_bank(input logic [LOCAL_ADDR_W-1:0] byte_addr);
    local_bank = byte_addr[6:5]; // 32-byte vectors interleaved over four banks.
  endfunction

  function automatic logic [LOCAL_ADDR_W-1:0] vector_byte_addr(input int unsigned vec_idx);
    vector_byte_addr = LOCAL_ADDR_W'(vec_idx * VECTOR_BYTES);
  endfunction
endpackage
