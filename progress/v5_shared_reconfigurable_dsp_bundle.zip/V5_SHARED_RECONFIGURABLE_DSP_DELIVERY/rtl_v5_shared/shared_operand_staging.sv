`timescale 1ns/1ps
import cgra_rtl_pkg::*;

// One compact 4-bank x 2-entry transient operand store shared by FFT/MM/FIR/QR.
// Each bank has one independent write/read port, matching the four PE-owned
// SRAM banks without creating a 4R4W monolithic RF.
module shared_operand_staging #(
  parameter int P_BANKS=SHARED_OPERAND_BANKS,
  parameter int P_ENTRIES=SHARED_OPERAND_ENTRIES_PER_BANK,
  parameter int P_VECTOR_W=VECTOR_W,
  parameter int P_VALUE_W=PARAM_VALUE_W
)(
  input logic clk_i,input logic rst_ni,input shared_stage_role_e role_i,
  input logic [P_BANKS-1:0] wr_valid_i,
  output logic [P_BANKS-1:0] wr_ready_o,
  input logic [P_BANKS-1:0][$clog2(P_ENTRIES)-1:0] wr_entry_i,
  input logic [P_BANKS-1:0][P_VECTOR_W-1:0] wr_data_i,
  input logic [P_BANKS-1:0] wr_invalidate_i,
  input logic [P_BANKS-1:0] rd_valid_i,
  output logic [P_BANKS-1:0] rd_ready_o,
  input logic [P_BANKS-1:0][$clog2(P_ENTRIES)-1:0] rd_entry_i,
  input logic [P_BANKS-1:0] rd_consume_i,
  output logic [P_BANKS-1:0] rd_data_valid_o,
  output logic [P_BANKS-1:0][P_VECTOR_W-1:0] rd_data_o,
  output logic [P_BANKS-1:0][P_ENTRIES-1:0] peek_valid_o,
  output logic [P_BANKS-1:0][P_ENTRIES-1:0][P_VECTOR_W-1:0] peek_data_o,
  input logic invalidate_all_i,output logic empty_o
);
  localparam int P_LANES=P_VECTOR_W/LANE_W;
  localparam int P_COMPACT_W=P_LANES*P_VALUE_W;
  logic [P_COMPACT_W-1:0] data_q[P_BANKS][P_ENTRIES];
  logic valid_q[P_BANKS][P_ENTRIES];
  function automatic logic [P_COMPACT_W-1:0] compact(input logic [P_VECTOR_W-1:0] v);
    logic [P_COMPACT_W-1:0] r;
    for(int l=0;l<P_LANES;l++) r[l*P_VALUE_W +:P_VALUE_W]=v[l*LANE_W +:P_VALUE_W];
    return r;
  endfunction
  function automatic logic [P_VECTOR_W-1:0] expand(input logic [P_COMPACT_W-1:0] v);
    logic [P_VECTOR_W-1:0] r; logic signed [P_VALUE_W-1:0] x; r='0;
    for(int l=0;l<P_LANES;l++) begin x=v[l*P_VALUE_W +:P_VALUE_W]; r[l*LANE_W +:LANE_W]={{(LANE_W-P_VALUE_W){x[P_VALUE_W-1]}},x}; end
    return r;
  endfunction
  always_comb begin
    wr_ready_o='1; rd_ready_o='1; rd_data_valid_o='0; rd_data_o='0;peek_valid_o='0;peek_data_o='0; empty_o=1'b1;
    for(int b=0;b<P_BANKS;b++) begin
      rd_data_valid_o[b]=rd_valid_i[b]&&valid_q[b][rd_entry_i[b]];
      rd_data_o[b]=expand(data_q[b][rd_entry_i[b]]);
      for(int e=0;e<P_ENTRIES;e++) begin
        empty_o&=!valid_q[b][e];
        peek_valid_o[b][e]=valid_q[b][e];
        peek_data_o[b][e]=expand(data_q[b][e]);
      end
    end
  end
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if(!rst_ni) for(int b=0;b<P_BANKS;b++) for(int e=0;e<P_ENTRIES;e++) begin data_q[b][e]<='0;valid_q[b][e]<=1'b0;end
    else begin
      if(invalidate_all_i) for(int b=0;b<P_BANKS;b++) for(int e=0;e<P_ENTRIES;e++) valid_q[b][e]<=1'b0;
      for(int b=0;b<P_BANKS;b++) begin
        if(wr_valid_i[b]&&wr_ready_o[b]) begin
          if(wr_invalidate_i[b]) valid_q[b][wr_entry_i[b]]<=1'b0;
          else begin data_q[b][wr_entry_i[b]]<=compact(wr_data_i[b]);valid_q[b][wr_entry_i[b]]<=1'b1;end
        end
        if(rd_valid_i[b]&&rd_ready_o[b]&&rd_consume_i[b]) valid_q[b][rd_entry_i[b]]<=1'b0;
      end
    end
  end
  logic unused_role;assign unused_role=^role_i;
endmodule
