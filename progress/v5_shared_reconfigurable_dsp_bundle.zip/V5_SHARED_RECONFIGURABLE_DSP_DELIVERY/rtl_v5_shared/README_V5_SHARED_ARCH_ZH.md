# V5 Shared-Resource Reconfigurable DSP RTL

## 架構凍結

- 單一 Shared Vector RF：16 entries，供 FFT twiddle、QR rotation parameter、MM A、FIR coefficient/scale 共用。
- 單一 Shared Operand Staging：4 banks × 2 entries，供 FFT input、MM B、FIR X、QR pivot/target及一般PE SRAM response共用。
- 單一 Shared Reorder Unit：負責FFT pack與其他scalar/vector重排。
- FFT TEU完全移除。W1/W2/W3由既有PE CMUL以兩個17-cycle recurrence waves產生，寫入Shared Vector RF，再由butterfly讀回。
- MM operand buffer完全移除。MM A存Shared Vector RF；MM B保留在local SRAM，只在使用前prefetch進Shared Operand Staging。
- QR private pivot/target arrays移除，controller只保留address/FSM。

## FFT recurrence

```
wave 0 (existing PE0/PE1 CMUL, mul-only):
  PE0: W1 = W0 × S
  PE1: S2 = S × S

wave 1:
  PE0: W2 = W0 × S2
  PE1: W3 = W1 × S2

SharedVectorRF[pid] = {W0,W1,W2,W3}
DMA input fill可與上述recurrence並行
butterfly開始前從SharedVectorRF讀回twiddle vector
```

## 面積方向

舊版重複raw vector payload約：MM buffer 15,360 bits＋generic MEM 1,024＋QR pivot 1,024＋QR target 1,024＋FFT input 1,024 = 19,456 bits/cluster。
新版Shared Operand Staging只有1,024 data bits，因此raw vector-register payload約減少18,432 bits/cluster；16 clusters約294,912 bits（36 KiB）。此估算不含valid/control/mux，也不含刪除TEU兩顆complex multipliers的額外面積節省。

## 合成

在此資料夾執行相對路徑filelist：

```
TOP_MODULE=single_cluster_integration_top
FILELIST=v5_single_cluster.f
```

`rtl_structural_check.py`只做括號、module/endmodule與本地named-port契約檢查；交付環境沒有Verilator/Icarus/Yosys，因此仍需在Synopsys DC前先跑正式SystemVerilog analyze/elaborate。
