`timescale 1ns/1ps
import cgra_rtl_pkg::*;

// Physical shared-storage/reorder island. Workload controllers are control-only
// clients; no controller owns a duplicate vector array.
module cluster_shared_resources #(
  parameter int P_VECTOR_W=VECTOR_W
)(
  input logic clk_i,input logic rst_ni,
  input shared_stage_role_e stage_role_i,

  // One physical SharedVectorRF read port.  The autonomous PE bundle and the
  // FFT stream controller are mutually exclusive in the integration wrapper;
  // this mux is therefore arbitration, not a duplicated read array.
  input logic [PARAM_ID_W-1:0] svrf_rd_pid_i,
  input logic svrf_rd_expected_tag_valid_i,
  input logic [PARAM_TAG_W-1:0] svrf_rd_expected_tag_i,
  output logic svrf_rd_ready_o,output logic [P_VECTOR_W-1:0] svrf_rd_data_o,
  output logic [PARAM_TAG_W-1:0] svrf_rd_tag_o,output logic svrf_rd_valid_o,
  input logic fft_rd_valid_i,input logic [PARAM_ID_W-1:0] fft_rd_pid_i,
  output logic fft_rd_ready_o,output logic [P_VECTOR_W-1:0] fft_rd_data_o,
  output logic fft_rd_data_valid_o,

  // Three producers: CORDIC/control, FFT recurrence, external/config.
  input logic ctrl_wr_valid_i,output logic ctrl_wr_ready_o,input param_write_op_e ctrl_wr_op_i,
  input logic [PARAM_ID_W-1:0] ctrl_wr_pid_i,input logic [P_VECTOR_W-1:0] ctrl_wr_data_i,
  input logic [LANE_W-1:0] ctrl_wr_c_i,ctrl_wr_s_i,input logic [1:0] ctrl_wr_pair_slot_i,
  input logic [PARAM_TAG_W-1:0] ctrl_wr_tag_i,
  input logic fft_wr_valid_i,output logic fft_wr_ready_o,input logic [PARAM_ID_W-1:0] fft_wr_pid_i,
  input logic [P_VECTOR_W-1:0] fft_wr_data_i,
  input logic ext_wr_valid_i,output logic ext_wr_ready_o,input param_write_op_e ext_wr_op_i,
  input logic [PARAM_ID_W-1:0] ext_wr_pid_i,input logic [P_VECTOR_W-1:0] ext_wr_data_i,
  input logic [LANE_W-1:0] ext_wr_c_i,ext_wr_s_i,input logic [PARAM_TAG_W-1:0] ext_wr_tag_i,

  // Staging write clients, one possible writer per bank selected by role.
  input logic [N_PE-1:0] fft_stage_wr_valid_i,input logic [N_PE-1:0] fft_stage_wr_entry_i,
  input logic [N_PE-1:0][P_VECTOR_W-1:0] fft_stage_wr_data_i,output logic [N_PE-1:0] fft_stage_wr_ready_o,
  input logic [N_PE-1:0] mm_stage_wr_valid_i,input logic [N_PE-1:0] mm_stage_wr_entry_i,
  input logic [N_PE-1:0][P_VECTOR_W-1:0] mm_stage_wr_data_i,output logic [N_PE-1:0] mm_stage_wr_ready_o,
  input logic [N_PE-1:0] qr_stage_wr_valid_i,input logic [N_PE-1:0] qr_stage_wr_entry_i,
  input logic [N_PE-1:0][P_VECTOR_W-1:0] qr_stage_wr_data_i,output logic [N_PE-1:0] qr_stage_wr_ready_o,
  input logic [N_PE-1:0] ext_stage_wr_valid_i,input logic [N_PE-1:0] ext_stage_wr_entry_i,
  input logic [N_PE-1:0][P_VECTOR_W-1:0] ext_stage_wr_data_i,output logic [N_PE-1:0] ext_stage_wr_ready_o,

  input logic [N_PE-1:0] stage_rd_valid_i,input logic [N_PE-1:0] stage_rd_entry_i,
  input logic [N_PE-1:0] stage_rd_consume_i,output logic [N_PE-1:0] stage_rd_ready_o,
  output logic [N_PE-1:0] stage_rd_data_valid_o,
  output logic [N_PE-1:0][P_VECTOR_W-1:0] stage_rd_data_o,
  output logic [N_PE-1:0][1:0] stage_peek_valid_o,
  output logic [N_PE-1:0][1:0][P_VECTOR_W-1:0] stage_peek_data_o,
  input logic stage_invalidate_all_i,output logic stage_empty_o,

  // Shared reorder/pack.
  input logic ru_in_valid_i,output logic ru_in_ready_o,input logic [2:0] ru_mode_i,
  input logic [N_PE*P_VECTOR_W-1:0] ru_in_vectors_i,
  output logic ru_out_valid_o,input logic ru_out_ready_i,
  output logic [1:0][P_VECTOR_W-1:0] ru_out_vectors_o
);
  logic rf_wr_valid,rf_wr_ready;param_write_op_e rf_wr_op;
  logic [PARAM_ID_W-1:0] rf_wr_pid;logic [P_VECTOR_W-1:0] rf_wr_data;
  logic [LANE_W-1:0] rf_wr_c,rf_wr_s;logic [1:0] rf_wr_slot;logic [PARAM_TAG_W-1:0] rf_wr_tag;
  always_comb begin
    rf_wr_valid=1'b0;rf_wr_op=PRF_WRITE_NONE;rf_wr_pid='0;rf_wr_data='0;rf_wr_c='0;rf_wr_s='0;rf_wr_slot='0;rf_wr_tag='0;
    ctrl_wr_ready_o=1'b0;fft_wr_ready_o=1'b0;ext_wr_ready_o=1'b0;
    if(ctrl_wr_valid_i) begin rf_wr_valid=1'b1;rf_wr_op=ctrl_wr_op_i;rf_wr_pid=ctrl_wr_pid_i;rf_wr_data=ctrl_wr_data_i;rf_wr_c=ctrl_wr_c_i;rf_wr_s=ctrl_wr_s_i;rf_wr_slot=ctrl_wr_pair_slot_i;rf_wr_tag=ctrl_wr_tag_i;ctrl_wr_ready_o=rf_wr_ready;end
    else if(fft_wr_valid_i) begin rf_wr_valid=1'b1;rf_wr_op=PRF_WRITE_VECTOR;rf_wr_pid=fft_wr_pid_i;rf_wr_data=fft_wr_data_i;fft_wr_ready_o=rf_wr_ready;end
    else if(ext_wr_valid_i) begin rf_wr_valid=1'b1;rf_wr_op=ext_wr_op_i;rf_wr_pid=ext_wr_pid_i;rf_wr_data=ext_wr_data_i;rf_wr_c=ext_wr_c_i;rf_wr_s=ext_wr_s_i;rf_wr_tag=ext_wr_tag_i;ext_wr_ready_o=rf_wr_ready;end
  end
  logic [PARAM_ID_W-1:0] physical_rd_pid;
  logic physical_rd_ready, physical_rd_valid;
  logic [P_VECTOR_W-1:0] physical_rd_data;
  logic [PARAM_TAG_W-1:0] physical_rd_tag;
  always_comb begin
    physical_rd_pid = fft_rd_valid_i ? fft_rd_pid_i : svrf_rd_pid_i;
    svrf_rd_ready_o = !fft_rd_valid_i && physical_rd_ready;
    svrf_rd_data_o = physical_rd_data;
    svrf_rd_tag_o = physical_rd_tag;
    svrf_rd_valid_o = !fft_rd_valid_i && physical_rd_valid;
    fft_rd_ready_o = fft_rd_valid_i && physical_rd_ready;
    fft_rd_data_o = physical_rd_data;
    fft_rd_data_valid_o = fft_rd_valid_i && physical_rd_valid;
  end
  shared_vector_rf u_svrf(
    .clk_i(clk_i),.rst_ni(rst_ni),.rd_pid_i(physical_rd_pid),
    .rd_expected_tag_valid_i(fft_rd_valid_i ? 1'b0 : svrf_rd_expected_tag_valid_i),
    .rd_expected_tag_i(svrf_rd_expected_tag_i),
    .rd_ready_o(physical_rd_ready),.rd_data_o(physical_rd_data),.rd_tag_o(physical_rd_tag),.rd_valid_o(physical_rd_valid),
    .wr_valid_i(rf_wr_valid),.wr_ready_o(rf_wr_ready),.wr_op_i(rf_wr_op),.wr_pid_i(rf_wr_pid),.wr_data_i(rf_wr_data),
    .wr_pair_c_i(rf_wr_c),.wr_pair_s_i(rf_wr_s),.wr_pair_slot_i(rf_wr_slot),.wr_tag_i(rf_wr_tag),.invalidate_clear_tag_i(1'b1));

  logic [N_PE-1:0] st_wr_valid,st_wr_ready,st_wr_entry,st_wr_inval;
  logic [N_PE-1:0][P_VECTOR_W-1:0] st_wr_data;
  always_comb begin
    st_wr_valid='0;st_wr_entry='0;st_wr_data='0;st_wr_inval='0;
    fft_stage_wr_ready_o='0;mm_stage_wr_ready_o='0;qr_stage_wr_ready_o='0;ext_stage_wr_ready_o='0;
    case(stage_role_i)
      STAGE_ROLE_FFT_INPUT: begin st_wr_valid=fft_stage_wr_valid_i;st_wr_entry=fft_stage_wr_entry_i;st_wr_data=fft_stage_wr_data_i;fft_stage_wr_ready_o=st_wr_ready;end
      STAGE_ROLE_MM_B: begin st_wr_valid=mm_stage_wr_valid_i;st_wr_entry=mm_stage_wr_entry_i;st_wr_data=mm_stage_wr_data_i;mm_stage_wr_ready_o=st_wr_ready;end
      STAGE_ROLE_QR_ROWS: begin st_wr_valid=qr_stage_wr_valid_i;st_wr_entry=qr_stage_wr_entry_i;st_wr_data=qr_stage_wr_data_i;qr_stage_wr_ready_o=st_wr_ready;end
      default: begin st_wr_valid=ext_stage_wr_valid_i;st_wr_entry=ext_stage_wr_entry_i;st_wr_data=ext_stage_wr_data_i;ext_stage_wr_ready_o=st_wr_ready;end
    endcase
  end
  shared_operand_staging u_stage(
    .clk_i(clk_i),.rst_ni(rst_ni),.role_i(stage_role_i),.wr_valid_i(st_wr_valid),.wr_ready_o(st_wr_ready),
    .wr_entry_i(st_wr_entry),.wr_data_i(st_wr_data),.wr_invalidate_i(st_wr_inval),
    .rd_valid_i(stage_rd_valid_i),.rd_ready_o(stage_rd_ready_o),.rd_entry_i(stage_rd_entry_i),
    .rd_consume_i(stage_rd_consume_i),.rd_data_valid_o(stage_rd_data_valid_o),.rd_data_o(stage_rd_data_o),
    .peek_valid_o(stage_peek_valid_o),.peek_data_o(stage_peek_data_o),
    .invalidate_all_i(stage_invalidate_all_i),.empty_o(stage_empty_o));

  shared_reorder_unit u_ru(.clk_i(clk_i),.rst_ni(rst_ni),.in_valid_i(ru_in_valid_i),.in_ready_o(ru_in_ready_o),
    .mode_i(ru_mode_i),.in_vectors_i(ru_in_vectors_i),.out_valid_o(ru_out_valid_o),.out_ready_i(ru_out_ready_i),.out_vectors_o(ru_out_vectors_o));
endmodule
