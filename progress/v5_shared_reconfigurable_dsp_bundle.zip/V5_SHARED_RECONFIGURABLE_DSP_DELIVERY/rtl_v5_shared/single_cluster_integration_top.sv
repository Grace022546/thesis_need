`timescale 1ns/1ps

// =============================================================================
// single_cluster_integration_top.sv
//
// One physical cluster synthesis/integration boundary:
//   * 1 x cluster_top control/issue hierarchy
//   * 4 x pe Q1.15 arithmetic cores
//   * 1 x registered iterative CORDIC (QR two-pass / FFT seed generation)
//   * 1 x shared-resource FFT controller; twiddle recurrence reuses existing PE CMULs
//   * 1 x sv_smu_sched_top local SRAM / WBQ / NoC scheduler
//
// Important contract boundaries:
//   * The same registered CORDIC performs 36-cycle QR two-pass and 18-cycle
//     FFT twiddle rotation-only operations. No dedicated twiddle block or separate parameter memory exists.
//   * Workload-specific memory address generation is not encoded uniformly in
//     pe_immediate_o. PE writeback addresses are consequently explicit wrapper
//     inputs (pe_writeback_addr_i), rather than guessed from immediate bits.
//   * SMU PE request tag 4'hF on port 0 is reserved for QR pivot preload.
// =============================================================================

module single_cluster_integration_top #(
  parameter int CLUSTER_ID = 0,
  parameter int XBAR_FIFO_DEPTH = 1,
  // Workload-frozen production default.  Override to 1 only for legacy
  // DIR_PE_RING/CORDIC broadcast contexts.
  parameter bit ENABLE_LOCAL_XBAR = 1'b0
) (
  input  logic clk_i,
  input  logic rst_ni,

  // --------------------------------------------------------------------------
  // Instruction/context programming and kernel control
  // --------------------------------------------------------------------------
  input  logic                         imem_wr_en_i,
  input  logic [cgra_rtl_pkg::PC_W-1:0] imem_wr_addr_i,
  input  logic [63:0]                  imem_wr_data_i,
  input  logic                         ctx_wr_en_i,
  input  logic [cgra_rtl_pkg::CTX_ADDR_W-1:0] ctx_wr_addr_i,
  input  logic [cgra_rtl_pkg::CTX_W-1:0] ctx_wr_data_i,
  input  logic                         start_i,
  input  logic [cgra_rtl_pkg::PC_W:0] program_words_i,

  output logic                         done_o,
  output logic                         active_o,
  output logic                         fault_o,
  output logic [7:0]                   fault_code_o,

  output logic                         barrier_req_o,
  output logic [15:0]                  barrier_token_o,
  input  logic                         barrier_release_i,

  // --------------------------------------------------------------------------
  // Direct DMA command boundary. A complete multi-cluster DMA controller / NoC
  // remains outside this single-cluster wrapper.
  // --------------------------------------------------------------------------
  output logic                         dma_req_valid_o,
  input  logic                         dma_req_ready_i,
  output logic [cgra_rtl_pkg::CLUSTER_ID_W-1:0] dma_src_cluster_o,
  output logic [cgra_rtl_pkg::CLUSTER_ID_W-1:0] dma_dst_cluster_o,
  output logic [cgra_rtl_pkg::LOCAL_ADDR_W-1:0] dma_src_local_o,
  output logic [cgra_rtl_pkg::LOCAL_ADDR_W-1:0] dma_dst_local_o,
  output logic [7:0]                   dma_len_vec_o,
  output logic [1:0]                   dma_requester_pe_o,
  output logic [2:0]                   dma_tag_o,
  input  logic                         dma_idle_i,

  // --------------------------------------------------------------------------
  // V5 block-distributed FFT stream ingress; no TEU.
  // --------------------------------------------------------------------------
  input  logic                         fft_stream_enable_i,
  input  logic                         fft_task_valid_i,
  output logic                         fft_task_ready_o,
  output logic                         fft_task_slot_o,
  input  logic [cgra_rtl_pkg::PARAM_ID_W-1:0] fft_task_param_pid_i,
  input  logic signed [15:0]           fft_task_seed_re_i,
  input  logic signed [15:0]           fft_task_seed_im_i,
  input  logic signed [15:0]           fft_task_step_re_i,
  input  logic signed [15:0]           fft_task_step_im_i,
  input  logic [cgra_rtl_pkg::LOCAL_ADDR_W-1:0] fft_task_dst0_addr_i,
  input  logic [cgra_rtl_pkg::LOCAL_ADDR_W-1:0] fft_task_dst1_addr_i,
  input  logic                         fft_input_fill_valid_i,
  output logic                         fft_input_fill_ready_o,
  input  logic                         fft_input_fill_slot_i,
  input  logic                         fft_input_fill_vector_i,
  input  logic [cgra_rtl_pkg::VECTOR_W-1:0] fft_input_fill_data_i,
  input  logic                         fft_stage_close_i,
  output logic                         fft_stage_done_o,
  output logic                         fft_stream_busy_o,

  // --------------------------------------------------------------------------
  // Workload operand boundary for sources not yet backed by a dedicated RTL RF.
  // Each 256-bit vector contains eight signed 32-bit containers; PE consumes
  // the low signed 16 bits of each lane as Q1.15.
  // --------------------------------------------------------------------------
  input  logic [cgra_rtl_pkg::N_PE*cgra_rtl_pkg::VECTOR_W-1:0] pe_operand_i,
  input  logic [cgra_rtl_pkg::N_PE*cgra_rtl_pkg::VECTOR_W-1:0] pe_twiddle_i,
  // PE CMUL second operand V.  Two signed Q1.15 components per PE replace
  // the former full 256-bit auxiliary vector and model-only latency override.
  input  logic [cgra_rtl_pkg::N_PE*2*16-1:0] pe_cmul_v_i,

  // Explicit local SRAM destination for each PE MEM/WRITEBACK result.
  input  logic [cgra_rtl_pkg::N_PE*cgra_rtl_pkg::LOCAL_ADDR_W-1:0] pe_writeback_addr_i,

  // QR target rows are no longer external operands.  They are mirrored from
  // every accepted architectural write to the landing addresses: WBQ/Port-A
  // commits for DMA/direct transitions and accepted Port-B writes for initial
  // configuration or explicit local writes.

  // Optional external ParamRF producer.
  input  logic                         ext_param_wr_valid_i,
  output logic                         ext_param_wr_ready_o,
  input  cgra_rtl_pkg::param_write_op_e ext_param_wr_op_i,
  input  logic [cgra_rtl_pkg::PARAM_ID_W-1:0] ext_param_wr_pid_i,
  input  logic [cgra_rtl_pkg::VECTOR_W-1:0] ext_param_wr_data_i,
  input  logic [cgra_rtl_pkg::LANE_W-1:0] ext_param_wr_pair_c_i,
  input  logic [cgra_rtl_pkg::LANE_W-1:0] ext_param_wr_pair_s_i,
  input  logic [cgra_rtl_pkg::PARAM_TAG_W-1:0] ext_param_wr_tag_i,

  // --------------------------------------------------------------------------
  // External local-memory requests sharing the four SMU PE ports.
  // Priority per port: FFT result drain (port0) > cluster PE writeback > internal MM B prefetch > external.
  // Read tag 4'hE is reserved for internal MM B-stationary prefetch.
  // QR pivot preload uses the independent SMU Port-A service interface.
  // --------------------------------------------------------------------------
  input  logic [cgra_rtl_pkg::N_PE-1:0] ext_pe_mem_req_valid_i,
  output logic [cgra_rtl_pkg::N_PE-1:0] ext_pe_mem_req_ready_o,
  input  logic [cgra_rtl_pkg::N_PE-1:0][1:0] ext_pe_mem_req_type_i,
  input  logic [cgra_rtl_pkg::N_PE-1:0] ext_pe_mem_req_is_vec_i,
  input  logic [cgra_rtl_pkg::N_PE-1:0][cgra_rtl_pkg::LOCAL_ADDR_W-1:0] ext_pe_mem_req_addr_i,
  input  logic [cgra_rtl_pkg::N_PE-1:0][cgra_rtl_pkg::VECTOR_W-1:0] ext_pe_mem_req_data_i,
  input  logic [cgra_rtl_pkg::N_PE-1:0][3:0] ext_pe_mem_req_wstrb_i,
  input  logic [cgra_rtl_pkg::N_PE-1:0][3:0] ext_pe_mem_req_tag_i,

  output logic [cgra_rtl_pkg::N_PE-1:0] smu_pe_rsp_valid_o,
  output logic [cgra_rtl_pkg::N_PE-1:0] smu_pe_rsp_kind_o,
  output logic [cgra_rtl_pkg::N_PE-1:0] smu_pe_rsp_err_o,
  output logic [cgra_rtl_pkg::N_PE-1:0][cgra_rtl_pkg::VECTOR_W-1:0] smu_pe_rsp_data_o,
  output logic [cgra_rtl_pkg::N_PE-1:0][3:0] smu_pe_rsp_tag_o,

  // --------------------------------------------------------------------------
  // SMU DMA/WBQ compatibility and formal producer interfaces
  // --------------------------------------------------------------------------
  input  logic                         dma_wb_valid_i,
  input  logic [cgra_rtl_pkg::LOCAL_ADDR_W-1:0] dma_wb_addr_i,
  input  logic [cgra_rtl_pkg::VECTOR_W-1:0] dma_wb_data_i,

  input  logic                         wbq_enq_valid_i,
  output logic                         wbq_enq_ready_o,
  input  logic [1:0]                   wbq_enq_bank_idx_i,
  input  logic [7:0]                   wbq_enq_line_addr_i,
  input  logic [cgra_rtl_pkg::VECTOR_W-1:0] wbq_enq_data_i,
  input  logic [3:0]                   wbq_enq_tag_i,
  input  logic                         wbq_enq_completion_credit_i,

  input  logic                         dma_local_dst_active_i,
  input  logic [cgra_rtl_pkg::LOCAL_ADDR_W-1:0] dma_local_dst_start_i,
  input  logic [cgra_rtl_pkg::LOCAL_ADDR_W-1:0] dma_local_dst_end_i,
  input  logic                         dma_issue_active_i,
  input  logic                         dma_issue_error_i,
  input  logic [cgra_rtl_pkg::GLOBAL_ADDR_W-1:0] dma_issue_dst_base_i,
  input  logic [3:0]                   dma_issue_tag_candidate_i,

  // --------------------------------------------------------------------------
  // SMU / NoC receive and transmit boundaries
  // --------------------------------------------------------------------------
  input  logic                         revb_noc_rx_valid_i,
  output logic                         revb_noc_rx_ready_o,
  input  logic [1:0]                   revb_noc_rx_opcode_i,
  input  logic [cgra_rtl_pkg::GLOBAL_ADDR_W-1:0] revb_noc_rx_addr_i,
  input  logic [cgra_rtl_pkg::VECTOR_W-1:0] revb_noc_rx_data_i,
  input  logic [3:0]                   revb_noc_rx_tag_i,
  input  logic [3:0]                   revb_noc_rx_requester_i,
  input  logic                         revb_noc_rx_path_i,

  input  logic                         revb_noc_rx_read_req_valid_i,
  output logic                         revb_noc_rx_read_req_ready_o,
  input  logic [cgra_rtl_pkg::GLOBAL_ADDR_W-1:0] revb_noc_rx_read_req_addr_i,
  input  logic [3:0]                   revb_noc_rx_read_req_tag_i,
  input  logic [3:0]                   revb_noc_rx_read_req_requester_i,
  input  logic                         revb_noc_rx_read_req_path_i,

  output logic                         revb_noc_tx_read_rsp_valid_o,
  input  logic                         revb_noc_tx_read_rsp_ready_i,
  output logic [1:0]                   revb_noc_tx_read_rsp_opcode_o,
  output logic [cgra_rtl_pkg::VECTOR_W-1:0] revb_noc_tx_read_rsp_data_o,
  output logic [3:0]                   revb_noc_tx_read_rsp_tag_o,
  output logic [3:0]                   revb_noc_tx_read_rsp_requester_o,
  output logic                         revb_noc_tx_read_rsp_path_o,

  input  logic                         remote_rd_enq_valid_i,
  output logic                         remote_rd_enq_ready_o,
  input  logic [1:0]                   remote_rd_enq_bank_idx_i,
  input  logic [7:0]                   remote_rd_enq_line_addr_i,
  input  logic [3:0]                   remote_rd_enq_tag_i,
  input  logic [3:0]                   remote_rd_enq_requester_i,
  input  logic                         remote_rd_enq_path_i,

  output logic                         remote_rd_rsp_valid_o,
  input  logic                         remote_rd_rsp_ready_i,
  output logic [cgra_rtl_pkg::VECTOR_W-1:0] remote_rd_rsp_data_o,
  output logic [3:0]                   remote_rd_rsp_tag_o,
  output logic [3:0]                   remote_rd_rsp_requester_o,
  output logic                         remote_rd_rsp_path_o
);

  import cgra_rtl_pkg::*;


  logic [N_PE-1:0] pe_busy;
  logic [N_PE*VECTOR_W-1:0] pe_result_data;
  logic cordic_busy, cordic_done;
  logic signed [15:0] cordic_r, cordic_c, cordic_s;

  // --------------------------------------------------------------------------
  // cluster_top interface wires
  // --------------------------------------------------------------------------
  logic                  qr_mem_req_valid;
  logic                  qr_mem_req_ready;
  logic                  qr_mem_req_write;
  logic [LOCAL_ADDR_W-1:0] qr_mem_req_addr;
  logic                  qr_mem_rsp_valid;
  logic [VECTOR_W-1:0]   qr_mem_rsp_data;

  logic                  pe_issue_valid;
  logic                  pe_issue_ready;
  logic [35:0]           pe_slots;
  logic [PARAM_ID_W-1:0] pe_param_id;
  logic [2:0]            pe_legacy_ctx_id;
  logic [EXEC_IMM_W-1:0] pe_immediate;
  logic [CTX_W-1:0]      pe_context;
  logic                  pe_param_valid;
  logic [VECTOR_W-1:0]   pe_param_vector;
  logic [PARAM_TAG_W-1:0] pe_param_tag;

  logic                  fir_agu_active;
  logic [7:0]            fir_k_group;
  logic [7:0]            fir_k_group_limit;
  logic [N_PE*LANES-1:0] fir_x_valid;
  logic [N_PE*LANES*FIR_INDEX_W-1:0] fir_x_index;
  logic [LANES-1:0]      fir_h_valid;
  logic [LANES*FIR_TAPS_W-1:0] fir_h_index;
  logic [N_PE*FIR_SAMPLES_W-1:0] fir_sample_index;

  logic                  qr_pe_pairs_valid;
  logic                  qr_pe_pairs_ready;
  logic [N_PE*VECTOR_W-1:0] qr_pe_pairs;
  logic                  qr_target_reset;
  logic [QR_TARGET_INPUT_VECS-1:0] qr_target_valid_q;
  logic [QR_TARGET_INPUT_VECS*VECTOR_W-1:0] qr_target_vectors_q;
  logic                  cordic_qr_pair_valid;
  logic signed [LANE_W-1:0] cordic_qr_pivot;
  logic signed [LANE_W-1:0] cordic_qr_target;

  logic                  cordic_req_valid;
  logic                  cordic_req_ready;
  logic                  cordic_mode_twiddle;
  logic [15:0]           cordic_twiddle_j;
  logic [3:0]            cordic_twiddle_m_log2;
  logic [PARAM_ID_W-1:0] cordic_param_id;
  logic [EXEC_IMM_W-1:0] cordic_immediate;
  logic [CTX_W-1:0]      cordic_context;
  logic                  cordic_rsp_valid;
  logic [VECTOR_W-1:0]   cordic_rsp_vector;
  logic signed [LANE_W-1:0] cordic_rsp_cos;
  logic signed [LANE_W-1:0] cordic_rsp_sin;
  logic                  cordic_idle;

  logic [N_PE-1:0]       pe_result_ready;
  logic [N_PE*PARAM_ID_W-1:0] pe_result_pid;
  logic [N_PE-1:0]       pe_writeback_valid;
  logic [N_PE-1:0]       pe_writeback_ready;
  logic [N_PE*VECTOR_W-1:0] pe_writeback_data;
  logic [N_PE*PARAM_ID_W-1:0] pe_writeback_pid;
  logic [N_PE*EXEC_IMM_W-1:0] pe_writeback_immediate;

  logic                  cordic_broadcast_valid;
  logic                  cordic_broadcast_ready;
  logic [VECTOR_W-1:0]   cordic_broadcast_data;
  logic [PARAM_ID_W-1:0] cordic_broadcast_pid;
  logic [N_PE-1:0]       xbar_dst_valid;
  logic [N_PE-1:0]       xbar_dst_pop;
  logic [N_PE*VECTOR_W-1:0] xbar_dst_data;

  // --------------------------------------------------------------------------
  // PE core wiring and result holding buffers
  // --------------------------------------------------------------------------
  logic [N_PE-1:0] pe_done;
  logic [N_PE-1:0][LANES*16-1:0] pe_reg_out_flat;
  logic [N_PE-1:0] result_valid_q;
  logic [N_PE-1:0][VECTOR_W-1:0] result_data_q;

  logic [N_PE-1:0][8:0] slot_bits;
  logic [N_PE-1:0] slot_active;
  logic [N_PE-1:0][2:0] slot_upstream;
  logic [N_PE-1:0][2:0] slot_downstream;
  logic [N_PE-1:0][2:0] slot_op;
  logic [N_PE-1:0] pe_fire;
  logic [N_PE-1:0] pe_core_ready;

  logic signed [15:0] pe_fire_din [N_PE][LANES];
  logic signed [15:0] pe_fire_tw  [N_PE][LANES];
  logic signed [15:0] pe_fire_aux [N_PE][LANES];
  logic [N_PE-1:0] pe_fire_cmul_mul_only;
  logic [N_PE-1:0] pe_fire_crot_separate_rows;

  // Ordinary PE memory responses also use the shared staging entry0.
  logic [N_PE-1:0] generic_stage_wr_valid,generic_stage_wr_ready,generic_stage_wr_entry;
  logic [N_PE-1:0][VECTOR_W-1:0] generic_stage_wr_data;

  // MM B-stationary controller; A is read from SharedVectorRF, no MM-private data array.
  logic                  mm_mac_valid;
  logic                  mm_issue_fire;
  logic                  mm_operands_ready;
  logic [VECTOR_W-1:0]   mm_a_vector;
  logic [N_PE*VECTOR_W-1:0] mm_b_vectors;
  logic [N_PE-1:0]       mm_b_req_valid;
  logic [N_PE-1:0]       mm_b_req_ready;
  logic [N_PE-1:0][LOCAL_ADDR_W-1:0] mm_b_req_addr;
  logic [N_PE-1:0][3:0]  mm_b_req_tag;

  // V5 FFT controller and unified shared-PE handshake.
  logic fft_task_ready_int,fft_input_fill_ready_int,fft_stage_done_int,fft_stream_busy_int;
  logic fft_pe_req_valid,fft_pe_req_ready,fft_pe_req_slot;
  logic [1:0] fft_pe_req_kind;
  logic [N_PE-1:0] fft_pe_req_active_mask;
  logic fft_pe_req_cmul_mul_only;
  logic [N_PE*VECTOR_W-1:0] fft_pe_req_a,fft_pe_req_b,fft_pe_req_twiddle;
  logic fft_pe_rsp_valid,fft_pe_rsp_ready,fft_pe_rsp_slot;
  logic [1:0] fft_pe_rsp_kind;
  logic [N_PE*VECTOR_W-1:0] fft_pe_rsp_data;
  logic                  fft_result_valid;
  logic                  fft_result_ready;
  logic [VECTOR_W-1:0]   fft_result_vec0;
  logic [VECTOR_W-1:0]   fft_result_vec1;
  logic [LOCAL_ADDR_W-1:0] fft_result_dst0_addr;
  logic [LOCAL_ADDR_W-1:0] fft_result_dst1_addr;
  logic                  fft_pe_launch;
  logic                  fft_pe_active_q;
  logic                  fft_pe_active_slot_q;
  logic [1:0]            fft_pe_active_kind_q;
  logic [N_PE-1:0]       fft_pe_active_mask_q;
  logic                  fft_pe_done_pending_q;
  logic                  fft_ru_pending_q;
  logic                  fft_rsp_hold_valid_q;
  logic                  fft_rsp_hold_slot_q;
  logic [1:0]            fft_rsp_hold_kind_q;
  logic [VECTOR_W-1:0]   fft_rsp_hold_vec0_q;
  logic [VECTOR_W-1:0]   fft_rsp_hold_vec1_q;
  logic [VECTOR_W-1:0]   pe_selected_din [N_PE];
  logic [VECTOR_W-1:0]   pe_selected_tw [N_PE];
  logic [VECTOR_W-1:0]   pe_selected_aux [N_PE];
  context_entry_pkg::pe_op_e pe_fire_op [N_PE];

  typedef enum logic [1:0] {
    FFT_DRAIN_IDLE, FFT_WRITE0, FFT_WRITE1
  } fft_drain_state_e;
  fft_drain_state_e      fft_drain_state_q;
  logic [VECTOR_W-1:0]   fft_drain_vec0_q, fft_drain_vec1_q;
  logic [LOCAL_ADDR_W-1:0] fft_drain_addr0_q, fft_drain_addr1_q;
  logic                  fft_drain_write_valid;
  logic                  fft_drain_write_ready;
  logic [LOCAL_ADDR_W-1:0] fft_drain_write_addr;
  logic [VECTOR_W-1:0]   fft_drain_write_data;

  // Shared resource clients.
  shared_stage_role_e stage_role;
  logic [N_PE-1:0] fft_stage_wr_valid,fft_stage_wr_ready,fft_stage_wr_entry;
  logic [N_PE-1:0][VECTOR_W-1:0] fft_stage_wr_data;
  logic fft_svrf_wr_valid,fft_svrf_wr_ready;
  logic [PARAM_ID_W-1:0] fft_svrf_wr_pid;logic [VECTOR_W-1:0] fft_svrf_wr_data;
  logic fft_svrf_rd_valid,fft_svrf_rd_ready,fft_svrf_rd_data_valid;
  logic [PARAM_ID_W-1:0] fft_svrf_rd_pid;
  logic [VECTOR_W-1:0] fft_svrf_rd_data;
  logic [N_PE-1:0] mm_stage_wr_valid,mm_stage_wr_ready,mm_stage_wr_entry;
  logic [N_PE-1:0][VECTOR_W-1:0] mm_stage_wr_data;
  logic [N_PE-1:0] qr_stage_wr_valid,qr_stage_wr_ready,qr_stage_wr_entry;
  logic [N_PE-1:0][VECTOR_W-1:0] qr_stage_wr_data;
  logic [N_PE-1:0] qr_preload_stage_wr_valid,qr_preload_stage_wr_ready,qr_preload_stage_wr_entry;
  logic [N_PE-1:0][VECTOR_W-1:0] qr_preload_stage_wr_data;
  logic [N_PE-1:0] qr_target_stage_wr_valid,qr_target_stage_wr_entry;
  logic [N_PE-1:0][VECTOR_W-1:0] qr_target_stage_wr_data;
  logic qr_mode_active;
  logic [N_PE-1:0] stage_rd_valid,stage_rd_ready,stage_rd_entry,stage_rd_consume;
  logic [1:0] fft_stage_rd_valid,fft_stage_rd_ready,fft_stage_rd_entry,fft_stage_rd_consume;
  logic [1:0] fft_stage_rd_data_valid;logic [1:0][VECTOR_W-1:0] fft_stage_rd_data;
  logic [N_PE-1:0] mm_stage_rd_valid,mm_stage_rd_ready,mm_stage_rd_entry,mm_stage_rd_consume;
  logic [N_PE-1:0] mm_stage_rd_data_valid;logic [N_PE-1:0][VECTOR_W-1:0] mm_stage_rd_data;
  logic [N_PE-1:0] stage_rd_data_valid;logic [N_PE-1:0][VECTOR_W-1:0] stage_rd_data;
  logic [N_PE-1:0][1:0] stage_peek_valid;
  logic [N_PE-1:0][1:0][VECTOR_W-1:0] stage_peek_data;
  logic stage_empty;
  logic shared_ru_in_valid,shared_ru_in_ready,shared_ru_out_valid,shared_ru_out_ready;
  logic [2:0] shared_ru_mode;logic [N_PE*VECTOR_W-1:0] shared_ru_in_vectors;
  logic [1:0][VECTOR_W-1:0] shared_ru_out_vectors;

  // Storage-free QR controller signals.
  logic shared_qr_preload_start,shared_qr_preload_ready,shared_qr_preload_busy,shared_qr_preload_valid;
  logic [QR_ROT_W-1:0] shared_qr_rotation,shared_qr_preload_rotation;
  logic [QR_ROW_W-1:0] shared_qr_pivot_row,shared_qr_column;
  logic shared_qr_pair_req,shared_qr_crot_req,shared_qr_crot_entity_qt,shared_qr_crot_ready;
  logic shared_qr_crot_rows_valid,shared_qr_cordic_pair_valid;
  logic [N_PE*VECTOR_W-1:0] shared_qr_crot_pivot_rows,shared_qr_crot_target_rows;
  logic signed [LANE_W-1:0] shared_qr_cordic_pivot,shared_qr_cordic_target;

  // --------------------------------------------------------------------------
  // SMU request mux and response wires
  // --------------------------------------------------------------------------
  logic [N_PE-1:0] smu_pe_req_valid;
  logic [N_PE-1:0] smu_pe_req_ready;
  logic [N_PE-1:0][1:0] smu_pe_req_type;
  logic [N_PE-1:0] smu_pe_req_is_vec;
  logic [N_PE-1:0][LOCAL_ADDR_W-1:0] smu_pe_req_addr;
  logic [N_PE-1:0][VECTOR_W-1:0] smu_pe_req_data;
  logic [N_PE-1:0][3:0] smu_pe_req_wstrb;
  logic [N_PE-1:0][3:0] smu_pe_req_tag;

  logic [N_PE-1:0] smu_pe_rsp_valid;
  logic [N_PE-1:0] smu_pe_rsp_kind;
  logic [N_PE-1:0] smu_pe_rsp_err;
  logic [N_PE-1:0][VECTOR_W-1:0] smu_pe_rsp_data;
  logic [N_PE-1:0][3:0] smu_pe_rsp_tag;
  logic [LOCAL_BANKS-1:0] wbq_commit_valid;
  logic [LOCAL_BANKS-1:0][LOCAL_ADDR_W-1:0] wbq_commit_addr;
  logic [LOCAL_BANKS-1:0][VECTOR_W-1:0] wbq_commit_data;


  // --------------------------------------------------------------------------
  // Cluster control/issue hierarchy
  // --------------------------------------------------------------------------
  cluster_top #(
    .CLUSTER_ID(CLUSTER_ID),
    .XBAR_FIFO_DEPTH(XBAR_FIFO_DEPTH),
    .ENABLE_LOCAL_XBAR(ENABLE_LOCAL_XBAR)
  ) u_cluster (
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .imem_wr_en_i(imem_wr_en_i),
    .imem_wr_addr_i(imem_wr_addr_i),
    .imem_wr_data_i(imem_wr_data_i),
    .ctx_wr_en_i(ctx_wr_en_i),
    .ctx_wr_addr_i(ctx_wr_addr_i),
    .ctx_wr_data_i(ctx_wr_data_i),
    .start_i(start_i),
    .program_words_i(program_words_i),
    .done_o(done_o),
    .active_o(active_o),
    .fault_o(fault_o),
    .fault_code_o(fault_code_o),
    .barrier_req_o(barrier_req_o),
    .barrier_token_o(barrier_token_o),
    .barrier_release_i(barrier_release_i),
    .dma_req_valid_o(dma_req_valid_o),
    .dma_req_ready_i(dma_req_ready_i),
    .dma_src_cluster_o(dma_src_cluster_o),
    .dma_dst_cluster_o(dma_dst_cluster_o),
    .dma_src_local_o(dma_src_local_o),
    .dma_dst_local_o(dma_dst_local_o),
    .dma_len_vec_o(dma_len_vec_o),
    .dma_requester_pe_o(dma_requester_pe_o),
    .dma_tag_o(dma_tag_o),
    .dma_idle_i(dma_idle_i),
    .qr_mem_req_valid_o(),
    .qr_mem_req_ready_i(1'b0),
    .qr_mem_req_write_o(),
    .qr_mem_req_addr_o(),
    .qr_mem_rsp_valid_i(1'b0),
    .qr_mem_rsp_data_i('0),
    .pe_issue_valid_o(pe_issue_valid),
    .pe_issue_ready_i(pe_issue_ready),
    .pe_slots_o(pe_slots),
    .pe_param_id_o(pe_param_id),
    .pe_legacy_ctx_id_o(pe_legacy_ctx_id),
    .pe_immediate_o(pe_immediate),
    .pe_context_o(pe_context),
    .pe_param_valid_o(pe_param_valid),
    .pe_param_vector_o(pe_param_vector),
    .pe_param_tag_o(pe_param_tag),
    .fir_agu_active_o(fir_agu_active),
    .fir_k_group_o(fir_k_group),
    .fir_k_group_limit_o(fir_k_group_limit),
    .fir_x_valid_o(fir_x_valid),
    .fir_x_index_o(fir_x_index),
    .fir_h_valid_o(fir_h_valid),
    .fir_h_index_o(fir_h_index),
    .fir_sample_index_o(fir_sample_index),
    .pe_busy_i(pe_busy),
    .ru_busy_i(1'b0),
    .qr_target_valid_i('0),
    .qr_target_vectors_i('0),
    .qr_target_reset_o(),
    .qr_pe_pairs_valid_o(qr_pe_pairs_valid),
    .qr_pe_pairs_ready_i(qr_pe_pairs_ready),
    .qr_pe_pairs_o(qr_pe_pairs),
    .cordic_qr_pair_valid_o(cordic_qr_pair_valid),
    .cordic_qr_pivot_o(cordic_qr_pivot),
    .cordic_qr_target_o(cordic_qr_target),
    .cordic_req_valid_o(cordic_req_valid),
    .cordic_req_ready_i(cordic_req_ready),
    .cordic_mode_twiddle_o(cordic_mode_twiddle),
    .cordic_twiddle_j_o(cordic_twiddle_j),
    .cordic_twiddle_m_log2_o(cordic_twiddle_m_log2),
    .cordic_param_id_o(cordic_param_id),
    .cordic_immediate_o(cordic_immediate),
    .cordic_context_o(cordic_context),
    .cordic_rsp_valid_i(cordic_rsp_valid),
    .cordic_rsp_vector_i(cordic_rsp_vector),
    .cordic_rsp_cos_i(cordic_rsp_cos),
    .cordic_rsp_sin_i(cordic_rsp_sin),
    .cordic_idle_i(cordic_idle),
    .ext_param_wr_valid_i(ext_param_wr_valid_i),
    .ext_param_wr_ready_o(ext_param_wr_ready_o),
    .ext_param_wr_op_i(ext_param_wr_op_i),
    .ext_param_wr_pid_i(ext_param_wr_pid_i),
    .ext_param_wr_data_i(ext_param_wr_data_i),
    .ext_param_wr_pair_c_i(ext_param_wr_pair_c_i),
    .ext_param_wr_pair_s_i(ext_param_wr_pair_s_i),
    .ext_param_wr_tag_i(ext_param_wr_tag_i),
    .pe_result_valid_i(result_valid_q),
    .pe_result_ready_o(pe_result_ready),
    .pe_result_data_i(pe_result_data),
    .pe_result_pid_i(pe_result_pid),
    .pe_writeback_valid_o(pe_writeback_valid),
    .pe_writeback_ready_i(pe_writeback_ready),
    .pe_writeback_data_o(pe_writeback_data),
    .pe_writeback_pid_o(pe_writeback_pid),
    .pe_writeback_immediate_o(pe_writeback_immediate),
    .cordic_broadcast_valid_i(cordic_broadcast_valid),
    .cordic_broadcast_ready_o(cordic_broadcast_ready),
    .cordic_broadcast_data_i(cordic_broadcast_data),
    .cordic_broadcast_pid_i(cordic_broadcast_pid),
    .xbar_dst_valid_o(xbar_dst_valid),
    .xbar_dst_pop_i(xbar_dst_pop),
    .xbar_dst_data_o(xbar_dst_data),
    .shared_qr_preload_start_o(shared_qr_preload_start),
    .shared_qr_rotation_o(shared_qr_rotation),.shared_qr_pivot_row_o(shared_qr_pivot_row),
    .shared_qr_preload_ready_i(shared_qr_preload_ready),.shared_qr_preload_busy_i(shared_qr_preload_busy),
    .shared_qr_preload_valid_i(shared_qr_preload_valid),.shared_qr_preload_rotation_i(shared_qr_preload_rotation),
    .shared_qr_pair_req_o(shared_qr_pair_req),.shared_qr_column_o(shared_qr_column),
    .shared_qr_crot_req_o(shared_qr_crot_req),.shared_qr_crot_entity_qt_o(shared_qr_crot_entity_qt),
    .shared_qr_crot_ready_o(shared_qr_crot_ready),.shared_qr_crot_rows_valid_i(shared_qr_crot_rows_valid),
    .shared_qr_crot_pivot_rows_i(shared_qr_crot_pivot_rows),.shared_qr_crot_target_rows_i(shared_qr_crot_target_rows),
    .shared_qr_cordic_pair_valid_i(shared_qr_cordic_pair_valid),
    .shared_qr_cordic_pivot_i(shared_qr_cordic_pivot),.shared_qr_cordic_target_i(shared_qr_cordic_target),
    .stage_role_i(stage_role),
    .fft_svrf_wr_valid_i(fft_svrf_wr_valid),.fft_svrf_wr_ready_o(fft_svrf_wr_ready),
    .fft_svrf_wr_pid_i(fft_svrf_wr_pid),.fft_svrf_wr_data_i(fft_svrf_wr_data),
    .fft_svrf_rd_valid_i(fft_svrf_rd_valid),.fft_svrf_rd_pid_i(fft_svrf_rd_pid),
    .fft_svrf_rd_ready_o(fft_svrf_rd_ready),.fft_svrf_rd_data_o(fft_svrf_rd_data),
    .fft_svrf_rd_data_valid_o(fft_svrf_rd_data_valid),
    .fft_stage_wr_valid_i(fft_stage_wr_valid),.fft_stage_wr_entry_i(fft_stage_wr_entry),
    .fft_stage_wr_data_i(fft_stage_wr_data),.fft_stage_wr_ready_o(fft_stage_wr_ready),
    .mm_stage_wr_valid_i(mm_stage_wr_valid),.mm_stage_wr_entry_i(mm_stage_wr_entry),
    .mm_stage_wr_data_i(mm_stage_wr_data),.mm_stage_wr_ready_o(mm_stage_wr_ready),
    .qr_stage_wr_valid_i(qr_stage_wr_valid),.qr_stage_wr_entry_i(qr_stage_wr_entry),
    .qr_stage_wr_data_i(qr_stage_wr_data),.qr_stage_wr_ready_o(qr_stage_wr_ready),
    .ext_stage_wr_valid_i(generic_stage_wr_valid),.ext_stage_wr_entry_i(generic_stage_wr_entry),
    .ext_stage_wr_data_i(generic_stage_wr_data),.ext_stage_wr_ready_o(generic_stage_wr_ready),
    .stage_rd_valid_i(stage_rd_valid),.stage_rd_entry_i(stage_rd_entry),
    .stage_rd_consume_i(stage_rd_consume),.stage_rd_ready_o(stage_rd_ready),
    .stage_rd_data_valid_o(stage_rd_data_valid),.stage_rd_data_o(stage_rd_data),
    .stage_peek_valid_o(stage_peek_valid),.stage_peek_data_o(stage_peek_data),
    .stage_invalidate_all_i(1'b0),.stage_empty_o(stage_empty),
    .shared_ru_in_valid_i(shared_ru_in_valid),.shared_ru_in_ready_o(shared_ru_in_ready),
    .shared_ru_mode_i(shared_ru_mode),.shared_ru_in_vectors_i(shared_ru_in_vectors),
    .shared_ru_out_valid_o(shared_ru_out_valid),.shared_ru_out_ready_i(shared_ru_out_ready),
    .shared_ru_out_vectors_o(shared_ru_out_vectors)
  );

  // --------------------------------------------------------------------------
  // Shared operand staging role/mux and storage-free QR controller.
  // --------------------------------------------------------------------------
  always_comb begin
    qr_target_stage_wr_valid = '0;
    qr_target_stage_wr_entry = '1; // entry1 = target row
    qr_target_stage_wr_data = '0;
    for (int b = 0; b < LOCAL_BANKS; b++) begin
      for (int q = 0; q < QR_TARGET_INPUT_VECS; q++) begin
        if (wbq_commit_valid[b] &&
            (wbq_commit_addr[b] == LOCAL_ADDR_W'((QR_TARGET_INPUT_BASE_VEC+q)*VECTOR_BYTES))) begin
          qr_target_stage_wr_valid[q] = 1'b1;
          qr_target_stage_wr_data[q] = wbq_commit_data[b];
        end
      end
    end
    for (int p = 0; p < N_PE; p++) begin
      for (int q = 0; q < QR_TARGET_INPUT_VECS; q++) begin
        if (smu_pe_req_valid[p] && smu_pe_req_ready[p] &&
            (smu_pe_req_type[p] == 2'b01) && smu_pe_req_is_vec[p] &&
            (smu_pe_req_addr[p] == LOCAL_ADDR_W'((QR_TARGET_INPUT_BASE_VEC+q)*VECTOR_BYTES))) begin
          qr_target_stage_wr_valid[q] = 1'b1;
          qr_target_stage_wr_data[q] = smu_pe_req_data[p];
        end
      end
    end

    // Target landing is an architectural visibility event and therefore wins
    // over a simultaneous pivot preload write to the same staging bank.
    qr_stage_wr_valid = '0;
    qr_stage_wr_entry = '0;
    qr_stage_wr_data = '0;
    qr_preload_stage_wr_ready = '0;
    for (int b = 0; b < N_PE; b++) begin
      if (qr_target_stage_wr_valid[b]) begin
        qr_stage_wr_valid[b] = 1'b1;
        qr_stage_wr_entry[b] = 1'b1;
        qr_stage_wr_data[b] = qr_target_stage_wr_data[b];
      end else begin
        qr_stage_wr_valid[b] = qr_preload_stage_wr_valid[b];
        qr_stage_wr_entry[b] = qr_preload_stage_wr_entry[b];
        qr_stage_wr_data[b] = qr_preload_stage_wr_data[b];
        qr_preload_stage_wr_ready[b] = qr_stage_wr_ready[b];
      end
    end

    qr_mode_active = shared_qr_preload_start || shared_qr_preload_busy ||
                     shared_qr_preload_valid || shared_qr_pair_req ||
                     shared_qr_crot_req || cordic_qr_pair_valid ||
                     (|qr_target_stage_wr_valid);
    if (fft_stream_enable_i)
      stage_role = STAGE_ROLE_FFT_INPUT;
    else if (mm_mac_valid || (|mm_b_req_valid) || (|mm_stage_wr_valid))
      stage_role = STAGE_ROLE_MM_B;
    else if (qr_mode_active)
      stage_role = STAGE_ROLE_QR_ROWS;
    else if (fir_agu_active)
      stage_role = STAGE_ROLE_FIR_X;
    else
      stage_role = STAGE_ROLE_GENERIC;

    stage_rd_valid = '0;
    stage_rd_entry = '0;
    stage_rd_consume = '0;
    fft_stage_rd_ready = '0;
    fft_stage_rd_data_valid = '0;
    fft_stage_rd_data = '0;
    mm_stage_rd_ready = '0;
    mm_stage_rd_data_valid = '0;
    mm_stage_rd_data = '0;
    case (stage_role)
      STAGE_ROLE_FFT_INPUT: begin
        stage_rd_valid[1:0] = fft_stage_rd_valid;
        stage_rd_entry[1:0] = fft_stage_rd_entry;
        stage_rd_consume[1:0] = fft_stage_rd_consume;
        fft_stage_rd_ready = stage_rd_ready[1:0];
        fft_stage_rd_data_valid = stage_rd_data_valid[1:0];
        fft_stage_rd_data = stage_rd_data[1:0];
      end
      STAGE_ROLE_MM_B: begin
        stage_rd_valid = mm_stage_rd_valid;
        stage_rd_entry = mm_stage_rd_entry;
        stage_rd_consume = mm_stage_rd_consume;
        mm_stage_rd_ready = stage_rd_ready;
        mm_stage_rd_data_valid = stage_rd_data_valid;
        mm_stage_rd_data = stage_rd_data;
      end
      default: begin
        // Generic/FIR MEM operands occupy entry0 in the four PE-corresponding
        // banks.  Consumption occurs only when an instruction actually fires.
        for (int p = 0; p < N_PE; p++) begin
          stage_rd_valid[p] = pe_fire[p] && (slot_upstream[p] == DIR_MEM);
          stage_rd_entry[p] = 1'b0;
          stage_rd_consume[p] = stage_rd_valid[p];
        end
        if (cordic_req_valid && cordic_req_ready && !cordic_mode_twiddle &&
            (cordic_src_sel == 2'd0)) begin
          stage_rd_valid[0] = 1'b1;
          stage_rd_entry[0] = 1'b0;
          stage_rd_consume[0] = 1'b1;
        end
      end
    endcase
  end

  qr_preload_controller u_qr_preload_shared (
    .clk_i(clk_i),.rst_ni(rst_ni),
    .start_valid_i(shared_qr_preload_start),.start_ready_o(shared_qr_preload_ready),
    .rotation_id_i(shared_qr_rotation),.pivot_row_i(shared_qr_pivot_row),
    .mem_req_valid_o(qr_mem_req_valid),.mem_req_ready_i(qr_mem_req_ready),
    .mem_req_write_o(qr_mem_req_write),.mem_req_addr_o(qr_mem_req_addr),
    .mem_rsp_valid_i(qr_mem_rsp_valid),.mem_rsp_data_i(qr_mem_rsp_data),
    .stage_wr_valid_o(qr_preload_stage_wr_valid),.stage_wr_ready_i(qr_preload_stage_wr_ready),
    .stage_wr_entry_o(qr_preload_stage_wr_entry),.stage_wr_data_o(qr_preload_stage_wr_data),
    .stage_peek_valid_i(stage_peek_valid),.stage_peek_data_i(stage_peek_data),
    .cordic_pair_req_i(shared_qr_pair_req),.cordic_rotation_id_i(shared_qr_rotation),
    .cordic_column_i(shared_qr_column),.cordic_pair_valid_o(shared_qr_cordic_pair_valid),
    .cordic_pivot_o(shared_qr_cordic_pivot),.cordic_target_o(shared_qr_cordic_target),
    .crot_req_i(shared_qr_crot_req),.crot_entity_qt_i(shared_qr_crot_entity_qt),
    .crot_rows_valid_o(shared_qr_crot_rows_valid),
    .crot_pivot_rows_o(shared_qr_crot_pivot_rows),.crot_target_rows_o(shared_qr_crot_target_rows),
    .preload_busy_o(shared_qr_preload_busy),.preload_valid_o(shared_qr_preload_valid),
    .preload_rotation_id_o(shared_qr_preload_rotation));

  assign mm_mac_valid = pe_issue_valid &&
                        (micro_kind_e'(pe_context[CTX_KIND_LSB +: 5]) == M_MM_MAC) &&
                        ((pe_immediate[28:25] & MICRO_FLAG_MM_PINGPONG) != 0);
  assign mm_issue_fire = mm_mac_valid && pe_issue_ready;

  mm_b_prefetch_controller u_mm_b_prefetch (
    .clk_i(clk_i),.rst_ni(rst_ni),.mm_mac_valid_i(mm_mac_valid),.issue_fire_i(mm_issue_fire),
    .immediate_i(pe_immediate),.context_i(pe_context),
    .shared_a_valid_i(pe_param_valid),.shared_a_i(pe_param_vector),
    .operands_ready_o(mm_operands_ready),.a_vector_o(mm_a_vector),
    .b_req_valid_o(mm_b_req_valid),.b_req_ready_i(mm_b_req_ready),
    .b_req_addr_o(mm_b_req_addr),.b_req_tag_o(mm_b_req_tag),
    .b_rsp_valid_i(smu_pe_rsp_valid),.b_rsp_err_i(smu_pe_rsp_err),
    .b_rsp_kind_i(smu_pe_rsp_kind),.b_rsp_data_i(smu_pe_rsp_data),.b_rsp_tag_i(smu_pe_rsp_tag),
    .stage_wr_valid_o(mm_stage_wr_valid),.stage_wr_ready_i(mm_stage_wr_ready),
    .stage_wr_entry_o(mm_stage_wr_entry),.stage_wr_data_o(mm_stage_wr_data),
    .stage_rd_valid_o(mm_stage_rd_valid),.stage_rd_data_valid_i(mm_stage_rd_data_valid),
    .stage_rd_entry_o(mm_stage_rd_entry),.stage_rd_consume_o(mm_stage_rd_consume),
    .stage_rd_data_i(mm_stage_rd_data),.b_vectors_o(mm_b_vectors));

  assign fft_task_ready_o = fft_stream_enable_i && fft_task_ready_int;
  assign fft_input_fill_ready_o = fft_stream_enable_i && fft_input_fill_ready_int;
  assign fft_stage_done_o = fft_stage_done_int;
  assign fft_stream_busy_o = fft_stream_busy_int || fft_pe_active_q ||
                             fft_rsp_hold_valid_q ||
                             (fft_drain_state_q != FFT_DRAIN_IDLE);

  fft_stream_engine u_fft_stream (
    .clk_i(clk_i),.rst_ni(rst_ni),
    .task_valid_i(fft_stream_enable_i && fft_task_valid_i),.task_ready_o(fft_task_ready_int),
    .task_slot_o(fft_task_slot_o),.task_param_pid_i(fft_task_param_pid_i),
    .task_seed_re_i(fft_task_seed_re_i),.task_seed_im_i(fft_task_seed_im_i),
    .task_step_re_i(fft_task_step_re_i),.task_step_im_i(fft_task_step_im_i),
    .task_dst0_addr_i(fft_task_dst0_addr_i),.task_dst1_addr_i(fft_task_dst1_addr_i),
    .input_fill_valid_i(fft_stream_enable_i && fft_input_fill_valid_i),
    .input_fill_ready_o(fft_input_fill_ready_int),.input_fill_slot_i(fft_input_fill_slot_i),
    .input_fill_vector_i(fft_input_fill_vector_i),.input_fill_data_i(fft_input_fill_data_i),
    .stage_wr_valid_o(fft_stage_wr_valid[1:0]),.stage_wr_ready_i(fft_stage_wr_ready[1:0]),
    .stage_wr_entry_o(fft_stage_wr_entry[1:0]),.stage_wr_data_o(fft_stage_wr_data[1:0]),
    .stage_rd_valid_o(fft_stage_rd_valid),.stage_rd_data_valid_i(fft_stage_rd_data_valid),
    .stage_rd_entry_o(fft_stage_rd_entry),.stage_rd_consume_o(fft_stage_rd_consume),
    .stage_rd_data_i(fft_stage_rd_data),
    .svrf_wr_valid_o(fft_svrf_wr_valid),.svrf_wr_ready_i(fft_svrf_wr_ready),
    .svrf_wr_pid_o(fft_svrf_wr_pid),.svrf_wr_data_o(fft_svrf_wr_data),
    .svrf_rd_valid_o(fft_svrf_rd_valid),.svrf_rd_ready_i(fft_svrf_rd_ready && fft_svrf_rd_data_valid),
    .svrf_rd_pid_o(fft_svrf_rd_pid),.svrf_rd_data_i(fft_svrf_rd_data),
    .pe_req_valid_o(fft_pe_req_valid),.pe_req_ready_i(fft_pe_req_ready),
    .pe_req_kind_o(fft_pe_req_kind),.pe_req_slot_o(fft_pe_req_slot),
    .pe_req_active_mask_o(fft_pe_req_active_mask),.pe_req_cmul_mul_only_o(fft_pe_req_cmul_mul_only),
    .pe_req_a_o(fft_pe_req_a),.pe_req_b_o(fft_pe_req_b),.pe_req_twiddle_o(fft_pe_req_twiddle),
    .pe_rsp_valid_i(fft_pe_rsp_valid),.pe_rsp_ready_o(fft_pe_rsp_ready),
    .pe_rsp_kind_i(fft_pe_rsp_kind),.pe_rsp_slot_i(fft_pe_rsp_slot),.pe_rsp_data_i(fft_pe_rsp_data),
    .result_valid_o(fft_result_valid),.result_ready_i(fft_result_ready),
    .result_vec0_o(fft_result_vec0),.result_vec1_o(fft_result_vec1),
    .result_dst0_addr_o(fft_result_dst0_addr),.result_dst1_addr_o(fft_result_dst1_addr),
    .stage_close_i(fft_stream_enable_i && fft_stage_close_i),
    .stage_done_o(fft_stage_done_int),.busy_o(fft_stream_busy_int));

  assign fft_stage_wr_valid[3:2]='0;
  assign fft_stage_wr_entry[3:2]='0;
  assign fft_stage_wr_data[3:2]='0;

  // --------------------------------------------------------------------------
  // PE slot decode, operand selection and issue readiness.
  // The same CMUL datapath serves FFT recurrence (mul-only) and butterfly.
  // --------------------------------------------------------------------------
  always_comb begin
    pe_issue_ready = !fft_stream_enable_i && !fft_pe_active_q &&
                     !fft_rsp_hold_valid_q;
    qr_pe_pairs_ready = 1'b0;
    xbar_dst_pop = '0;

    for (int p = 0; p < N_PE; p++) begin
      slot_bits[p]       = pe_slots[p*9 +: 9];
      slot_op[p]         = slot_bits[p][8:6];
      slot_upstream[p]   = slot_bits[p][5:3];
      slot_downstream[p] = slot_bits[p][2:0];
      slot_active[p]     = (slot_op[p] != PE_NOP);

      pe_core_ready[p] = !pe_busy[p] && !result_valid_q[p];
      if (slot_active[p]) begin
        if (slot_upstream[p] == DIR_MEM)
          pe_core_ready[p] &= stage_peek_valid[p][0];
        if (slot_upstream[p] == DIR_PE_RING)
          pe_core_ready[p] &= xbar_dst_valid[p];
        if (slot_upstream[p] == DIR_PARAM_RF)
          pe_core_ready[p] &= pe_param_valid;
        if (slot_op[p] == PE_CROT)
          pe_core_ready[p] &= shared_qr_crot_rows_valid && pe_param_valid;
        pe_issue_ready &= pe_core_ready[p];
      end
    end
    if (mm_mac_valid)
      pe_issue_ready &= mm_operands_ready;

    qr_pe_pairs_ready = !fft_stream_enable_i && pe_issue_valid && pe_issue_ready;
    fft_pe_req_ready = fft_stream_enable_i && !fft_pe_active_q &&
                       !fft_rsp_hold_valid_q && !(|pe_busy) &&
                       !(|result_valid_q);
    fft_pe_launch = fft_pe_req_valid && fft_pe_req_ready;

    for (int p = 0; p < N_PE; p++) begin
      pe_fire[p] = (fft_pe_launch && fft_pe_req_active_mask[p]) ||
                   (!fft_stream_enable_i && pe_issue_valid &&
                    pe_issue_ready && slot_active[p]);
      pe_fire_op[p] = fft_pe_launch ? context_entry_pkg::OP_CMUL :
                       context_entry_pkg::pe_op_e'(slot_op[p]);
      pe_fire_cmul_mul_only[p] = fft_pe_launch && fft_pe_req_cmul_mul_only;
      pe_fire_crot_separate_rows[p] = !fft_stream_enable_i &&
                                      (slot_op[p] == PE_CROT) &&
                                      shared_qr_crot_rows_valid;

      if (!fft_stream_enable_i && pe_fire[p] &&
          (slot_upstream[p] == DIR_PE_RING))
        xbar_dst_pop[p] = 1'b1;

      pe_selected_din[p] = pe_operand_i[p*VECTOR_W +: VECTOR_W];
      pe_selected_tw[p] = pe_twiddle_i[p*VECTOR_W +: VECTOR_W];
      pe_selected_aux[p] = '0;
      if (slot_upstream[p] == DIR_MEM)
        pe_selected_din[p] = stage_peek_data[p][0];
      else if (slot_upstream[p] == DIR_PE_RING)
        pe_selected_din[p] = xbar_dst_data[p*VECTOR_W +: VECTOR_W];
      else if (slot_upstream[p] == DIR_PARAM_RF)
        pe_selected_din[p] = pe_param_vector;
      if (pe_param_valid)
        pe_selected_tw[p] = pe_param_vector;

      if (mm_mac_valid) begin
        pe_selected_din[p] = mm_a_vector;
        pe_selected_tw[p] = mm_b_vectors[p*VECTOR_W +: VECTOR_W];
      end

      if ((slot_op[p] == PE_CROT) && shared_qr_crot_rows_valid) begin
        pe_selected_din[p] = shared_qr_crot_pivot_rows[p*VECTOR_W +: VECTOR_W];
        pe_selected_aux[p] = shared_qr_crot_target_rows[p*VECTOR_W +: VECTOR_W];
        pe_selected_tw[p] = pe_param_vector;
      end

      if (fft_pe_launch) begin
        pe_selected_din[p] = fft_pe_req_a[p*VECTOR_W +: VECTOR_W];
        if (fft_pe_req_cmul_mul_only) begin
          pe_selected_tw[p] = fft_pe_req_b[p*VECTOR_W +: VECTOR_W];
          pe_selected_aux[p] = '0;
        end else begin
          pe_selected_tw[p] = fft_pe_req_twiddle[p*VECTOR_W +: VECTOR_W];
          pe_selected_aux[p] = fft_pe_req_b[p*VECTOR_W +: VECTOR_W];
        end
      end
    end

    if (!fft_stream_enable_i && cordic_req_valid && cordic_req_ready &&
        (cordic_src_sel == 2'd2))
      xbar_dst_pop[0] = 1'b1;
  end

  generate
    for (genvar gp = 0; gp < N_PE; gp++) begin : g_pe
      for (genvar gl = 0; gl < LANES; gl++) begin : g_operand_unpack
        always_comb begin
          pe_fire_din[gp][gl] =
            $signed(pe_selected_din[gp][gl*LANE_W +: 16]);
          pe_fire_tw[gp][gl] =
            $signed(pe_selected_tw[gp][gl*LANE_W +: 16]);
          pe_fire_aux[gp][gl] =
            $signed(pe_selected_aux[gp][gl*LANE_W +: 16]);
        end
      end

      pe u_pe (
        .clk(clk_i),
        .rst_n(rst_ni),
        .fire(pe_fire[gp]),
        .fire_op(pe_fire_op[gp]),
        .fire_din(pe_fire_din[gp]),
        .fire_tw(pe_fire_tw[gp]),
        .fire_aux(pe_fire_aux[gp]),
        .fire_extra_latency(8'd0),
        .fire_mac_acc_clear(!fft_pe_launch && (slot_op[gp] == PE_MAC) &&
                            !pe_context[CTX_ACC_BIT]),
        .fire_reduce_acc_raw(!fft_pe_launch && (slot_upstream[gp] == DIR_ACC)),
        .fire_acc_context(!fft_pe_launch && pe_legacy_ctx_id[0]),
        .fire_cmul_mul_only(pe_fire_cmul_mul_only[gp]),
        .fire_crot_separate_rows(pe_fire_crot_separate_rows[gp]),
        .busy(pe_busy[gp]),
        .done(pe_done[gp]),
        .illegal_fire_while_busy(),
        .reg_out_flat(pe_reg_out_flat[gp])
      );

      always_comb begin
        result_data_q[gp] = '0;
        for (int l = 0; l < LANES; l++) begin
          result_data_q[gp][l*LANE_W +: LANE_W] =
            {{(LANE_W-16){pe_reg_out_flat[gp][l*16+15]}},
              pe_reg_out_flat[gp][l*16 +: 16]};
        end
      end
    end
  endgenerate

  // Autonomous results are held until cluster_top accepts/reroutes them.
  // FFT results bypass that path and are packed into two vectors below.
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      result_valid_q <= '0;
    end else begin
      for (int p = 0; p < N_PE; p++) begin
        if (result_valid_q[p] && pe_result_ready[p])
          result_valid_q[p] <= 1'b0;
        if (pe_done[p] && !fft_pe_active_q)
          result_valid_q[p] <= 1'b1;
      end
    end
  end

  // Existing PE CMUL results return through a single response channel.
  // Recurrence waves return PE0/PE1 directly; butterfly outputs pass through
  // the one shared reorder/pack unit.  No FFT-private result FIFO exists.
  always_comb begin
    fft_pe_rsp_valid = fft_rsp_hold_valid_q;
    fft_pe_rsp_slot = fft_rsp_hold_slot_q;
    fft_pe_rsp_kind = fft_rsp_hold_kind_q;
    fft_pe_rsp_data = '0;
    fft_pe_rsp_data[0*VECTOR_W +: VECTOR_W] = fft_rsp_hold_vec0_q;
    fft_pe_rsp_data[1*VECTOR_W +: VECTOR_W] = fft_rsp_hold_vec1_q;

    shared_ru_in_valid = fft_pe_done_pending_q &&
                         (fft_pe_active_kind_q == 2'd2);
    shared_ru_mode = 3'd1;
    shared_ru_in_vectors = pe_result_data;
    shared_ru_out_ready = fft_ru_pending_q && !fft_rsp_hold_valid_q;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin : p_fft_pe_response
    if (!rst_ni) begin
      fft_pe_active_q <= 1'b0;
      fft_pe_active_slot_q <= 1'b0;
      fft_pe_active_kind_q <= '0;
      fft_pe_active_mask_q <= '0;
      fft_pe_done_pending_q <= 1'b0;
      fft_ru_pending_q <= 1'b0;
      fft_rsp_hold_valid_q <= 1'b0;
      fft_rsp_hold_slot_q <= 1'b0;
      fft_rsp_hold_kind_q <= '0;
      fft_rsp_hold_vec0_q <= '0;
      fft_rsp_hold_vec1_q <= '0;
    end else begin
      if (fft_pe_launch) begin
        fft_pe_active_q <= 1'b1;
        fft_pe_active_slot_q <= fft_pe_req_slot;
        fft_pe_active_kind_q <= fft_pe_req_kind;
        fft_pe_active_mask_q <= fft_pe_req_active_mask;
      end

      if (fft_pe_active_q &&
          ((pe_done & fft_pe_active_mask_q) == fft_pe_active_mask_q)) begin
        // PE outputs become visible after this edge; consume them next cycle.
        fft_pe_active_q <= 1'b0;
        fft_pe_done_pending_q <= 1'b1;
      end

      if (fft_pe_done_pending_q && (fft_pe_active_kind_q != 2'd2) &&
          !fft_rsp_hold_valid_q) begin
        fft_rsp_hold_valid_q <= 1'b1;
        fft_rsp_hold_slot_q <= fft_pe_active_slot_q;
        fft_rsp_hold_kind_q <= fft_pe_active_kind_q;
        fft_rsp_hold_vec0_q <= result_data_q[0];
        fft_rsp_hold_vec1_q <= result_data_q[1];
        fft_pe_done_pending_q <= 1'b0;
      end

      if (shared_ru_in_valid && shared_ru_in_ready) begin
        fft_pe_done_pending_q <= 1'b0;
        fft_ru_pending_q <= 1'b1;
      end
      if (shared_ru_out_valid && shared_ru_out_ready) begin
        fft_rsp_hold_valid_q <= 1'b1;
        fft_rsp_hold_slot_q <= fft_pe_active_slot_q;
        fft_rsp_hold_kind_q <= 2'd2;
        fft_rsp_hold_vec0_q <= shared_ru_out_vectors[0];
        fft_rsp_hold_vec1_q <= shared_ru_out_vectors[1];
        fft_ru_pending_q <= 1'b0;
      end

      if (fft_rsp_hold_valid_q && fft_pe_rsp_ready)
        fft_rsp_hold_valid_q <= 1'b0;
    end
  end

  always_comb begin
    pe_result_data = '0;
    pe_result_pid = '0;
    for (int p = 0; p < N_PE; p++) begin
      pe_result_data[p*VECTOR_W +: VECTOR_W] = result_data_q[p];
      pe_result_pid[p*PARAM_ID_W +: PARAM_ID_W] = pe_param_id;
    end
  end

  // --------------------------------------------------------------------------
  // Registered local CORDIC integration
  // --------------------------------------------------------------------------
  logic signed [15:0] cordic_a;
  logic signed [15:0] cordic_b;
  logic [1:0] cordic_src_sel;
  logic [1:0] cordic_dst_sel;
  logic [PARAM_ID_W-1:0] cordic_pid_q;
  logic [1:0] cordic_dst_q;
  logic cordic_mode_q;
  logic cordic_source_ready;
  logic cordic_broadcast_valid_q;
  logic [PARAM_ID_W-1:0] cordic_broadcast_pid_q;

  always_comb begin
    cordic_src_sel = cordic_context[CTX_CORDIC_SRC_LSB +: 2];
    cordic_dst_sel = cordic_context[CTX_CORDIC_DST_LSB +: 2];
    cordic_a = $signed(stage_peek_data[0][0][0 +: 16]);
    cordic_b = $signed(stage_peek_data[0][0][LANE_W +: 16]);
    cordic_source_ready = stage_peek_valid[0][0];
    case (cordic_src_sel)
      2'd1: begin
        cordic_a = $signed(result_data_q[0][0 +: 16]);
        cordic_b = $signed(result_data_q[0][LANE_W +: 16]);
        cordic_source_ready = 1'b1;
      end
      2'd2: begin
        cordic_a = $signed(xbar_dst_data[0 +: 16]);
        cordic_b = $signed(xbar_dst_data[LANE_W +: 16]);
        cordic_source_ready = xbar_dst_valid[0];
      end
      default: begin end
    endcase
    // Production QR path: use the explicit pivot preload cache and the target-R
    // landing buffer, not PE0's generic operand slot.
    if (cordic_qr_pair_valid) begin
      cordic_a = $signed(cordic_qr_pivot[15:0]);
      cordic_b = $signed(cordic_qr_target[15:0]);
      cordic_source_ready = 1'b1;
    end
  end

  assign cordic_req_ready = !cordic_busy && !cordic_broadcast_valid_q &&
                            (cordic_mode_twiddle || cordic_source_ready);
  assign cordic_idle = !cordic_busy;

  cordic_unit u_cordic (
    .clk(clk_i),
    .rst_n(rst_ni),
    .start(cordic_req_valid && cordic_req_ready),
    .mode_twiddle_i(cordic_mode_twiddle),
    .a_in(cordic_a),
    .b_in(cordic_b),
    .twiddle_j_i(cordic_twiddle_j),
    .twiddle_m_log2_i(cordic_twiddle_m_log2),
    .busy(cordic_busy),
    .done(cordic_done),
    .r_out(cordic_r),
    .c_out(cordic_c),
    .s_out(cordic_s)
  );

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cordic_pid_q <= '0;
      cordic_dst_q <= 2'd0;
      cordic_broadcast_valid_q <= 1'b0;
      cordic_broadcast_pid_q <= '0;
      cordic_mode_q <= 1'b0;
    end else begin
      if (cordic_req_valid && cordic_req_ready) begin
        cordic_pid_q <= cordic_param_id;
        cordic_dst_q <= cordic_dst_sel;
        cordic_mode_q <= cordic_mode_twiddle;
      end
      if (cordic_broadcast_valid_q && cordic_broadcast_ready)
        cordic_broadcast_valid_q <= 1'b0;
      if (cordic_done && ((cordic_dst_q == 2'd1) || (cordic_dst_q == 2'd2))) begin
        cordic_broadcast_valid_q <= 1'b1;
        cordic_broadcast_pid_q <= cordic_pid_q;
      end
    end
  end

  always_comb begin
    cordic_rsp_vector = '0;
    if (cordic_mode_q) begin
      // FFT seed vector: first complex pair is {cos,sin}.
      cordic_rsp_vector[0*LANE_W +: LANE_W] = {{(LANE_W-16){cordic_c[15]}}, cordic_c};
      cordic_rsp_vector[1*LANE_W +: LANE_W] = {{(LANE_W-16){cordic_s[15]}}, cordic_s};
    end else begin
      // QR result vector: {r,c,s}.
      cordic_rsp_vector[0*LANE_W +: LANE_W] = {{(LANE_W-16){cordic_r[15]}}, cordic_r};
      cordic_rsp_vector[1*LANE_W +: LANE_W] = {{(LANE_W-16){cordic_c[15]}}, cordic_c};
      cordic_rsp_vector[2*LANE_W +: LANE_W] = {{(LANE_W-16){cordic_s[15]}}, cordic_s};
    end
    cordic_rsp_cos = {{(LANE_W-16){cordic_c[15]}}, cordic_c};
    cordic_rsp_sin = {{(LANE_W-16){cordic_s[15]}}, cordic_s};
    cordic_rsp_valid = cordic_done;

    cordic_broadcast_valid = cordic_broadcast_valid_q;
    // CORDIC outputs remain stable until the next accepted start. New starts
    // are blocked while the broadcast buffer is pending, so the live packed
    // result safely supplies the held ready/valid transaction.
    cordic_broadcast_data = cordic_rsp_vector;
    cordic_broadcast_pid = cordic_broadcast_pid_q;
  end

  // --------------------------------------------------------------------------
  // FFT result drain.  Packing has already occurred in the shared RU; the two
  // architectural vectors now use the ordinary local-SRAM write path.
  // --------------------------------------------------------------------------
  always_comb begin
    fft_drain_write_valid = (fft_drain_state_q == FFT_WRITE0) ||
                            (fft_drain_state_q == FFT_WRITE1);
    fft_drain_write_addr = (fft_drain_state_q == FFT_WRITE1) ?
                           fft_drain_addr1_q : fft_drain_addr0_q;
    fft_drain_write_data = (fft_drain_state_q == FFT_WRITE1) ?
                           fft_drain_vec1_q : fft_drain_vec0_q;
    fft_result_ready = (fft_drain_state_q == FFT_WRITE1) &&
                       fft_drain_write_ready;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin : p_fft_result_drain
    if (!rst_ni) begin
      fft_drain_state_q <= FFT_DRAIN_IDLE;
      fft_drain_vec0_q <= '0;
      fft_drain_vec1_q <= '0;
      fft_drain_addr0_q <= '0;
      fft_drain_addr1_q <= '0;
    end else begin
      unique case (fft_drain_state_q)
        FFT_DRAIN_IDLE: begin
          if (fft_result_valid) begin
            fft_drain_vec0_q <= fft_result_vec0;
            fft_drain_vec1_q <= fft_result_vec1;
            fft_drain_addr0_q <= fft_result_dst0_addr;
            fft_drain_addr1_q <= fft_result_dst1_addr;
            fft_drain_state_q <= FFT_WRITE0;
          end
        end
        FFT_WRITE0: if (fft_drain_write_ready)
          fft_drain_state_q <= FFT_WRITE1;
        FFT_WRITE1: if (fft_drain_write_ready)
          fft_drain_state_q <= FFT_DRAIN_IDLE;
        default: fft_drain_state_q <= FFT_DRAIN_IDLE;
      endcase
    end
  end

  // QR target vectors are written directly into SharedOperandStaging entry1
  // by the combinational accepted-write detector above.  No QR-private mirror
  // registers are retained.

  // --------------------------------------------------------------------------
  // SMU request arbitration
  // --------------------------------------------------------------------------
  always_comb begin
    smu_pe_req_valid = '0;
    smu_pe_req_type = '0;
    smu_pe_req_is_vec = '0;
    smu_pe_req_addr = '0;
    smu_pe_req_data = '0;
    smu_pe_req_wstrb = '0;
    smu_pe_req_tag = '0;
    ext_pe_mem_req_ready_o = '0;
    pe_writeback_ready = '0;
    mm_b_req_ready = '0;
    fft_drain_write_ready = 1'b0;
    for (int p = 0; p < N_PE; p++) begin
      if ((p == 0) && fft_drain_write_valid) begin
        smu_pe_req_valid[p] = 1'b1;
        smu_pe_req_type[p] = 2'b01;
        smu_pe_req_is_vec[p] = 1'b1;
        smu_pe_req_addr[p] = fft_drain_write_addr;
        smu_pe_req_data[p] = fft_drain_write_data;
        smu_pe_req_wstrb[p] = 4'hF;
        smu_pe_req_tag[p] = 4'hD;
        fft_drain_write_ready = smu_pe_req_ready[p];
      end else if (pe_writeback_valid[p]) begin
        smu_pe_req_valid[p] = 1'b1;
        smu_pe_req_type[p] = 2'b01;
        smu_pe_req_is_vec[p] = 1'b1;
        smu_pe_req_addr[p] = pe_writeback_addr_i[p*LOCAL_ADDR_W +: LOCAL_ADDR_W];
        smu_pe_req_data[p] = pe_writeback_data[p*VECTOR_W +: VECTOR_W];
        smu_pe_req_wstrb[p] = 4'hF;
        smu_pe_req_tag[p] = pe_writeback_pid[p*PARAM_ID_W +: PARAM_ID_W];
        pe_writeback_ready[p] = smu_pe_req_ready[p];
      end else if (mm_b_req_valid[p]) begin
        smu_pe_req_valid[p] = 1'b1;
        smu_pe_req_type[p] = 2'b00;
        smu_pe_req_is_vec[p] = 1'b1;
        smu_pe_req_addr[p] = mm_b_req_addr[p];
        smu_pe_req_data[p] = '0;
        smu_pe_req_wstrb[p] = 4'h0;
        smu_pe_req_tag[p] = mm_b_req_tag[p];
        mm_b_req_ready[p] = smu_pe_req_ready[p];
      end else begin
        // The SMU response port is registered but has no downstream ready.
        // Do not accept a second ordinary read until its one-entry operand
        // latch is empty, and reserve tag E for the internal MM reader.
        if (!((ext_pe_mem_req_type_i[p] == 2'b00) &&
              (stage_peek_valid[p][0] || (ext_pe_mem_req_tag_i[p] == 4'hE)))) begin
          smu_pe_req_valid[p] = ext_pe_mem_req_valid_i[p];
          smu_pe_req_type[p] = ext_pe_mem_req_type_i[p];
          smu_pe_req_is_vec[p] = ext_pe_mem_req_is_vec_i[p];
          smu_pe_req_addr[p] = ext_pe_mem_req_addr_i[p];
          smu_pe_req_data[p] = ext_pe_mem_req_data_i[p];
          smu_pe_req_wstrb[p] = ext_pe_mem_req_wstrb_i[p];
          smu_pe_req_tag[p] = ext_pe_mem_req_tag_i[p];
          ext_pe_mem_req_ready_o[p] = smu_pe_req_ready[p];
        end
      end
    end
  end

  // Ordinary successful PE read responses land directly in shared staging
  // entry0.  Tag E belongs to the MM controller and is routed separately.
  always_comb begin
    generic_stage_wr_valid = '0;
    generic_stage_wr_entry = '0;
    generic_stage_wr_data = '0;
    for (int p = 0; p < N_PE; p++) begin
      if (smu_pe_rsp_valid[p] && !smu_pe_rsp_err[p] && !smu_pe_rsp_kind[p] &&
          (smu_pe_rsp_tag[p] != 4'hE)) begin
        generic_stage_wr_valid[p] = 1'b1;
        generic_stage_wr_entry[p] = 1'b0;
        generic_stage_wr_data[p] = smu_pe_rsp_data[p];
      end
    end
  end

  assign smu_pe_rsp_valid_o = smu_pe_rsp_valid;
  assign smu_pe_rsp_kind_o = smu_pe_rsp_kind;
  assign smu_pe_rsp_err_o = smu_pe_rsp_err;
  assign smu_pe_rsp_data_o = smu_pe_rsp_data;
  assign smu_pe_rsp_tag_o = smu_pe_rsp_tag;

  // --------------------------------------------------------------------------
  // Local SRAM / WBQ / NoC scheduler
  // --------------------------------------------------------------------------
  sv_smu_sched_top #(
    .NUM_PE(N_PE),
    .NUM_BANKS(4),
    .LOCAL_ADDR_W(LOCAL_ADDR_W),
    .LINE_ADDR_W(8),
    .GLOBAL_ADDR_W(GLOBAL_ADDR_W),
    .VECTOR_W(VECTOR_W),
    .PE_TAG_W(4),
    .WSTRB_W(4),
    .DMA_TAG_W(4),
    .DMA_CNT_W(8)
  ) u_smu (
    .clk(clk_i),
    .rst_n(rst_ni),
    .pe_req_valid(smu_pe_req_valid),
    .pe_req_ready(smu_pe_req_ready),
    .pe_req_type(smu_pe_req_type),
    .pe_req_is_vec(smu_pe_req_is_vec),
    .pe_req_addr(smu_pe_req_addr),
    .pe_req_data(smu_pe_req_data),
    .pe_req_wstrb(smu_pe_req_wstrb),
    .pe_req_tag(smu_pe_req_tag),
    .qr_preload_req_valid(qr_mem_req_valid),
    .qr_preload_req_ready(qr_mem_req_ready),
    .qr_preload_req_addr(qr_mem_req_addr),
    .qr_preload_rsp_valid(qr_mem_rsp_valid),
    .qr_preload_rsp_data(qr_mem_rsp_data),
    .dma_wb_valid(dma_wb_valid_i),
    .dma_wb_addr(dma_wb_addr_i),
    .dma_wb_data(dma_wb_data_i),
    .wbq_enq_valid(wbq_enq_valid_i),
    .wbq_enq_ready(wbq_enq_ready_o),
    .wbq_enq_bank_idx(wbq_enq_bank_idx_i),
    .wbq_enq_line_addr(wbq_enq_line_addr_i),
    .wbq_enq_data(wbq_enq_data_i),
    .wbq_enq_tag(wbq_enq_tag_i),
    .wbq_enq_completion_credit(wbq_enq_completion_credit_i),
    .dma_local_dst_active(dma_local_dst_active_i),
    .dma_local_dst_start(dma_local_dst_start_i),
    .dma_local_dst_end(dma_local_dst_end_i),
    .dma_issue_active(dma_issue_active_i),
    .dma_issue_error(dma_issue_error_i),
    .dma_issue_dst_base(dma_issue_dst_base_i),
    .dma_issue_tag_candidate(dma_issue_tag_candidate_i),
    .revb_noc_rx_valid(revb_noc_rx_valid_i),
    .revb_noc_rx_ready(revb_noc_rx_ready_o),
    .revb_noc_rx_opcode(revb_noc_rx_opcode_i),
    .revb_noc_rx_addr(revb_noc_rx_addr_i),
    .revb_noc_rx_data(revb_noc_rx_data_i),
    .revb_noc_rx_tag(revb_noc_rx_tag_i),
    .revb_noc_rx_requester(revb_noc_rx_requester_i),
    .revb_noc_rx_path(revb_noc_rx_path_i),
    .revb_noc_rx_read_req_valid(revb_noc_rx_read_req_valid_i),
    .revb_noc_rx_read_req_ready(revb_noc_rx_read_req_ready_o),
    .revb_noc_rx_read_req_addr(revb_noc_rx_read_req_addr_i),
    .revb_noc_rx_read_req_tag(revb_noc_rx_read_req_tag_i),
    .revb_noc_rx_read_req_requester(revb_noc_rx_read_req_requester_i),
    .revb_noc_rx_read_req_path(revb_noc_rx_read_req_path_i),
    .revb_noc_tx_read_rsp_valid(revb_noc_tx_read_rsp_valid_o),
    .revb_noc_tx_read_rsp_ready(revb_noc_tx_read_rsp_ready_i),
    .revb_noc_tx_read_rsp_opcode(revb_noc_tx_read_rsp_opcode_o),
    .revb_noc_tx_read_rsp_data(revb_noc_tx_read_rsp_data_o),
    .revb_noc_tx_read_rsp_tag(revb_noc_tx_read_rsp_tag_o),
    .revb_noc_tx_read_rsp_requester(revb_noc_tx_read_rsp_requester_o),
    .revb_noc_tx_read_rsp_path(revb_noc_tx_read_rsp_path_o),
    .remote_rd_enq_valid(remote_rd_enq_valid_i),
    .remote_rd_enq_ready(remote_rd_enq_ready_o),
    .remote_rd_enq_bank_idx(remote_rd_enq_bank_idx_i),
    .remote_rd_enq_line_addr(remote_rd_enq_line_addr_i),
    .remote_rd_enq_tag(remote_rd_enq_tag_i),
    .remote_rd_enq_requester(remote_rd_enq_requester_i),
    .remote_rd_enq_path(remote_rd_enq_path_i),
    .remote_rd_rsp_valid(remote_rd_rsp_valid_o),
    .remote_rd_rsp_ready(remote_rd_rsp_ready_i),
    .remote_rd_rsp_data(remote_rd_rsp_data_o),
    .remote_rd_rsp_tag(remote_rd_rsp_tag_o),
    .remote_rd_rsp_requester(remote_rd_rsp_requester_o),
    .remote_rd_rsp_path(remote_rd_rsp_path_o),
    .pe_rsp_valid(smu_pe_rsp_valid),
    .pe_rsp_kind(smu_pe_rsp_kind),
    .pe_rsp_err(smu_pe_rsp_err),
    .pe_rsp_data(smu_pe_rsp_data),
    .pe_rsp_tag(smu_pe_rsp_tag),
    .wbq_commit_valid(wbq_commit_valid),
    .wbq_commit_addr(wbq_commit_addr),
    .wbq_commit_data(wbq_commit_data)
  );

endmodule : single_cluster_integration_top
