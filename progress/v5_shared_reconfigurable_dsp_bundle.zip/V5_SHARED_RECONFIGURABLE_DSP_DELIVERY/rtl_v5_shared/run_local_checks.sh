#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 rtl_structural_check.py
if grep -RInE '\b(mm_operand_buffer|fft_twiddle_expansion_unit|module param_rf|module qr_pivot_preload|twiddle_service_unit)\b' --include='*.sv' .; then
  echo 'ERROR: removed workload-specific module still referenced' >&2
  exit 1
fi
echo V5_LOCAL_STRUCTURAL_CHECK_PASS
