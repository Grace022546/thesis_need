#!/usr/bin/env python3
from __future__ import annotations
import re, json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
files=sorted(ROOT.glob('*.sv'))

def strip(text:str)->str:
    text=re.sub(r'/\*.*?\*/','',text,flags=re.S)
    text=re.sub(r'//.*','',text)
    text=re.sub(r'"(?:\\.|[^"\\])*"','""',text)
    return text

def balanced(t):
    pairs={'(':')','[':']','{':'}'}; stack=[]
    for i,ch in enumerate(t):
        if ch in pairs: stack.append((ch,i))
        elif ch in pairs.values():
            if not stack or pairs[stack[-1][0]]!=ch: return False,f'unmatched {ch} at {i}'
            stack.pop()
    return (not stack, '' if not stack else f'unclosed {stack[-1]}')

def modules_and_ports(t):
    out={}
    pat=re.compile(r'\bmodule\s+(\w+)\s*(?:#\s*\(.*?\)\s*)?\((.*?)\)\s*;',re.S)
    for m in pat.finditer(t):
        name=m.group(1); hdr=m.group(2)
        ports=set(re.findall(r'\b(?:input|output|inout)\b(?:\s+(?:wire|logic|reg|var|signed|unsigned|\[[^\]]+\]|\w+::\w+))*\s+(\w+)\b',hdr))
        # More tolerant: grab last identifier of comma-separated declarations.
        for piece in hdr.split(','):
            ids=re.findall(r'\b([A-Za-z_]\w*)\b',piece)
            if ids:
                cand=ids[-1]
                if cand not in {'input','output','inout','logic','wire','reg','signed','unsigned'}:
                    ports.add(cand)
        out[name]=ports
    return out
texts={f:strip(f.read_text(errors='ignore')) for f in files}
mods={}
for f,t in texts.items():
    for n,p in modules_and_ports(t).items():
        if n in mods: raise SystemExit(f'duplicate module {n}: {mods[n][0]} and {f}')
        mods[n]=(f,p)

builtin={'if','for','case','while','assign','always_comb','always_ff','always','function','task','return','else','begin','end','unique','priority','generate'}
instances=[]; errors=[]
inst_re=re.compile(r'(?m)^\s*(\w+)\s*(?:#\s*\(.*?\)\s*)?(\w+)\s*\((.*?)\)\s*;',re.S)
for f,t in texts.items():
    ok,msg=balanced(t)
    if not ok: errors.append(f'{f.name}: {msg}')
    if len(re.findall(r'\bmodule\b',t))!=len(re.findall(r'\bendmodule\b',t)):
        errors.append(f'{f.name}: module/endmodule count mismatch')
    for m in inst_re.finditer(t):
        typ,inst,body=m.group(1),m.group(2),m.group(3)
        if typ in builtin or typ in {'module'}: continue
        if typ not in mods: continue
        named=set(re.findall(r'\.(\w+)\s*\(',body))
        allowed=mods[typ][1]
        unknown=sorted(named-allowed)
        if unknown: errors.append(f'{f.name}:{inst} ({typ}) unknown ports {unknown}')
        instances.append({'file':f.name,'module':typ,'instance':inst,'named_ports':len(named)})

required={'cgra_rtl_pkg','context_entry_pkg'}
report={'files':[f.name for f in files],'modules':sorted(mods),'instances':instances,'errors':errors}
(ROOT/'rtl_structural_check.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
raise SystemExit(1 if errors else 0)
