`timescale 1ns/1ps
import cgra_rtl_pkg::*;

// MM has no private operand memory. A is read from SharedVectorRF. B remains
// resident in local SRAM and is prefetched into the generic 4-bank staging RF.
module mm_b_prefetch_controller #(
  parameter int P_VECTOR_W=VECTOR_W
)(
  input logic clk_i,input logic rst_ni,
  input logic mm_mac_valid_i,input logic issue_fire_i,
  input logic [EXEC_IMM_W-1:0] immediate_i,
  input logic [CTX_W-1:0] context_i,
  input logic shared_a_valid_i,input logic [P_VECTOR_W-1:0] shared_a_i,
  output logic operands_ready_o,output logic [P_VECTOR_W-1:0] a_vector_o,

  output logic [N_PE-1:0] b_req_valid_o,input logic [N_PE-1:0] b_req_ready_i,
  output logic [N_PE-1:0][LOCAL_ADDR_W-1:0] b_req_addr_o,
  output logic [N_PE-1:0][3:0] b_req_tag_o,
  input logic [N_PE-1:0] b_rsp_valid_i,input logic [N_PE-1:0] b_rsp_err_i,
  input logic [N_PE-1:0] b_rsp_kind_i,input logic [N_PE-1:0][P_VECTOR_W-1:0] b_rsp_data_i,
  input logic [N_PE-1:0][3:0] b_rsp_tag_i,

  output logic [N_PE-1:0] stage_wr_valid_o,input logic [N_PE-1:0] stage_wr_ready_i,
  output logic [N_PE-1:0] stage_wr_entry_o,
  output logic [N_PE-1:0][P_VECTOR_W-1:0] stage_wr_data_o,
  output logic [N_PE-1:0] stage_rd_valid_o,input logic [N_PE-1:0] stage_rd_data_valid_i,
  output logic [N_PE-1:0] stage_rd_entry_o,output logic [N_PE-1:0] stage_rd_consume_o,
  input logic [N_PE-1:0][P_VECTOR_W-1:0] stage_rd_data_i,
  output logic [N_PE*P_VECTOR_W-1:0] b_vectors_o
);
  localparam logic [3:0] RSP_TAG=4'hE;
  logic active_q; logic [N_PE-1:0] req_sent_q,rsp_seen_q;
  logic [10:0] base_vec_q; logic [2:0] k_group_q; logic context_entry_q;
  logic [10:0] context_base;
  assign context_base={context_i[CTX_RSVD_AGU_LSB +:3],context_i[CTX_DMA_LEN_LSB +:8]};

  always_comb begin
    a_vector_o=shared_a_i;
    b_req_valid_o='0;b_req_addr_o='0;b_req_tag_o='0;
    for(int p=0;p<N_PE;p++) begin
      b_req_valid_o[p]=active_q && !req_sent_q[p];
      b_req_addr_o[p]=LOCAL_ADDR_W'((base_vec_q+k_group_q*N_PE+p)*(VECTOR_W/8));
      b_req_tag_o[p]=RSP_TAG;
    end
    stage_wr_valid_o='0;stage_wr_entry_o={N_PE{context_entry_q}};stage_wr_data_o='0;
    for(int p=0;p<N_PE;p++) begin
      stage_wr_valid_o[p]=b_rsp_valid_i[p]&&!b_rsp_err_i[p]&&!b_rsp_kind_i[p]&&(b_rsp_tag_i[p]==RSP_TAG);
      stage_wr_data_o[p]=b_rsp_data_i[p];
    end
    stage_rd_valid_o={N_PE{active_q}}; stage_rd_entry_o={N_PE{context_entry_q}};
    stage_rd_consume_o={N_PE{issue_fire_i}};
    b_vectors_o='0;
    for(int p=0;p<N_PE;p++) b_vectors_o[p*P_VECTOR_W +: P_VECTOR_W]=stage_rd_data_i[p];
    operands_ready_o=mm_mac_valid_i && shared_a_valid_i && active_q && (&rsp_seen_q) &&
                     (&stage_rd_data_valid_i);
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if(!rst_ni) begin
      active_q<=1'b0; req_sent_q<='0; rsp_seen_q<='0; base_vec_q<='0;
      k_group_q<='0; context_entry_q<=1'b0;
    end else begin
      if(mm_mac_valid_i && !active_q) begin
        active_q<=1'b1; req_sent_q<='0; rsp_seen_q<='0;
        base_vec_q<=context_base; k_group_q<=immediate_i[12:10];
        context_entry_q<=immediate_i[29];
      end
      for(int p=0;p<N_PE;p++) begin
        if(b_req_valid_o[p] && b_req_ready_i[p]) req_sent_q[p]<=1'b1;
        if(stage_wr_valid_o[p] && stage_wr_ready_i[p]) rsp_seen_q[p]<=1'b1;
      end
      if(issue_fire_i) begin active_q<=1'b0; req_sent_q<='0; rsp_seen_q<='0; end
    end
  end
endmodule
