`timescale 1ns/1ps
import cgra_rtl_pkg::*;

// Storage-free QR preload/control. Pivot vectors are written directly into
// SharedOperandStaging entry0; target vectors arrive in entry1 from SMU/WBQ.
// No QR-private 4-vector cache or interleave register array is instantiated.
module qr_preload_controller #(
  parameter int P_VECTOR_W=VECTOR_W
)(
  input logic clk_i,input logic rst_ni,
  input logic start_valid_i,output logic start_ready_o,
  input logic [QR_ROT_W-1:0] rotation_id_i,input logic [QR_ROW_W-1:0] pivot_row_i,
  output logic mem_req_valid_o,input logic mem_req_ready_i,
  output logic mem_req_write_o,output logic [LOCAL_ADDR_W-1:0] mem_req_addr_o,
  input logic mem_rsp_valid_i,input logic [P_VECTOR_W-1:0] mem_rsp_data_i,

  output logic [N_PE-1:0] stage_wr_valid_o,input logic [N_PE-1:0] stage_wr_ready_i,
  output logic [N_PE-1:0] stage_wr_entry_o,
  output logic [N_PE-1:0][P_VECTOR_W-1:0] stage_wr_data_o,
  input logic [N_PE-1:0][1:0] stage_peek_valid_i,
  input logic [N_PE-1:0][1:0][P_VECTOR_W-1:0] stage_peek_data_i,

  input logic cordic_pair_req_i,input logic [QR_ROT_W-1:0] cordic_rotation_id_i,
  input logic [QR_ROW_W-1:0] cordic_column_i,
  output logic cordic_pair_valid_o,
  output logic signed [LANE_W-1:0] cordic_pivot_o,cordic_target_o,

  input logic crot_req_i,input logic crot_entity_qt_i,
  output logic crot_rows_valid_o,
  output logic [N_PE*P_VECTOR_W-1:0] crot_pivot_rows_o,crot_target_rows_o,
  output logic preload_busy_o,output logic preload_valid_o,
  output logic [QR_ROT_W-1:0] preload_rotation_id_o
);
  typedef enum logic [1:0] {Q_IDLE,Q_REQ,Q_WAIT,Q_DONE} qstate_e;
  qstate_e state_q; logic [1:0] vec_q; logic [QR_ROT_W-1:0] rot_q; logic [QR_ROW_W-1:0] row_q;
  logic [1:0] cordic_vec; logic [2:0] cordic_lane;
  assign start_ready_o=(state_q==Q_IDLE);
  assign preload_busy_o=(state_q!=Q_IDLE)&&(state_q!=Q_DONE);
  assign preload_valid_o=(state_q==Q_DONE); assign preload_rotation_id_o=rot_q;
  assign mem_req_valid_o=(state_q==Q_REQ); assign mem_req_write_o=1'b0;
  // Four pivot vectors: R vec0/1 then QT vec0/1.
  always_comb begin
    logic [10:0] base_vec;
    base_vec=(vec_q<2) ? (QR_R_BASE_VEC+row_q*QR_ROW_SLOT_STRIDE_VECS+vec_q)
                       : (QR_QT_BASE_VEC+row_q*QR_ROW_SLOT_STRIDE_VECS+(vec_q-2));
    mem_req_addr_o=LOCAL_ADDR_W'(base_vec*(VECTOR_W/8));
  end

  always_comb begin
    stage_wr_valid_o='0;stage_wr_entry_o='0;stage_wr_data_o='0;
    if(state_q==Q_WAIT && mem_rsp_valid_i) begin
      stage_wr_valid_o[vec_q]=1'b1; stage_wr_entry_o[vec_q]=1'b0;
      stage_wr_data_o[vec_q]=mem_rsp_data_i;
    end
  end

  assign cordic_vec=cordic_column_i[3] ? 2'd1 : 2'd0;
  assign cordic_lane=cordic_column_i[2:0];
  always_comb begin
    cordic_pair_valid_o=1'b0;cordic_pivot_o='0;cordic_target_o='0;
    if(cordic_pair_req_i && cordic_rotation_id_i==rot_q &&
       stage_peek_valid_i[cordic_vec][0] && stage_peek_valid_i[cordic_vec][1]) begin
      cordic_pair_valid_o=1'b1;
      cordic_pivot_o=stage_peek_data_i[cordic_vec][0][cordic_lane*LANE_W +: LANE_W];
      cordic_target_o=stage_peek_data_i[cordic_vec][1][cordic_lane*LANE_W +: LANE_W];
    end
  end

  always_comb begin
    int src_bank,src_lane;
    crot_pivot_rows_o='0;crot_target_rows_o='0;
    crot_rows_valid_o=crot_req_i;
    for(int p=0;p<N_PE;p++) begin
      for(int k=0;k<LANES/2;k++) begin
        src_bank=(crot_entity_qt_i ? 2 : 0)+((p*4+k)>=8);
        src_lane=(p*4+k)%8;
        crot_pivot_rows_o[p*P_VECTOR_W+k*LANE_W +: LANE_W]=
          stage_peek_data_i[src_bank][0][src_lane*LANE_W +: LANE_W];
        crot_target_rows_o[p*P_VECTOR_W+k*LANE_W +: LANE_W]=
          stage_peek_data_i[src_bank][1][src_lane*LANE_W +: LANE_W];
        crot_rows_valid_o &= stage_peek_valid_i[src_bank][0]&&stage_peek_valid_i[src_bank][1];
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if(!rst_ni) begin state_q<=Q_IDLE;vec_q<='0;rot_q<='0;row_q<='0;end
    else case(state_q)
      Q_IDLE: if(start_valid_i) begin state_q<=Q_REQ;vec_q<=2'd0;rot_q<=rotation_id_i;row_q<=pivot_row_i;end
      Q_REQ: if(mem_req_valid_o&&mem_req_ready_i) state_q<=Q_WAIT;
      Q_WAIT: if(mem_rsp_valid_i&&stage_wr_ready_i[vec_q]) begin
        if(vec_q==2'd3) state_q<=Q_DONE; else begin vec_q<=vec_q+1'b1;state_q<=Q_REQ;end
      end
      Q_DONE: if(!start_valid_i) state_q<=Q_IDLE;
      default: state_q<=Q_IDLE;
    endcase
  end
endmodule
