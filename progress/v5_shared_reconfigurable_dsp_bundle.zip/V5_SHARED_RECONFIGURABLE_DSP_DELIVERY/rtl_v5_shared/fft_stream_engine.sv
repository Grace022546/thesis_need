`timescale 1ns/1ps
import cgra_rtl_pkg::*;

// FFT stream controller with no FFT-only arithmetic.  The local CORDIC supplies
// W0 and step S.  Existing PE CMUL datapaths execute two recurrence waves:
//   wave0: PE0=W0*S=W1, PE1=S*S=S2
//   wave1: PE0=W0*S2=W2, PE1=W1*S2=W3
// The packed {W0,W1,W2,W3} vector is written to SharedVectorRF. DMA/input fill
// may progress concurrently, but recurrence and butterfly never use the PEs in
// the same cycle.
module fft_stream_engine #(
  parameter int P_VECTOR_W=VECTOR_W,
  parameter int P_FIFO_SLOTS=2
)(
  input logic clk_i,input logic rst_ni,

  input logic task_valid_i,output logic task_ready_o,output logic task_slot_o,
  input logic [PARAM_ID_W-1:0] task_param_pid_i,
  input logic signed [15:0] task_seed_re_i,task_seed_im_i,
  input logic signed [15:0] task_step_re_i,task_step_im_i,
  input logic [LOCAL_ADDR_W-1:0] task_dst0_addr_i,task_dst1_addr_i,

  input logic input_fill_valid_i,output logic input_fill_ready_o,
  input logic input_fill_slot_i,input logic input_fill_vector_i,
  input logic [P_VECTOR_W-1:0] input_fill_data_i,

  // Shared operand staging write/read interface. FFT uses bank0/1, entry=slot.
  output logic [1:0] stage_wr_valid_o,input logic [1:0] stage_wr_ready_i,
  output logic [1:0] stage_wr_entry_o,
  output logic [1:0][P_VECTOR_W-1:0] stage_wr_data_o,
  output logic [1:0] stage_rd_valid_o,input logic [1:0] stage_rd_data_valid_i,
  output logic [1:0] stage_rd_entry_o,output logic [1:0] stage_rd_consume_o,
  input logic [1:0][P_VECTOR_W-1:0] stage_rd_data_i,

  // SharedVectorRF write/read. The cluster arbitrates this with CORDIC/QR/MM.
  output logic svrf_wr_valid_o,input logic svrf_wr_ready_i,
  output logic [PARAM_ID_W-1:0] svrf_wr_pid_o,
  output logic [P_VECTOR_W-1:0] svrf_wr_data_o,
  output logic svrf_rd_valid_o,input logic svrf_rd_ready_i,
  output logic [PARAM_ID_W-1:0] svrf_rd_pid_o,
  input logic [P_VECTOR_W-1:0] svrf_rd_data_i,

  // Unified existing-PE request. kind: 0=recurrence wave0, 1=wave1, 2=butterfly.
  output logic pe_req_valid_o,input logic pe_req_ready_i,
  output logic [1:0] pe_req_kind_o,output logic pe_req_slot_o,
  output logic [N_PE-1:0] pe_req_active_mask_o,
  output logic pe_req_cmul_mul_only_o,
  output logic [N_PE*P_VECTOR_W-1:0] pe_req_a_o,
  output logic [N_PE*P_VECTOR_W-1:0] pe_req_b_o,
  output logic [N_PE*P_VECTOR_W-1:0] pe_req_twiddle_o,
  input logic pe_rsp_valid_i,output logic pe_rsp_ready_o,
  input logic [1:0] pe_rsp_kind_i,input logic pe_rsp_slot_i,
  input logic [N_PE*P_VECTOR_W-1:0] pe_rsp_data_i,

  // Results already pass through the shared RU in the integration wrapper.
  output logic result_valid_o,input logic result_ready_i,
  output logic [P_VECTOR_W-1:0] result_vec0_o,result_vec1_o,
  output logic [LOCAL_ADDR_W-1:0] result_dst0_addr_o,result_dst1_addr_o,

  input logic stage_close_i,output logic stage_done_o,output logic busy_o
);
  typedef enum logic [2:0] {S_FREE,S_REC0,S_REC1,S_RFWRITE,S_READY,S_BFLY,S_RESULT} state_e;
  state_e state_q[2];
  logic [1:0] input_valid_q[2];
  logic [PARAM_ID_W-1:0] pid_q[2];
  logic signed [15:0] w0_re_q[2],w0_im_q[2],step_re_q[2],step_im_q[2];
  logic signed [15:0] w1_re_q[2],w1_im_q[2],s2_re_q[2],s2_im_q[2];
  logic signed [15:0] w2_re_q[2],w2_im_q[2],w3_re_q[2],w3_im_q[2];
  logic [LOCAL_ADDR_W-1:0] dst0_q[2],dst1_q[2];
  logic [P_VECTOR_W-1:0] result0_q[2],result1_q[2];
  logic pe_inflight_q; logic [1:0] pe_kind_q; logic pe_slot_q;
  logic stage_close_q;
  logic free_found,free_slot,issue_found,issue_slot,result_found,result_slot;

  always_comb begin
    free_found=1'b0; free_slot=1'b0;
    issue_found=1'b0; issue_slot=1'b0;
    result_found=1'b0; result_slot=1'b0;
    for(int s=0;s<2;s++) begin
      if(!free_found && state_q[s]==S_FREE) begin free_found=1'b1; free_slot=s[0]; end
      if(!issue_found && (state_q[s]==S_REC0 || state_q[s]==S_REC1 ||
                          (state_q[s]==S_READY && (&input_valid_q[s])))) begin
        issue_found=1'b1; issue_slot=s[0];
      end
      if(!result_found && state_q[s]==S_RESULT) begin result_found=1'b1; result_slot=s[0]; end
    end
  end

  assign task_ready_o=free_found;
  assign task_slot_o=free_slot;
  assign input_fill_ready_o=stage_wr_ready_i[input_fill_vector_i];
  always_comb begin
    stage_wr_valid_o='0;stage_wr_entry_o='0;stage_wr_data_o='0;
    stage_wr_valid_o[input_fill_vector_i]=input_fill_valid_i;
    stage_wr_entry_o[input_fill_vector_i]=input_fill_slot_i;
    stage_wr_data_o[input_fill_vector_i]=input_fill_data_i;
  end

  always_comb begin
    stage_rd_valid_o='0; stage_rd_entry_o='0; stage_rd_consume_o='0;
    svrf_wr_valid_o=1'b0; svrf_wr_pid_o='0; svrf_wr_data_o='0;
    svrf_rd_valid_o=1'b0; svrf_rd_pid_o='0;
    pe_req_valid_o=1'b0; pe_req_kind_o='0; pe_req_slot_o=issue_slot;
    pe_req_active_mask_o='0; pe_req_cmul_mul_only_o=1'b0;
    pe_req_a_o='0; pe_req_b_o='0; pe_req_twiddle_o='0;

    for(int s=0;s<2;s++) if(state_q[s]==S_RFWRITE) begin
      svrf_wr_valid_o=1'b1; svrf_wr_pid_o=pid_q[s];
      svrf_wr_data_o[0*LANE_W +: LANE_W]={{(LANE_W-16){w0_re_q[s][15]}},w0_re_q[s]};
      svrf_wr_data_o[1*LANE_W +: LANE_W]={{(LANE_W-16){w0_im_q[s][15]}},w0_im_q[s]};
      svrf_wr_data_o[2*LANE_W +: LANE_W]={{(LANE_W-16){w1_re_q[s][15]}},w1_re_q[s]};
      svrf_wr_data_o[3*LANE_W +: LANE_W]={{(LANE_W-16){w1_im_q[s][15]}},w1_im_q[s]};
      svrf_wr_data_o[4*LANE_W +: LANE_W]={{(LANE_W-16){w2_re_q[s][15]}},w2_re_q[s]};
      svrf_wr_data_o[5*LANE_W +: LANE_W]={{(LANE_W-16){w2_im_q[s][15]}},w2_im_q[s]};
      svrf_wr_data_o[6*LANE_W +: LANE_W]={{(LANE_W-16){w3_re_q[s][15]}},w3_re_q[s]};
      svrf_wr_data_o[7*LANE_W +: LANE_W]={{(LANE_W-16){w3_im_q[s][15]}},w3_im_q[s]};
    end

    if(issue_found && !pe_inflight_q) begin
      pe_req_valid_o=1'b1; pe_req_slot_o=issue_slot;
      case(state_q[issue_slot])
        S_REC0: begin
          pe_req_kind_o=2'd0; pe_req_active_mask_o=4'b0011; pe_req_cmul_mul_only_o=1'b1;
          pe_req_a_o[0*P_VECTOR_W + 0*LANE_W +: 16]=w0_re_q[issue_slot];
          pe_req_a_o[0*P_VECTOR_W + 1*LANE_W +: 16]=w0_im_q[issue_slot];
          pe_req_b_o[0*P_VECTOR_W + 0*LANE_W +: 16]=step_re_q[issue_slot];
          pe_req_b_o[0*P_VECTOR_W + 1*LANE_W +: 16]=step_im_q[issue_slot];
          pe_req_a_o[1*P_VECTOR_W + 0*LANE_W +: 16]=step_re_q[issue_slot];
          pe_req_a_o[1*P_VECTOR_W + 1*LANE_W +: 16]=step_im_q[issue_slot];
          pe_req_b_o[1*P_VECTOR_W + 0*LANE_W +: 16]=step_re_q[issue_slot];
          pe_req_b_o[1*P_VECTOR_W + 1*LANE_W +: 16]=step_im_q[issue_slot];
        end
        S_REC1: begin
          pe_req_kind_o=2'd1; pe_req_active_mask_o=4'b0011; pe_req_cmul_mul_only_o=1'b1;
          pe_req_a_o[0*P_VECTOR_W + 0*LANE_W +: 16]=w0_re_q[issue_slot];
          pe_req_a_o[0*P_VECTOR_W + 1*LANE_W +: 16]=w0_im_q[issue_slot];
          pe_req_b_o[0*P_VECTOR_W + 0*LANE_W +: 16]=s2_re_q[issue_slot];
          pe_req_b_o[0*P_VECTOR_W + 1*LANE_W +: 16]=s2_im_q[issue_slot];
          pe_req_a_o[1*P_VECTOR_W + 0*LANE_W +: 16]=w1_re_q[issue_slot];
          pe_req_a_o[1*P_VECTOR_W + 1*LANE_W +: 16]=w1_im_q[issue_slot];
          pe_req_b_o[1*P_VECTOR_W + 0*LANE_W +: 16]=s2_re_q[issue_slot];
          pe_req_b_o[1*P_VECTOR_W + 1*LANE_W +: 16]=s2_im_q[issue_slot];
        end
        default: begin
          pe_req_kind_o=2'd2; pe_req_active_mask_o='1; pe_req_cmul_mul_only_o=1'b0;
          stage_rd_valid_o=2'b11; stage_rd_entry_o={2{issue_slot}};
          svrf_rd_valid_o=1'b1; svrf_rd_pid_o=pid_q[issue_slot];
          // One architectural input vector contains four complex samples.
          // PE p receives sample p from both input vectors and twiddle Wp from
          // the single SharedVectorRF read.  No controller-private twiddle copy
          // participates in butterfly arithmetic.
          for(int p=0;p<N_PE;p++) begin
            pe_req_a_o[p*P_VECTOR_W + 0*LANE_W +: LANE_W] =
              stage_rd_data_i[0][(2*p+0)*LANE_W +: LANE_W];
            pe_req_a_o[p*P_VECTOR_W + 1*LANE_W +: LANE_W] =
              stage_rd_data_i[0][(2*p+1)*LANE_W +: LANE_W];
            pe_req_b_o[p*P_VECTOR_W + 0*LANE_W +: LANE_W] =
              stage_rd_data_i[1][(2*p+0)*LANE_W +: LANE_W];
            pe_req_b_o[p*P_VECTOR_W + 1*LANE_W +: LANE_W] =
              stage_rd_data_i[1][(2*p+1)*LANE_W +: LANE_W];
            pe_req_twiddle_o[p*P_VECTOR_W + 0*LANE_W +: LANE_W] =
              svrf_rd_data_i[(2*p+0)*LANE_W +: LANE_W];
            pe_req_twiddle_o[p*P_VECTOR_W + 1*LANE_W +: LANE_W] =
              svrf_rd_data_i[(2*p+1)*LANE_W +: LANE_W];
          end
          if(!(stage_rd_data_valid_i==2'b11 && svrf_rd_ready_i)) pe_req_valid_o=1'b0;
          if(pe_req_valid_o && pe_req_ready_i) stage_rd_consume_o=2'b11;
        end
      endcase
    end
  end

  assign pe_rsp_ready_o=1'b1;
  assign result_valid_o=result_found;
  assign result_vec0_o=result0_q[result_slot]; assign result_vec1_o=result1_q[result_slot];
  assign result_dst0_addr_o=dst0_q[result_slot]; assign result_dst1_addr_o=dst1_q[result_slot];
  assign busy_o=(state_q[0]!=S_FREE)||(state_q[1]!=S_FREE)||pe_inflight_q;
  assign stage_done_o=stage_close_q && !busy_o;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if(!rst_ni) begin
      stage_close_q<=1'b0; pe_inflight_q<=1'b0; pe_kind_q<='0; pe_slot_q<=1'b0;
      for(int s=0;s<2;s++) begin state_q[s]<=S_FREE; input_valid_q[s]<='0; result0_q[s]<='0; result1_q[s]<='0; end
    end else begin
      if(stage_close_i) stage_close_q<=1'b1;
      if(stage_done_o) stage_close_q<=1'b0;
      if(task_valid_i && task_ready_o) begin
        state_q[free_slot]<=S_REC0; input_valid_q[free_slot]<='0; pid_q[free_slot]<=task_param_pid_i;
        w0_re_q[free_slot]<=task_seed_re_i; w0_im_q[free_slot]<=task_seed_im_i;
        step_re_q[free_slot]<=task_step_re_i; step_im_q[free_slot]<=task_step_im_i;
        dst0_q[free_slot]<=task_dst0_addr_i; dst1_q[free_slot]<=task_dst1_addr_i;
      end
      if(input_fill_valid_i && input_fill_ready_o) input_valid_q[input_fill_slot_i][input_fill_vector_i]<=1'b1;
      for(int s=0;s<2;s++) if(state_q[s]==S_RFWRITE && svrf_wr_valid_o && svrf_wr_ready_i) state_q[s]<=S_READY;
      if(pe_req_valid_o && pe_req_ready_i) begin
        pe_inflight_q<=1'b1; pe_kind_q<=pe_req_kind_o; pe_slot_q<=pe_req_slot_o;
        if(pe_req_kind_o==2'd0) state_q[pe_req_slot_o]<=S_REC0;
        else if(pe_req_kind_o==2'd1) state_q[pe_req_slot_o]<=S_REC1;
        else state_q[pe_req_slot_o]<=S_BFLY;
      end
      if(pe_rsp_valid_i && pe_rsp_ready_o) begin
        pe_inflight_q<=1'b0;
        case(pe_rsp_kind_i)
          2'd0: begin
            w1_re_q[pe_rsp_slot_i]<=pe_rsp_data_i[0*P_VECTOR_W + 0*LANE_W +: 16];
            w1_im_q[pe_rsp_slot_i]<=pe_rsp_data_i[0*P_VECTOR_W + 1*LANE_W +: 16];
            s2_re_q[pe_rsp_slot_i]<=pe_rsp_data_i[1*P_VECTOR_W + 0*LANE_W +: 16];
            s2_im_q[pe_rsp_slot_i]<=pe_rsp_data_i[1*P_VECTOR_W + 1*LANE_W +: 16];
            state_q[pe_rsp_slot_i]<=S_REC1;
          end
          2'd1: begin
            w2_re_q[pe_rsp_slot_i]<=pe_rsp_data_i[0*P_VECTOR_W + 0*LANE_W +: 16];
            w2_im_q[pe_rsp_slot_i]<=pe_rsp_data_i[0*P_VECTOR_W + 1*LANE_W +: 16];
            w3_re_q[pe_rsp_slot_i]<=pe_rsp_data_i[1*P_VECTOR_W + 0*LANE_W +: 16];
            w3_im_q[pe_rsp_slot_i]<=pe_rsp_data_i[1*P_VECTOR_W + 1*LANE_W +: 16];
            state_q[pe_rsp_slot_i]<=S_RFWRITE;
          end
          default: begin
            // Shared RU packs PE outputs; wrapper returns its two vectors here.
            result0_q[pe_rsp_slot_i]<=pe_rsp_data_i[0*P_VECTOR_W +: P_VECTOR_W];
            result1_q[pe_rsp_slot_i]<=pe_rsp_data_i[1*P_VECTOR_W +: P_VECTOR_W];
            input_valid_q[pe_rsp_slot_i]<='0; state_q[pe_rsp_slot_i]<=S_RESULT;
          end
        endcase
      end
      if(result_valid_o && result_ready_i) state_q[result_slot]<=S_FREE;
    end
  end
endmodule
