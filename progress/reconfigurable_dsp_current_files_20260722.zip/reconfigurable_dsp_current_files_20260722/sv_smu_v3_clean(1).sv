`timescale 1ns/1ps
// ============================================================================
// SMU v1.4 RevB Lean Performance RTL Functional Closure Cleanup Checkpoint RTL-CLEAN-1D
// ----------------------------------------------------------------------------
// This source is the synthesis-facing Lean Performance RTL checkpoint.  The
// functional datapath is intentionally preserved in this boundary cleanup pass;
// only module names, comments, and ownership labels are normalized to match the
// SMU_v1_4_RevB_Lean_Performance_RTL_Architecture_Note_v2 document.
//
// Boundary classes used below:
//   FORMAL RTL PATH       : intended architectural/module-boundary interface.
//   COMPAT / ADAPTER PATH : legacy or test-adapter interface kept for current
//                           C++/Verilator integration.
//   LOCAL OBSERVATION PATH: internal-only compatibility/observation state; not
//                           a final Lean Performance module boundary.
//
// LP-3BE keeps the LP-3BA functional closure datapath and removes only
// host-side redundant diagnostic code in the paired C++ regression driver.
// ============================================================================
module sv_bank_wrapper_64 (
    input  logic         clk,
    input  logic         rst_n,
    input  logic         portA_req_valid,
    input  logic         portA_req_write,
    input  logic [7:0]   portA_addr,
    input  logic [63:0]  portA_wdata,
    input  logic [63:0]  portA_wbem,
    output logic         portA_req_accepted,
    input  logic         portB_req_valid,
    input  logic         portB_req_write,
    input  logic [7:0]   portB_addr,
    input  logic [63:0]  portB_wdata,
    input  logic [63:0]  portB_wbem,
    output logic         portB_req_accepted,
    output logic         portA_rsp_valid,
    output logic [63:0]  portA_rdata,
    output logic         portB_rsp_valid,
    output logic [63:0]  portB_rdata,
    output logic         hazard_same_addr,
    output logic         hazard_blocked
);
    logic [7:0]  AA;
    logic [63:0] DA;
    logic [63:0] BWEBA;
    logic        WEBA;
    logic        CEBA;
    logic        CLKA;
    logic [63:0] QA;
    logic [7:0]  AB;
    logic [63:0] DB;
    logic [63:0] BWEBB;
    logic        WEBB;
    logic        CEBB;
    logic        CLKB;
    logic [63:0] QB;
    logic        SLP;
    logic        DSLP;
    logic        SD;
    logic [1:0]  WTSEL;
    logic [1:0]  RTSEL;
    logic [7:0]  AMA;
    logic [63:0] DMA;
    logic [63:0] BWEBMA;
    logic        WEBMA;
    logic        CEBMA;
    logic [7:0]  AMB;
    logic [63:0] DMB;
    logic [63:0] BWEBMB;
    logic        WEBMB;
    logic        CEBMB;
    logic        BIST;
    logic        CLKM;
    logic same_addr;
    logic has_write;
    logic allow_dual_read;
    logic allow_parallel;
    logic block_due_to_same_addr_write;
    logic a_accept_comb, b_accept_comb;
    logic a_read_accepted_q, b_read_accepted_q;
    assign CLKA = clk;
    assign CLKB = clk;
    always_comb begin
        SLP   = 1'b0;
        DSLP  = 1'b0;
        SD    = 1'b0;
        WTSEL = 2'b01;
        RTSEL = 2'b01;
        AMA    = 8'h00;
        DMA    = 64'h0;
        BWEBMA = {64{1'b1}};
        WEBMA  = 1'b1;
        CEBMA  = 1'b1;
        AMB    = 8'h00;
        DMB    = 64'h0;
        BWEBMB = {64{1'b1}};
        WEBMB  = 1'b1;
        CEBMB  = 1'b1;
        BIST   = 1'b0;
        CLKM   = 1'b0;
    end
    always_comb begin
        same_addr = portA_req_valid && portB_req_valid && (portA_addr == portB_addr);
        has_write = (portA_req_valid && portA_req_write) ||
                    (portB_req_valid && portB_req_write);
        allow_dual_read = same_addr &&
                          portA_req_valid && !portA_req_write &&
                          portB_req_valid && !portB_req_write;
        allow_parallel = (!same_addr) &&
                         (portA_req_valid || portB_req_valid);
        block_due_to_same_addr_write = same_addr && has_write;
        hazard_same_addr = same_addr;
        hazard_blocked   = block_due_to_same_addr_write;
    end
    always_comb begin
        a_accept_comb = 1'b0;
        b_accept_comb = 1'b0;
        unique case ({portA_req_valid, portB_req_valid})
            2'b00: begin
                a_accept_comb = 1'b0;
                b_accept_comb = 1'b0;
            end
            2'b10: begin
                a_accept_comb = 1'b1;
                b_accept_comb = 1'b0;
            end
            2'b01: begin
                a_accept_comb = 1'b0;
                b_accept_comb = 1'b1;
            end
            2'b11: begin
                if (allow_dual_read) begin
                    a_accept_comb = 1'b1;
                    b_accept_comb = 1'b1;
                end
                else if (allow_parallel) begin
                    a_accept_comb = 1'b1;
                    b_accept_comb = 1'b1;
                end
                else begin
                    a_accept_comb = 1'b0;
                    b_accept_comb = 1'b0;
                end
            end
            default: begin
                a_accept_comb = 1'b0;
                b_accept_comb = 1'b0;
            end
        endcase
    end
    assign portA_req_accepted = a_accept_comb;
    assign portB_req_accepted = b_accept_comb;
    always_comb begin
        AA    = 8'h00;
        DA    = 64'h0;
        BWEBA = {64{1'b1}};
        WEBA  = 1'b1;
        CEBA  = 1'b1;
        AB    = 8'h00;
        DB    = 64'h0;
        BWEBB = {64{1'b1}};
        WEBB  = 1'b1;
        CEBB  = 1'b1;
        if (a_accept_comb) begin
            AA   = portA_addr;
            CEBA = 1'b0;
            if (portA_req_write) begin
                WEBA  = 1'b0;
                DA    = portA_wdata;
                BWEBA = portA_wbem;
            end
            else begin
                WEBA  = 1'b1;
                BWEBA = {64{1'b1}};
            end
        end
        if (b_accept_comb) begin
            AB   = portB_addr;
            CEBB = 1'b0;
            if (portB_req_write) begin
                WEBB  = 1'b0;
                DB    = portB_wdata;
                BWEBB = portB_wbem;
            end
            else begin
                WEBB  = 1'b1;
                BWEBB = {64{1'b1}};
            end
        end
    end
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            a_read_accepted_q <= 1'b0;
            b_read_accepted_q <= 1'b0;
            portA_rsp_valid <= 1'b0;
            portB_rsp_valid <= 1'b0;
            portA_rdata     <= '0;
            portB_rdata     <= '0;
        end
        else begin
            a_read_accepted_q <= a_accept_comb && !portA_req_write;
            b_read_accepted_q <= b_accept_comb && !portB_req_write;
            portA_rsp_valid <= a_read_accepted_q;
            portB_rsp_valid <= b_read_accepted_q;
            if (a_read_accepted_q)
                portA_rdata <= QA;
            if (b_read_accepted_q)
                portB_rdata <= QB;
        end
    end
    TSDN16FFCLLULVTA256X64M4WBSHO u_macro (
        .AA(AA),
        .DA(DA),
        .BWEBA(BWEBA),
        .WEBA(WEBA),
        .CEBA(CEBA),
        .CLKA(CLKA),
        .QA(QA),
        .AB(AB),
        .DB(DB),
        .BWEBB(BWEBB),
        .WEBB(WEBB),
        .CEBB(CEBB),
        .CLKB(CLKB),
        .QB(QB),
        .SLP(SLP),
        .DSLP(DSLP),
        .SD(SD),
        .PUDELAY(),
        .WTSEL(WTSEL),
        .RTSEL(RTSEL),
        .AMA(AMA),
        .DMA(DMA),
        .BWEBMA(BWEBMA),
        .WEBMA(WEBMA),
        .CEBMA(CEBMA),
        .AMB(AMB),
        .DMB(DMB),
        .BWEBMB(BWEBMB),
        .WEBMB(WEBMB),
        .CEBMB(CEBMB),
        .BIST(BIST),
        .CLKM(CLKM)
    );
endmodule
module sv_bank_wrapper_256 (
    input  logic          clk,
    input  logic          rst_n,
    input  logic          portA_req_valid,
    input  logic          portA_req_write,
    input  logic          portA_is_scalar,
    input  logic [7:0]    portA_line_addr,
    input  logic [2:0]    portA_lane_idx,
    input  logic [255:0]  portA_wdata,
    input  logic [3:0]    portA_wstrb,
    output logic          portA_req_accepted,
    input  logic          portB_req_valid,
    input  logic          portB_req_write,
    input  logic          portB_is_scalar,
    input  logic [7:0]    portB_line_addr,
    input  logic [2:0]    portB_lane_idx,
    input  logic [255:0]  portB_wdata,
    input  logic [3:0]    portB_wstrb,
    output logic          portB_req_accepted,
    output logic          portA_rsp_valid,
    output logic [255:0]  portA_rdata,
    output logic          portB_rsp_valid,
    output logic [255:0]  portB_rdata,
    output logic          hazard_same_addr,
    output logic          hazard_blocked
);
    localparam int NUM_SLICES = 4;
    logic same_addr;
    logic has_write;
    logic allow_dual_read;
    logic allow_parallel;
    logic block_due_to_same_addr_write;
    always_comb begin
        same_addr = portA_req_valid && portB_req_valid &&
                    (portA_line_addr == portB_line_addr);
        has_write = (portA_req_valid && portA_req_write) ||
                    (portB_req_valid && portB_req_write);
        allow_dual_read = same_addr &&
                          portA_req_valid && !portA_req_write &&
                          portB_req_valid && !portB_req_write;
        allow_parallel = (!same_addr) &&
                         (portA_req_valid || portB_req_valid);
        block_due_to_same_addr_write = same_addr && has_write;
        hazard_same_addr = same_addr;
        hazard_blocked   = block_due_to_same_addr_write;
    end
    logic a_accept_comb, b_accept_comb;
    always_comb begin
        a_accept_comb = 1'b0;
        b_accept_comb = 1'b0;
        unique case ({portA_req_valid, portB_req_valid})
            2'b00: begin
                a_accept_comb = 1'b0;
                b_accept_comb = 1'b0;
            end
            2'b10: begin
                a_accept_comb = 1'b1;
                b_accept_comb = 1'b0;
            end
            2'b01: begin
                a_accept_comb = 1'b0;
                b_accept_comb = 1'b1;
            end
            2'b11: begin
                if (allow_dual_read) begin
                    a_accept_comb = 1'b1;
                    b_accept_comb = 1'b1;
                end
                else if (allow_parallel) begin
                    a_accept_comb = 1'b1;
                    b_accept_comb = 1'b1;
                end
                else begin
                    a_accept_comb = 1'b0;
                    b_accept_comb = 1'b0;
                end
            end
            default: begin
                a_accept_comb = 1'b0;
                b_accept_comb = 1'b0;
            end
        endcase
    end
    assign portA_req_accepted = a_accept_comb;
    assign portB_req_accepted = b_accept_comb;
    logic [1:0] portA_scalar_slice_idx;
    logic       portA_scalar_half_sel;
    logic [1:0] portB_scalar_slice_idx;
    logic       portB_scalar_half_sel;
    assign portA_scalar_slice_idx = portA_lane_idx[2:1];
    assign portA_scalar_half_sel  = portA_lane_idx[0];
    assign portB_scalar_slice_idx = portB_lane_idx[2:1];
    assign portB_scalar_half_sel  = portB_lane_idx[0];
    logic [NUM_SLICES-1:0]        sliceA_req_valid;
    logic [NUM_SLICES-1:0]        sliceA_req_write;
    logic [NUM_SLICES-1:0][7:0]   sliceA_addr;
    logic [NUM_SLICES-1:0][63:0]  sliceA_wdata;
    logic [NUM_SLICES-1:0][63:0]  sliceA_wbem;
    logic [NUM_SLICES-1:0]        sliceB_req_valid;
    logic [NUM_SLICES-1:0]        sliceB_req_write;
    logic [NUM_SLICES-1:0][7:0]   sliceB_addr;
    logic [NUM_SLICES-1:0][63:0]  sliceB_wdata;
    logic [NUM_SLICES-1:0][63:0]  sliceB_wbem;
    logic [NUM_SLICES-1:0]        sliceA_rsp_valid;
    logic [NUM_SLICES-1:0][63:0]  sliceA_rdata;
    logic [NUM_SLICES-1:0]        sliceB_rsp_valid;
    logic [NUM_SLICES-1:0][63:0]  sliceB_rdata;
    function automatic [63:0] pack_scalar_to_64(
        input logic [31:0] scalar_data,
        input logic        high_half
    );
        begin
            if (!high_half) begin
                pack_scalar_to_64 = {32'h0000_0000, scalar_data};
            end else begin
                pack_scalar_to_64 = {scalar_data, 32'h0000_0000};
            end
        end
    endfunction
    function automatic [63:0] scalar_wstrb_to_bwem64(
        input logic [3:0] wstrb,
        input logic       high_half
    );
        logic [63:0] mask;
        begin
            mask = {64{1'b1}}; // default keep
            if (!high_half) begin
                mask[7:0]    = {8{~wstrb[0]}};
                mask[15:8]   = {8{~wstrb[1]}};
                mask[23:16]  = {8{~wstrb[2]}};
                mask[31:24]  = {8{~wstrb[3]}};
            end else begin
                mask[39:32]  = {8{~wstrb[0]}};
                mask[47:40]  = {8{~wstrb[1]}};
                mask[55:48]  = {8{~wstrb[2]}};
                mask[63:56]  = {8{~wstrb[3]}};
            end
            scalar_wstrb_to_bwem64 = mask;
        end
    endfunction
    integer i;
    always_comb begin
        for (i = 0; i < NUM_SLICES; i++) begin
            sliceA_req_valid[i] = 1'b0;
            sliceA_req_write[i] = 1'b0;
            sliceA_addr[i]      = portA_line_addr;
            sliceA_wdata[i]     = 64'h0;
            sliceA_wbem[i]      = {64{1'b1}};
            sliceB_req_valid[i] = 1'b0;
            sliceB_req_write[i] = 1'b0;
            sliceB_addr[i]      = portB_line_addr;
            sliceB_wdata[i]     = 64'h0;
            sliceB_wbem[i]      = {64{1'b1}};
        end
        if (a_accept_comb) begin
            if (!portA_is_scalar) begin
                for (i = 0; i < NUM_SLICES; i++) begin
                    sliceA_req_valid[i] = 1'b1;
                    sliceA_req_write[i] = portA_req_write;
                    sliceA_addr[i]      = portA_line_addr;
                    sliceA_wdata[i]     = portA_wdata[i*64 +: 64];
                    sliceA_wbem[i]      = portA_req_write ? {64{1'b0}} : {64{1'b1}};
                end
            end
            else begin
                sliceA_req_valid[portA_scalar_slice_idx] = 1'b1;
                sliceA_req_write[portA_scalar_slice_idx] = portA_req_write;
                sliceA_addr[portA_scalar_slice_idx]      = portA_line_addr;
                sliceA_wdata[portA_scalar_slice_idx]     =
                    pack_scalar_to_64(portA_wdata[31:0], portA_scalar_half_sel);
                sliceA_wbem[portA_scalar_slice_idx]      =
                    portA_req_write
                    ? scalar_wstrb_to_bwem64(portA_wstrb, portA_scalar_half_sel)
                    : {64{1'b1}};
            end
        end
        if (b_accept_comb) begin
            if (!portB_is_scalar) begin
                for (i = 0; i < NUM_SLICES; i++) begin
                    sliceB_req_valid[i] = 1'b1;
                    sliceB_req_write[i] = portB_req_write;
                    sliceB_addr[i]      = portB_line_addr;
                    sliceB_wdata[i]     = portB_wdata[i*64 +: 64];
                    sliceB_wbem[i]      = portB_req_write ? {64{1'b0}} : {64{1'b1}};
                end
            end
            else begin
                sliceB_req_valid[portB_scalar_slice_idx] = 1'b1;
                sliceB_req_write[portB_scalar_slice_idx] = portB_req_write;
                sliceB_addr[portB_scalar_slice_idx]      = portB_line_addr;
                sliceB_wdata[portB_scalar_slice_idx]     =
                    pack_scalar_to_64(portB_wdata[31:0], portB_scalar_half_sel);
                sliceB_wbem[portB_scalar_slice_idx]      =
                    portB_req_write
                    ? scalar_wstrb_to_bwem64(portB_wstrb, portB_scalar_half_sel)
                    : {64{1'b1}};
            end
        end
    end
    genvar g;
    generate
        for (g = 0; g < NUM_SLICES; g++) begin : GEN_SLICES
            sv_bank_wrapper_64 u_slice (
                .clk               (clk),
                .rst_n             (rst_n),
                .portA_req_valid   (sliceA_req_valid[g]),
                .portA_req_write   (sliceA_req_write[g]),
                .portA_addr        (sliceA_addr[g]),
                .portA_wdata       (sliceA_wdata[g]),
                .portA_wbem        (sliceA_wbem[g]),
                .portA_req_accepted(),
                .portB_req_valid   (sliceB_req_valid[g]),
                .portB_req_write   (sliceB_req_write[g]),
                .portB_addr        (sliceB_addr[g]),
                .portB_wdata       (sliceB_wdata[g]),
                .portB_wbem        (sliceB_wbem[g]),
                .portB_req_accepted(),
                .portA_rsp_valid   (sliceA_rsp_valid[g]),
                .portA_rdata       (sliceA_rdata[g]),
                .portB_rsp_valid   (sliceB_rsp_valid[g]),
                .portB_rdata       (sliceB_rdata[g]),
                .hazard_same_addr  (),
                .hazard_blocked    ()
            );
        end
    endgenerate
    logic a_read_pending_q, b_read_pending_q;
    logic a_read_scalar_q,  b_read_scalar_q;
    logic [1:0] a_read_slice_q, b_read_slice_q;
    logic       a_read_half_q,  b_read_half_q;
    logic a_vec_rsp_ready, b_vec_rsp_ready;
    logic a_scalar_rsp_ready, b_scalar_rsp_ready;
    logic a_rsp_fire_condition, b_rsp_fire_condition;
    always_comb begin
        a_vec_rsp_ready    = 1'b0;
        b_vec_rsp_ready    = 1'b0;
        a_scalar_rsp_ready = 1'b0;
        b_scalar_rsp_ready = 1'b0;
        if (a_read_pending_q) begin
            if (!a_read_scalar_q) begin
                a_vec_rsp_ready = sliceA_rsp_valid[0];
            end
            else begin
                a_scalar_rsp_ready = sliceA_rsp_valid[a_read_slice_q];
            end
        end
        if (b_read_pending_q) begin
            if (!b_read_scalar_q) begin
                b_vec_rsp_ready = sliceB_rsp_valid[0];
            end
            else begin
                b_scalar_rsp_ready = sliceB_rsp_valid[b_read_slice_q];
            end
        end
        a_rsp_fire_condition = a_vec_rsp_ready | a_scalar_rsp_ready;
        b_rsp_fire_condition = b_vec_rsp_ready | b_scalar_rsp_ready;
    end
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            a_read_pending_q <= 1'b0;
            b_read_pending_q <= 1'b0;
            a_read_scalar_q  <= 1'b0;
            b_read_scalar_q  <= 1'b0;
            a_read_slice_q   <= '0;
            b_read_slice_q   <= '0;
            a_read_half_q    <= 1'b0;
            b_read_half_q    <= 1'b0;
            portA_rsp_valid  <= 1'b0;
            portB_rsp_valid  <= 1'b0;
            portA_rdata      <= '0;
            portB_rdata      <= '0;
        end
        else begin
            portA_rsp_valid <= 1'b0;
            portB_rsp_valid <= 1'b0;
            if (a_accept_comb && !portA_req_write) begin
                a_read_pending_q <= 1'b1;
                a_read_scalar_q  <= portA_is_scalar;
                a_read_slice_q   <= portA_scalar_slice_idx;
                a_read_half_q    <= portA_scalar_half_sel;
            end
            else if (a_rsp_fire_condition) begin
                a_read_pending_q <= 1'b0;
            end
            if (b_accept_comb && !portB_req_write) begin
                b_read_pending_q <= 1'b1;
                b_read_scalar_q  <= portB_is_scalar;
                b_read_slice_q   <= portB_scalar_slice_idx;
                b_read_half_q    <= portB_scalar_half_sel;
            end
            else if (b_rsp_fire_condition) begin
                b_read_pending_q <= 1'b0;
            end
            if (a_rsp_fire_condition) begin
                portA_rsp_valid <= 1'b1;
                portA_rdata     <= '0;
                if (!a_read_scalar_q) begin
                    portA_rdata[63:0]    <= sliceA_rdata[0];
                    portA_rdata[127:64]  <= sliceA_rdata[1];
                    portA_rdata[191:128] <= sliceA_rdata[2];
                    portA_rdata[255:192] <= sliceA_rdata[3];
                end
                else begin
                    if (!a_read_half_q)
                        portA_rdata[31:0] <= sliceA_rdata[a_read_slice_q][31:0];
                    else
                        portA_rdata[31:0] <= sliceA_rdata[a_read_slice_q][63:32];
                end
            end
            if (b_rsp_fire_condition) begin
                portB_rsp_valid <= 1'b1;
                portB_rdata     <= '0;
                if (!b_read_scalar_q) begin
                    portB_rdata[63:0]    <= sliceB_rdata[0];
                    portB_rdata[127:64]  <= sliceB_rdata[1];
                    portB_rdata[191:128] <= sliceB_rdata[2];
                    portB_rdata[255:192] <= sliceB_rdata[3];
                end
                else begin
                    if (!b_read_half_q)
                        portB_rdata[31:0] <= sliceB_rdata[b_read_slice_q][31:0];
                    else
                        portB_rdata[31:0] <= sliceB_rdata[b_read_slice_q][63:32];
                end
            end
        end
    end
endmodule
module sv_smu_top #(
    parameter int NUM_BANKS = 4
) (
    input  logic                         clk,
    input  logic                         rst_n,
    input  logic [NUM_BANKS-1:0]         bank_portA_req_valid,
    input  logic [NUM_BANKS-1:0]         bank_portA_req_write,
    input  logic [NUM_BANKS-1:0]         bank_portA_is_scalar,
    input  logic [NUM_BANKS-1:0][7:0]    bank_portA_line_addr,
    input  logic [NUM_BANKS-1:0][2:0]    bank_portA_lane_idx,
    input  logic [NUM_BANKS-1:0][255:0]  bank_portA_wdata,
    input  logic [NUM_BANKS-1:0][3:0]    bank_portA_wstrb,
    output logic [NUM_BANKS-1:0]         bank_portA_req_accepted,
    output logic [NUM_BANKS-1:0]         bank_portA_rsp_valid,
    output logic [NUM_BANKS-1:0][255:0]  bank_portA_rdata,
    input  logic [NUM_BANKS-1:0]         bank_portB_req_valid,
    input  logic [NUM_BANKS-1:0]         bank_portB_req_write,
    input  logic [NUM_BANKS-1:0]         bank_portB_is_scalar,
    input  logic [NUM_BANKS-1:0][7:0]    bank_portB_line_addr,
    input  logic [NUM_BANKS-1:0][2:0]    bank_portB_lane_idx,
    input  logic [NUM_BANKS-1:0][255:0]  bank_portB_wdata,
    input  logic [NUM_BANKS-1:0][3:0]    bank_portB_wstrb,
    output logic [NUM_BANKS-1:0]         bank_portB_req_accepted,
    output logic [NUM_BANKS-1:0]         bank_portB_rsp_valid,
    output logic [NUM_BANKS-1:0][255:0]  bank_portB_rdata,
    output logic [NUM_BANKS-1:0]         bank_hazard_same_addr,
    output logic [NUM_BANKS-1:0]         bank_hazard_blocked
);
    genvar g;
    generate
        for (g = 0; g < NUM_BANKS; g++) begin : GEN_BANKS
            sv_bank_wrapper_256 u_bank (
                .clk               (clk),
                .rst_n             (rst_n),
                .portA_req_valid   (bank_portA_req_valid[g]),
                .portA_req_write   (bank_portA_req_write[g]),
                .portA_is_scalar   (bank_portA_is_scalar[g]),
                .portA_line_addr   (bank_portA_line_addr[g]),
                .portA_lane_idx    (bank_portA_lane_idx[g]),
                .portA_wdata       (bank_portA_wdata[g]),
                .portA_wstrb       (bank_portA_wstrb[g]),
                .portA_req_accepted(bank_portA_req_accepted[g]),
                .portA_rsp_valid   (bank_portA_rsp_valid[g]),
                .portA_rdata       (bank_portA_rdata[g]),
                .portB_req_valid   (bank_portB_req_valid[g]),
                .portB_req_write   (bank_portB_req_write[g]),
                .portB_is_scalar   (bank_portB_is_scalar[g]),
                .portB_line_addr   (bank_portB_line_addr[g]),
                .portB_lane_idx    (bank_portB_lane_idx[g]),
                .portB_wdata       (bank_portB_wdata[g]),
                .portB_wstrb       (bank_portB_wstrb[g]),
                .portB_req_accepted(bank_portB_req_accepted[g]),
                .portB_rsp_valid   (bank_portB_rsp_valid[g]),
                .portB_rdata       (bank_portB_rdata[g]),
                .hazard_same_addr  (bank_hazard_same_addr[g]),
                .hazard_blocked    (bank_hazard_blocked[g])
            );
        end
    endgenerate
endmodule
// ============================================================================
// Module: sv_smu_sched_top_lean_internal
// ----------------------------------------------------------------------------
// Lean Performance SMU internal block map:
//   pe_frontend_portb              : PE req decode + PortB per-bank scheduling
//   dma_ctrl                       : DMA admission/issue/address/protect state
//   outstanding_table              : transition-fed table; target RTL owner
//   noc_rx_frontdoor               : RevB opcode-specific RX ready/dispatch
//   wbq_8entry                     : unified WBQ + 4-bank drain
//   remote_read_responder_small    : remote READ_REQ hold + PortA READ + RSP hold
//   portA_service_arbiter          : WBQ WRITE / QR preload READ / remote READ selection
//   portAB_hazard_bank_access      : overlap/forward/stall/bank drive
//   status_csr                     : completion/status/error/protect clear
//
// Port A naming policy:
//   - portA_svc_* is the architectural Non-PE Service Port bundle.
//   - wbq_* is the architectural writeback producer/queue/drain namespace.
//   - dma_wb_* / dma_wb_pending_* remain compatibility adapter mirrors until
//     the clean DMA producer interface is fully owned by RTL.
// ============================================================================
module sv_smu_sched_top_lean_internal #(
    parameter int NUM_PE       = 4,
    parameter int NUM_BANKS    = 4,
    parameter int LOCAL_ADDR_W = 15,
    parameter int LINE_ADDR_W  = 8,
    parameter int GLOBAL_ADDR_W = 19,
    parameter int VECTOR_W     = 256,
    parameter int PE_TAG_W     = 4,
    parameter int WSTRB_W      = 4,
    parameter int DMA_TAG_W    = 4,
    parameter int DMA_CNT_W    = 8
) (
    input  logic                         clk,
    input  logic                         rst_n,
    // --------------------------------------------------------------------
    // FORMAL RTL PATH: PE local memory interface.
    // Block owner: pe_frontend_portb.
    // --------------------------------------------------------------------
    input  logic [NUM_PE-1:0]                    pe_req_valid,
    output logic [NUM_PE-1:0]                    pe_req_ready,
    input  logic [NUM_PE-1:0][1:0]               pe_req_type,
    input  logic [NUM_PE-1:0]                    pe_req_is_vec,
    input  logic [NUM_PE-1:0][LOCAL_ADDR_W-1:0]  pe_req_addr,
    input  logic [NUM_PE-1:0][VECTOR_W-1:0]      pe_req_data,
    input  logic [NUM_PE-1:0][WSTRB_W-1:0]       pe_req_wstrb,
    input  logic [NUM_PE-1:0][PE_TAG_W-1:0]      pe_req_tag,
    // Dedicated QR pivot-preload vector read on the architectural non-PE
    // service Port A. One request may be outstanding.
    input  logic                                 qr_preload_req_valid,
    output logic                                 qr_preload_req_ready,
    input  logic [LOCAL_ADDR_W-1:0]              qr_preload_req_addr,
    output logic                                 qr_preload_rsp_valid,
    output logic [VECTOR_W-1:0]                  qr_preload_rsp_data,
    // --------------------------------------------------------------------
    // COMPAT / ADAPTER PATH: legacy single-entry DMA writeback producer.
    // Compatibility adapter classification:
    //   dma_wb_* is not the architectural Port A path in RevB.  Treat it as a
    //   compatibility WBQ producer adapter for current C++ bridge/regressions.
    //   New/final producers should drive wbq_enq_* with explicit tag/source/
    //   completion-credit metadata.
    // --------------------------------------------------------------------
    input  logic                                 dma_wb_valid,
    input  logic [LOCAL_ADDR_W-1:0]              dma_wb_addr,
    input  logic [VECTOR_W-1:0]                  dma_wb_data,
    // --------------------------------------------------------------------
    // FORMAL RTL PATH: WBQ producer enqueue interface.
    // Block owner: wbq_8entry.
    // --------------------------------------------------------------------
    // RevB-SPEC3 formal WBQ enqueue interface.
    // Lean naming target:
    //   wbq_enq_* is the final producer-side writeback interface.
    //   dma_wb_* may still feed this mux during compatibility testing, but
    //   should not appear in future architecture diagrams as a Port A source.
    input  logic                                 wbq_enq_valid,
    output logic                                 wbq_enq_ready,
    input  logic [1:0]                           wbq_enq_bank_idx,
    input  logic [LINE_ADDR_W-1:0]               wbq_enq_line_addr,
    input  logic [VECTOR_W-1:0]                  wbq_enq_data,
    input  logic [DMA_TAG_W-1:0]                 wbq_enq_tag,
    input  logic [2:0]                           wbq_enq_src_kind,
    input  logic                                 wbq_enq_completion_credit,
    // --------------------------------------------------------------------
    // LOCAL OBSERVATION PATH: WBQ drain hold and legacy WB adapter mirrors.
    // Not part of final Lean Performance module boundary.
    // --------------------------------------------------------------------
    // RevB-RTL11 verification-only drain hold.  This does not seed WBQ
    // state directly; it only holds the drain consumer off so normal
    // dma_wb_valid enqueue traffic can accumulate a multi-bank backlog.
    // --------------------------------------------------------------------
    // COMPAT / ADAPTER PATH: DMA protect/status state imported from the
    // current C++ harness.  Future Lean RTL should internalize this in
    // dma_ctrl/status_csr, but boundary cleanup keeps behavior unchanged.
    // --------------------------------------------------------------------
    input  logic                                 dma_local_dst_active,
    input  logic [LOCAL_ADDR_W-1:0]              dma_local_dst_start,
    input  logic [LOCAL_ADDR_W-1:0]              dma_local_dst_end,
    // --------------------------------------------------------------------
    // COMPAT / ADAPTER PATH: DMA issue/admission/planner adapter inputs.
    // These describe or compare dma_ctrl behavior; they are not clean final
    // hardware block interfaces.
    // --------------------------------------------------------------------
    input  logic                                 dma_issue_active,
    input  logic                                 dma_issue_error,
    input  logic [7:0]                           dma_issue_holdoff,
    input  logic [GLOBAL_ADDR_W-1:0]             dma_issue_src_base,
    input  logic [GLOBAL_ADDR_W-1:0]             dma_issue_dst_base,
    input  logic [DMA_TAG_W-1:0]                 dma_issue_tag_candidate,
    // LOCAL OBSERVATION PATH: legacy perf4 burst planner adapter.
    // LOCAL OBSERVATION PATH: legacy perf5 2D stride address adapter.
    // LOCAL OBSERVATION PATH: legacy perf6 2D command-format adapter.
    // LOCAL OBSERVATION PATH: legacy NoC TX/RX observation hooks.
    // --------------------------------------------------------------------
    // FORMAL RTL PATH: RevB unified NoC RX front-door.
    // Block owner: noc_rx_frontdoor.
    // --------------------------------------------------------------------
    // RevB unified NoC RX front-door.  This opcode-shaped path does
    // not create new datapaths; it dispatches READ_RSP into the formal WBQ
    // enqueue interface, ERROR_RSP into the status/error-ready path, and
    // READ_REQ into the same remote read responder request holder used by
    // RevB-SPEC4.
    input  logic                                 revb_noc_rx_valid,
    output logic                                 revb_noc_rx_ready,
    input  logic [1:0]                           revb_noc_rx_opcode,
    input  logic [GLOBAL_ADDR_W-1:0]             revb_noc_rx_addr,
    input  logic [VECTOR_W-1:0]                  revb_noc_rx_data,
    input  logic [DMA_TAG_W-1:0]                 revb_noc_rx_tag,
    input  logic [3:0]                           revb_noc_rx_requester,
    input  logic                                 revb_noc_rx_path,
    // --------------------------------------------------------------------
    // FORMAL RTL PATH: request-shaped remote READ_REQ intake.
    // Block owner: remote_read_responder_small.
    // --------------------------------------------------------------------
    // RevB formal NoC READ_REQ -> remote read responder intake.
    // The legacy remote_rd_enq_* sideband remains for existing adapter tests;
    // this path decodes a real NoC request-shaped input into the same
    // responder request holding register.
    input  logic                                 revb_noc_rx_read_req_valid,
    output logic                                 revb_noc_rx_read_req_ready,
    input  logic [GLOBAL_ADDR_W-1:0]             revb_noc_rx_read_req_addr,
    input  logic [DMA_TAG_W-1:0]                 revb_noc_rx_read_req_tag,
    input  logic [3:0]                           revb_noc_rx_read_req_requester,
    input  logic                                 revb_noc_rx_read_req_path,
    // --------------------------------------------------------------------
    // FORMAL RTL PATH: NoC TX READ_RSP view from remote responder hold.
    // Block owner: remote_read_responder_small / NoC TX adapter.
    // --------------------------------------------------------------------
    // RevB formal NoC TX READ_RSP view.  This is driven from the
    // existing remote read response holding register; revb_noc_tx_read_rsp_ready
    // participates in the same hold-release handshake as remote_rd_rsp_ready.
    output logic                                 revb_noc_tx_read_rsp_valid,
    input  logic                                 revb_noc_tx_read_rsp_ready,
    output logic [1:0]                           revb_noc_tx_read_rsp_opcode,
    output logic [VECTOR_W-1:0]                  revb_noc_tx_read_rsp_data,
    output logic [DMA_TAG_W-1:0]                 revb_noc_tx_read_rsp_tag,
    output logic [3:0]                           revb_noc_tx_read_rsp_requester,
    output logic                                 revb_noc_tx_read_rsp_path,
    // --------------------------------------------------------------------
    // COMPAT / ADAPTER PATH: legacy remote read sideband.
    // Kept until the formal RevB NoC READ_REQ/RSP interface fully replaces it.
    // --------------------------------------------------------------------
    input  logic                                 remote_rd_enq_valid,
    output logic                                 remote_rd_enq_ready,
    input  logic [1:0]                           remote_rd_enq_bank_idx,
    input  logic [LINE_ADDR_W-1:0]               remote_rd_enq_line_addr,
    input  logic [DMA_TAG_W-1:0]                 remote_rd_enq_tag,
    input  logic [3:0]                           remote_rd_enq_requester,
    input  logic                                 remote_rd_enq_path,
    output logic                                 remote_rd_rsp_valid,
    input  logic                                 remote_rd_rsp_ready,
    output logic [VECTOR_W-1:0]                  remote_rd_rsp_data,
    output logic [DMA_TAG_W-1:0]                 remote_rd_rsp_tag,
    output logic [3:0]                           remote_rd_rsp_requester,
    output logic                                 remote_rd_rsp_path,
    // --------------------------------------------------------------------
    // FORMAL RTL PATH: public PE response and compact status outputs.
    // --------------------------------------------------------------------
    // COMPAT / ADAPTER NOTE: older RX/completion/hazard/status observation
    // interfaces have been localized inside the internal module.
    // --------------------------------------------------------------------
    // COMPAT / ADAPTER PATH: outstanding table metadata is still transition-fed;
    // the Lean target is full RTL ownership in a later functional pass.
    // --------------------------------------------------------------------
    // COMPAT / ADAPTER PATH: DMA command admission and side-effect adapter state.
    output logic [NUM_PE-1:0]                    pe_rsp_valid,
    input  logic [NUM_PE-1:0]                    pe_rsp_ready,
    output logic [NUM_PE-1:0]                    pe_rsp_kind,
    output logic [NUM_PE-1:0]                    pe_rsp_err,
    output logic [NUM_PE-1:0][VECTOR_W-1:0]      pe_rsp_data,
    output logic [NUM_PE-1:0][PE_TAG_W-1:0]      pe_rsp_tag,
    output logic [NUM_BANKS-1:0]                 bank_hazard_same_addr,
    output logic [NUM_BANKS-1:0]                 bank_hazard_blocked,
    output logic                                 dma_wb_meta_valid,
    output logic                                 dma_wb_meta_pending,
    output logic [LOCAL_ADDR_W-1:0]              dma_wb_meta_local_addr,
    output logic [1:0]                           dma_wb_meta_bank_idx,
    output logic [LINE_ADDR_W-1:0]               dma_wb_meta_line_addr,
    output logic [31:0]                          dma_wb_meta_lane0,
    // Architectural write-visibility event: asserted only when a WBQ entry is
    // accepted by the destination SRAM Port A.  One commit per bank/cycle.
    output logic [NUM_BANKS-1:0]                 wbq_commit_valid,
    output logic [NUM_BANKS-1:0][LOCAL_ADDR_W-1:0] wbq_commit_addr,
    output logic [NUM_BANKS-1:0][VECTOR_W-1:0]   wbq_commit_data,
    output logic [NUM_PE-1:0]                    pe_protect_hit
    // Compact observation buses remain intentionally absent from this public
    // synthesis-facing boundary; adapter-only versions belong in archive builds.
);

    // COMPAT/FUTURE-READY BOUNDARY FIELDS:
    // These inputs are intentionally preserved for the C++ bridge / future
    // metadata-ready interfaces, but this lean checkpoint does not consume them
    // in the functional datapath yet. Fold them into a local reduction so
    // Keep the preserved fields visible to the lint reduction without treating them as accidental unused ports.
    /* verilator lint_off UNUSEDSIGNAL */
    logic _rtlclean1d_unused_compat_boundary;
    /* verilator lint_on UNUSEDSIGNAL */
    assign _rtlclean1d_unused_compat_boundary = &{1'b0,
        {DMA_CNT_W{1'b0}},
        wbq_enq_src_kind,
        dma_issue_holdoff,
        dma_issue_src_base,
        revb_noc_rx_addr[GLOBAL_ADDR_W-1:LOCAL_ADDR_W],
        revb_noc_rx_read_req_addr[GLOBAL_ADDR_W-1:LOCAL_ADDR_W],
        pe_rsp_ready
    };

    // --------------------------------------------------------------------

    // ====================================================================
    // LEAN INTERNAL REGION MAP
    // --------------------------------------------------------------------
    // The declarations and logic below are grouped by their Lean block role.
    // This boundary cleanup does not move declarations across dependency points;
    // it updates ownership labels only.
    // ====================================================================

    // --------------------------------------------------------------------
    // Shared address/vector helper definitions.
    // --------------------------------------------------------------------
    localparam int LANE_IDX_W = 3;
    localparam int DMA_OUTSTANDING_SHADOW_MAX = 8;
    // --------------------------------------------------------------------
    // CLEAN INTERNAL REGION: outstanding table, NoC RX metadata, and DMA command planning state.
    // Role : internal compatibility observation only; not final datapath state.
    // --------------------------------------------------------------------    logic [DMA_TAG_W-1:0]     rx_lookup_entry_tag [DMA_OUTSTANDING_SHADOW_MAX];
    logic [7:0]                           phase11p_outstanding_valid_q;
    logic [DMA_TAG_W-1:0]                 phase11p_outstanding_tag_q [DMA_OUTSTANDING_SHADOW_MAX];
    logic [GLOBAL_ADDR_W-1:0]             phase11p_outstanding_dst_global_q [DMA_OUTSTANDING_SHADOW_MAX];
    logic [3:0]                           phase11p_outstanding_count_q;
    logic                                 phase11p_insert_ready;
    logic [2:0]                           phase11p_insert_idx;
    logic                                 phase11p_insert_fire;
    logic                                 phase11p_clear_fire;
    logic [2:0]                           phase11p_clear_idx;
    logic [7:0]                           phase11p_valid_after_clear;
    logic [7:0]                           phase11p_valid_next;
    logic [3:0]                           phase11p_count_after_clear;
    logic [3:0]                           phase11p_count_next;
    logic                                 phase11p_lookup_hit;
    logic [2:0]                           phase11p_lookup_match_idx;
    logic [LOCAL_ADDR_W-1:0]              phase11p_lookup_match_dst;
    logic [LOCAL_ADDR_W-1:0]              noc_rx_read_rsp_lookup_local_addr;
    logic [1:0]                           noc_rx_read_rsp_lookup_bank_idx;
    logic [LINE_ADDR_W-1:0]               noc_rx_read_rsp_lookup_line_addr;
    logic                                 noc_rx_read_rsp_uses_lookup_metadata;
    logic                                 dma_issue_active_q;
    logic [DMA_TAG_W-1:0]                 dma_issue_tag_candidate_q;
    logic                                 phase11p_insert_tag_already_valid;
    logic [DMA_WBQ_DEPTH-1:0]             wbq_commit_credit_tag_fire;
    // Intentional local-address slicing: bank/line/lane decoders consume only
    // the address bits needed by each field.
    /* verilator lint_off UNUSEDSIGNAL */
    function automatic [1:0] local_addr_to_bank_idx(input logic [LOCAL_ADDR_W-1:0] addr);
        local_addr_to_bank_idx = addr[6:5];
    endfunction
    function automatic [LINE_ADDR_W-1:0] local_addr_to_line_addr(input logic [LOCAL_ADDR_W-1:0] addr);
        local_addr_to_line_addr = addr[14:7];
    endfunction
    function automatic [LANE_IDX_W-1:0] local_addr_to_lane_idx(input logic [LOCAL_ADDR_W-1:0] addr);
        local_addr_to_lane_idx = addr[4:2];
    endfunction
    /* verilator lint_on UNUSEDSIGNAL */
    function automatic [LOCAL_ADDR_W-1:0] bank_line_to_local_addr(
        input logic [1:0] bank_idx,
        input logic [LINE_ADDR_W-1:0] line_addr
    );
        bank_line_to_local_addr = {line_addr, bank_idx, 5'b0};
    endfunction
    function automatic [31:0] vec_lane32(
        input logic [VECTOR_W-1:0] vec,
        input logic [2:0] lane_idx
    );
        vec_lane32 = vec[lane_idx*32 +: 32];
    endfunction
    // --------------------------------------------------------------------
    // Block: pe_frontend_portb
    // Role : PE decode, bank/lane extraction, and per-bank PE selection.
    // --------------------------------------------------------------------
    logic [NUM_PE-1:0][1:0]               pe_bank_idx;
    logic [NUM_PE-1:0][LINE_ADDR_W-1:0]   pe_line_addr;
    logic [NUM_PE-1:0][LANE_IDX_W-1:0]    pe_lane_idx;
    logic [NUM_PE-1:0]                    pe_is_read;
    logic [NUM_PE-1:0]                    pe_is_write;
    logic [NUM_PE-1:0]                    pe_is_scalar;
    logic [NUM_PE-1:0][NUM_BANKS-1:0]     pe_hits_bank;
    logic [NUM_BANKS-1:0]                 sel_pe_valid;
    logic [NUM_BANKS-1:0][$clog2(NUM_PE)-1:0] sel_pe_idx;
    logic [NUM_BANKS-1:0]                 sel_pe_is_read;
    logic [NUM_BANKS-1:0]                 sel_pe_is_write;
    logic [NUM_BANKS-1:0]                 sel_pe_is_scalar;
    logic [NUM_BANKS-1:0][LINE_ADDR_W-1:0] sel_pe_line_addr;
    logic [NUM_BANKS-1:0][LANE_IDX_W-1:0] sel_pe_lane_idx;
    logic [NUM_BANKS-1:0][VECTOR_W-1:0]   sel_pe_wdata;
    logic [NUM_BANKS-1:0][WSTRB_W-1:0]    sel_pe_wstrb;
    logic [NUM_BANKS-1:0][PE_TAG_W-1:0]   sel_pe_tag;
    // --------------------------------------------------------------------
    // COMPAT / ADAPTER REGION: legacy DMA writeback pending mirrors.
    // Compatibility adapter classification:
    //   These dma_wb_pending_* / phase8* / phase8b* names are legacy
    //   compatibility mirrors. The final Lean datapath is WBQ -> portA_svc
    //   WRITE -> bank. Keep them only for current C++ adapter compatibility
    //   until a later DMA producer cleanup pass.
    // --------------------------------------------------------------------
    logic [1:0]                           dma_wb_bank_idx;
    logic [LINE_ADDR_W-1:0]               dma_wb_line_addr;
    logic                                 dma_wb_pending_valid;
    logic [LOCAL_ADDR_W-1:0]              dma_wb_pending_addr;
    // COMPAT / ADAPTER MIRROR:
    //   dma_wb_eff_* is retained as a legacy effective-WB mirror for existing
    //   adapter users.  It is not the architectural Port A candidate.
    //   Final Port A service selection is represented by portA_svc_* below.
    logic                                 dma_wb_eff_valid;
    logic [1:0]                           dma_wb_eff_bank_idx;
    logic [LINE_ADDR_W-1:0]               dma_wb_eff_line_addr;
    logic [31:0]                          dma_wb_eff_lane0;


    // --------------------------------------------------------------------
    // Block: wbq_8entry
    // Role : formal unified WBQ, 8-entry buffering, per-bank 4-bank drain,
    //        in-place retry, and completion-credit retirement.
    // --------------------------------------------------------------------
    // RevB-SPEC3: formal WBQ enqueue interface + per-bank 4-bank drain.
    // Legacy dma_wb_pending_* signals are retained as compatibility mirrors of the
    // oldest valid WBQ entry; Port A WRITE candidates are selected from wbq_*.
    // The WBQ entry now carries the spec-facing metadata required for future
    // completion/status ownership: dma_tag, src_kind, and completion_credit.
    localparam int DMA_WBQ_DEPTH = 8;
    localparam logic [1:0] REVB_NOC_OP_READ_RSP  = 2'b00;
    localparam logic [1:0] REVB_NOC_OP_ERROR_RSP = 2'b01;
    localparam logic [1:0] REVB_NOC_OP_READ_REQ  = 2'b10;
    logic [DMA_WBQ_DEPTH-1:0]                   wbq_valid_q;
    logic [DMA_WBQ_DEPTH-1:0][LOCAL_ADDR_W-1:0] wbq_addr_q;
    logic [DMA_WBQ_DEPTH-1:0][VECTOR_W-1:0]     wbq_data_q;
    logic [DMA_WBQ_DEPTH-1:0][1:0]              wbq_bank_idx_q;
    logic [DMA_WBQ_DEPTH-1:0][LINE_ADDR_W-1:0]  wbq_line_addr_q;
    logic [DMA_WBQ_DEPTH-1:0][DMA_TAG_W-1:0]    wbq_dma_tag_q;

    // INTERNAL OBSERVATION HELPERS: retained only for the optional compact
    // WBQ observation bus after pruning evidence-only dbg_revb_wbq_* top-level
    // ports. These are not exported as scattered debug ports.
    logic [DMA_WBQ_DEPTH-1:0]                   wbq_completion_credit_q;
    logic [DMA_WBQ_DEPTH-1:0][3:0]              wbq_retry_count_q;

    logic                                       wbq_enq_fire;
    logic [$clog2(DMA_WBQ_DEPTH)-1:0]           wbq_enq_idx;
    logic                                       wbq_enq_req_valid;
    logic [LOCAL_ADDR_W-1:0]                    wbq_enq_req_addr;
    logic [VECTOR_W-1:0]                        wbq_enq_req_data;
    logic [1:0]                                 wbq_enq_req_bank_idx;
    logic [LINE_ADDR_W-1:0]                     wbq_enq_req_line_addr;
    logic [DMA_TAG_W-1:0]                       wbq_enq_req_tag;
    logic                                       wbq_enq_req_completion_credit;
    logic                                       wbq_any_invalid;
    logic [$clog2(DMA_WBQ_DEPTH)-1:0]           wbq_first_invalid_idx;
    logic                                       wbq_any_valid;
    logic [$clog2(DMA_WBQ_DEPTH)-1:0]           wbq_dbg_idx;

    logic [NUM_BANKS-1:0]                       wbq_drain_valid;
    logic [NUM_BANKS-1:0][$clog2(DMA_WBQ_DEPTH)-1:0] wbq_drain_idx;
    logic [DMA_WBQ_DEPTH-1:0]                   wbq_entry_commit_fire;
    logic [DMA_WBQ_DEPTH-1:0]                   wbq_entry_retry_fire;
    logic [3:0]                                 wbq_valid_count;
    logic [3:0]                                 wbq_occupancy_count;
    logic                                       wbq_almost_full;
    localparam logic [3:0]                      DMA_WBQ_ALMOST_FULL_LEVEL = 4'd7;
    logic [2:0]                                 wbq_parallel_candidate_count;
    logic [2:0]                                 wbq_parallel_commit_count;

    // --------------------------------------------------------------------
    // Block: portA_service_arbiter
    // Role : selects WBQ WRITE, QR preload READ, or remote READ per bank.
    // --------------------------------------------------------------------
    // RevB-RTL1: internal Port A service abstraction.
    // Current behavior is intentionally unchanged: the only implemented Port A
    // service source is the existing DMA/WBQ writeback path.  Future cleanup steps
    // can add REMOTE_READ and richer WBQ drain sources behind this bundle
    // without touching the downstream PortA/PortB hazard rule again.
    localparam logic [1:0] PORTA_OP_READ  = 2'd1;
    localparam logic [1:0] PORTA_OP_WRITE = 2'd2;
    localparam logic [2:0] PORTA_SRC_WBQ_DRAIN   = 3'd2;
    localparam logic [2:0] PORTA_SRC_REMOTE_READ = 3'd3;
    localparam logic [2:0] PORTA_SRC_QR_PRELOAD  = 3'd4;

    // FORMAL LEAN RTL BUNDLE:
    //   portA_svc_* is the only architectural Non-PE Service Port candidate
    //   namespace.  It may carry WBQ drain WRITE, QR pivot-preload READ, or remote responder READ.
    logic [NUM_BANKS-1:0]                 portA_svc_valid;
    logic [NUM_BANKS-1:0][1:0]            portA_svc_op;
    logic [NUM_BANKS-1:0][2:0]            portA_svc_src;
    logic [NUM_BANKS-1:0][LINE_ADDR_W-1:0] portA_svc_line_addr;
    logic [NUM_BANKS-1:0][LANE_IDX_W-1:0] portA_svc_lane_idx;
    logic [NUM_BANKS-1:0][VECTOR_W-1:0]   portA_svc_wdata;
    logic [NUM_BANKS-1:0][WSTRB_W-1:0]    portA_svc_wstrb;

    // LP-3BE: per-bank anti-starvation toggle for normal-priority Port A
    // arbitration.  1 means prefer remote READ when both WBQ and remote
    // candidates are present and WBQ is not almost full; 0 means prefer WBQ.
    logic [NUM_BANKS-1:0]                 portA_rr_toggle_q;
    logic [NUM_BANKS-1:0]                 remote_rd_portA_candidate_valid;
    logic [NUM_BANKS-1:0]                 qr_preload_portA_candidate_valid;
    logic [1:0]                           qr_preload_bank_idx;
    logic [LINE_ADDR_W-1:0]               qr_preload_line_addr;
    logic                                 qr_preload_issue_fire;
    logic                                 qr_preload_pending_q;
    logic [1:0]                           qr_preload_pending_bank_q;

    // --------------------------------------------------------------------
    // Block: noc_rx_frontdoor
    // Role : opcode-specific ready and dispatch for READ_RSP/ERROR_RSP/READ_REQ.
    // --------------------------------------------------------------------
    // RevB-CLEAN1 / SPEC5: unified NoC RX front-door opcode decode.  READ_RSP reuses
    // the formal WBQ enqueue path; ERROR_RSP requires outstanding tag
    // lookup and clears through the status/error side; READ_REQ reuses the same remote read responder path from SPEC4.
    logic                                 revb_noc_rx_is_read_rsp;
    logic                                 revb_noc_rx_is_error_rsp;
    logic                                 revb_noc_rx_is_read_req;
    logic                                 revb_noc_rx_read_rsp_ready;
    logic                                 revb_noc_rx_error_rsp_ready;
    logic                                 revb_noc_rx_read_req_front_ready;
    logic                                 revb_noc_rx_read_rsp_fire;
    logic                                 revb_noc_rx_error_rsp_fire;
    logic                                 revb_noc_rx_read_req_front_fire;
    // LP-3BE: ERROR_RSP is a tag-owned outstanding-table event.
    // It is accepted only when the tag matches an outstanding entry, then
    // clears that entry through the same registered clear path without WBQ.
    logic                                 noc_rx_error_rsp_has_lookup_metadata;
    logic                                 noc_rx_error_rsp_status_capacity;
    logic                                 noc_rx_error_rsp_clear_fire;
    // LP-3BE: duplicate READ_RSP guard.  While a completion-credit WBQ entry
    // for the same tag is still waiting for Port A commit, the outstanding
    // entry intentionally remains valid for commit-time clear.  A second
    // READ_RSP with the same tag must therefore be backpressured instead of
    // being accepted as another writeback.
    logic                                 noc_rx_read_rsp_tag_pending_wbq;
    logic [1:0]                           revb_noc_rx_decoded_bank_idx;
    logic [LINE_ADDR_W-1:0]               revb_noc_rx_decoded_line_addr;

    // --------------------------------------------------------------------
    // Block: remote_read_responder_small
    // Role : request hold, Port A READ issue, response hold, and READ_RSP view.
    // --------------------------------------------------------------------
    // RevB-SPEC4: remote DMA read responder can now be driven either by
    // the legacy remote_rd_enq_* verification sideband or by the formalized
    // NoC READ_REQ-shaped input below.  Both paths converge into the same
    // request holding register, Port A READ service, response holding register,
    // and NoC TX READ_RSP view.
    logic                                 remote_rd_req_hold_valid_q;
    logic [1:0]                           remote_rd_req_hold_bank_idx_q;
    logic [LINE_ADDR_W-1:0]               remote_rd_req_hold_line_addr_q;
    logic [DMA_TAG_W-1:0]                 remote_rd_req_hold_tag_q;
    logic [3:0]              remote_rd_req_hold_requester_q;
    logic                                 remote_rd_req_hold_path_q;
    logic                                 remote_rd_req_issue_fire;
    logic                                 remote_rd_req_enq_fire;
    logic                                 remote_rd_rsp_hold_fire;

    logic [NUM_BANKS-1:0]                 remote_rd_pending_rsp_valid_q;
    logic [NUM_BANKS-1:0][DMA_TAG_W-1:0]  remote_rd_pending_rsp_tag_q;
    logic [NUM_BANKS-1:0][3:0] remote_rd_pending_rsp_requester_q;
    logic [NUM_BANKS-1:0]                 remote_rd_pending_rsp_path_q;
    logic [NUM_BANKS-1:0]                 remote_rd_rsp_capture_fire;

    logic                                 remote_rd_rsp_hold_valid_q;
    logic [VECTOR_W-1:0]                  remote_rd_rsp_hold_data_q;
    logic [DMA_TAG_W-1:0]                 remote_rd_rsp_hold_tag_q;
    logic [3:0]              remote_rd_rsp_hold_requester_q;
    logic                                 remote_rd_rsp_hold_path_q;
    logic                                 remote_rd_rsp_hold_capture_fire;
    logic [1:0]                           remote_rd_rsp_hold_capture_bank;

    logic                                 remote_rd_req_intake_ready;
    logic                                 remote_rd_req_intake_valid;
    logic [1:0]                           remote_rd_req_intake_bank_idx;
    logic [LINE_ADDR_W-1:0]               remote_rd_req_intake_line_addr;
    logic [DMA_TAG_W-1:0]                 remote_rd_req_intake_tag;
    logic [3:0]                           remote_rd_req_intake_requester;
    logic                                 remote_rd_req_intake_path;

    // --------------------------------------------------------------------
    // --------------------------------------------------------------------
    // Block logic: outstanding_table lookup / commit-time clear planning.
    // --------------------------------------------------------------------
    // RTL-CLEAN-1A: split lookup/insert planning from clear/next-state
    // planning.  Keeping the READ_RSP/ERROR_RSP lookup in a read-only
    // combinational island avoids a Verilator UNOPTFLAT false dependency where
    // revb_noc_rx_*_fire, WBQ commit, and outstanding-table clear were all
    // computed in one always_comb block.
    always_comb begin
        phase11p_insert_ready = (phase11p_outstanding_count_q < 4'd8);
        phase11p_insert_idx   = '0;
        for (int i = 0; i < DMA_OUTSTANDING_SHADOW_MAX; i++) begin
            if (!phase11p_outstanding_valid_q[i] && (phase11p_insert_idx == '0)) begin
                phase11p_insert_idx = i[2:0];
            end
        end

        phase11p_insert_tag_already_valid = 1'b0;
        for (int i = 0; i < DMA_OUTSTANDING_SHADOW_MAX; i++) begin
            if (phase11p_outstanding_valid_q[i] &&
                (phase11p_outstanding_tag_q[i] == dma_issue_tag_candidate)) begin
                phase11p_insert_tag_already_valid = 1'b1;
            end
        end

        phase11p_insert_fire = dma_issue_active && !dma_issue_error &&
                               phase11p_insert_ready &&
                               !phase11p_insert_tag_already_valid &&
                               (!dma_issue_active_q ||
                                (dma_issue_tag_candidate != dma_issue_tag_candidate_q));
    end

    always_comb begin
        phase11p_lookup_hit       = 1'b0;
        phase11p_lookup_match_idx = '0;
        phase11p_lookup_match_dst = '0;
        for (int i = 0; i < DMA_OUTSTANDING_SHADOW_MAX; i++) begin
            if (phase11p_outstanding_valid_q[i] &&
                (phase11p_outstanding_tag_q[i] == revb_noc_rx_tag) &&
                !phase11p_lookup_hit) begin
                phase11p_lookup_hit       = 1'b1;
                phase11p_lookup_match_idx = i[2:0];
                phase11p_lookup_match_dst = phase11p_outstanding_dst_global_q[i][LOCAL_ADDR_W-1:0];
            end
        end

        noc_rx_read_rsp_uses_lookup_metadata = phase11p_lookup_hit;
        // RevB clean owner rule:
        // READ_RSP writeback destination must come from outstanding-table
        // metadata.  revb_noc_rx_addr remains available for READ_REQ remote
        // responder decode, but is no longer a READ_RSP writeback fallback.
        noc_rx_read_rsp_lookup_local_addr = phase11p_lookup_match_dst;
        noc_rx_read_rsp_lookup_bank_idx  = local_addr_to_bank_idx(noc_rx_read_rsp_lookup_local_addr);
        noc_rx_read_rsp_lookup_line_addr = local_addr_to_line_addr(noc_rx_read_rsp_lookup_local_addr);
    end

    always_comb begin
        wbq_commit_credit_tag_fire = '0;
        for (int i = 0; i < DMA_WBQ_DEPTH; i++) begin
            wbq_commit_credit_tag_fire[i] = wbq_entry_commit_fire[i] &&
                                            wbq_completion_credit_q[i];
        end

        phase11p_clear_fire = 1'b0;
        phase11p_clear_idx  = '0;
        for (int i = 0; i < DMA_WBQ_DEPTH; i++) begin
            if (wbq_commit_credit_tag_fire[i] && !phase11p_clear_fire) begin
                for (int j = 0; j < DMA_OUTSTANDING_SHADOW_MAX; j++) begin
                    if (phase11p_outstanding_valid_q[j] &&
                        (phase11p_outstanding_tag_q[j] == wbq_dma_tag_q[i])) begin
                        phase11p_clear_fire = 1'b1;
                        phase11p_clear_idx  = j[2:0];
                    end
                end
            end
        end

        if (noc_rx_error_rsp_clear_fire && !phase11p_clear_fire) begin
            phase11p_clear_fire = 1'b1;
            phase11p_clear_idx  = phase11p_lookup_match_idx;
        end

        phase11p_valid_after_clear = phase11p_outstanding_valid_q;
        phase11p_count_after_clear = phase11p_outstanding_count_q;
        if (phase11p_clear_fire) begin
            phase11p_valid_after_clear[phase11p_clear_idx] = 1'b0;
            if (phase11p_count_after_clear != 0) begin
                phase11p_count_after_clear = phase11p_count_after_clear - 4'd1;
            end
        end

        phase11p_valid_next = phase11p_valid_after_clear;
        phase11p_count_next = phase11p_count_after_clear;
        if (phase11p_insert_fire) begin
            phase11p_valid_next[phase11p_insert_idx] = 1'b1;
            phase11p_count_next = phase11p_count_after_clear + 4'd1;
        end
    end

    // Block logic: noc_rx_frontdoor + remote_read_responder_small handshake.
    // --------------------------------------------------------------------
    assign revb_noc_rx_is_read_rsp  = revb_noc_rx_valid && (revb_noc_rx_opcode == REVB_NOC_OP_READ_RSP);
    assign revb_noc_rx_is_error_rsp = revb_noc_rx_valid && (revb_noc_rx_opcode == REVB_NOC_OP_ERROR_RSP);
    assign revb_noc_rx_is_read_req  = revb_noc_rx_valid && (revb_noc_rx_opcode == REVB_NOC_OP_READ_REQ);
    assign revb_noc_rx_decoded_bank_idx  = local_addr_to_bank_idx(revb_noc_rx_addr[LOCAL_ADDR_W-1:0]);
    assign revb_noc_rx_decoded_line_addr = local_addr_to_line_addr(revb_noc_rx_addr[LOCAL_ADDR_W-1:0]);

    assign remote_rd_req_intake_ready = !remote_rd_req_hold_valid_q || remote_rd_req_issue_fire;
    assign revb_noc_rx_read_rsp_ready = wbq_enq_ready && !wbq_enq_valid && !dma_wb_valid &&
                                            noc_rx_read_rsp_uses_lookup_metadata &&
                                            !noc_rx_read_rsp_tag_pending_wbq;
    assign noc_rx_error_rsp_has_lookup_metadata = phase11p_lookup_hit;
    assign noc_rx_error_rsp_status_capacity = 1'b1;
    assign revb_noc_rx_error_rsp_ready = noc_rx_error_rsp_has_lookup_metadata &&
                                         noc_rx_error_rsp_status_capacity;
    assign noc_rx_error_rsp_clear_fire = revb_noc_rx_error_rsp_fire;
    assign revb_noc_rx_read_req_front_ready = remote_rd_req_intake_ready && !revb_noc_rx_read_req_valid;
    assign revb_noc_rx_ready = (revb_noc_rx_opcode == REVB_NOC_OP_READ_RSP)  ? revb_noc_rx_read_rsp_ready :
                               (revb_noc_rx_opcode == REVB_NOC_OP_ERROR_RSP) ? revb_noc_rx_error_rsp_ready :
                               (revb_noc_rx_opcode == REVB_NOC_OP_READ_REQ)  ? revb_noc_rx_read_req_front_ready :
                                                                                1'b0;
    assign revb_noc_rx_read_rsp_fire = revb_noc_rx_is_read_rsp && revb_noc_rx_ready;
    assign revb_noc_rx_error_rsp_fire = revb_noc_rx_is_error_rsp && revb_noc_rx_ready;
    assign revb_noc_rx_read_req_front_fire = revb_noc_rx_is_read_req && revb_noc_rx_ready;

    assign revb_noc_rx_read_req_ready = remote_rd_req_intake_ready && !revb_noc_rx_is_read_req;
    assign remote_rd_enq_ready = remote_rd_req_intake_ready &&
                                 !revb_noc_rx_read_req_valid &&
                                 !revb_noc_rx_is_read_req;

    assign remote_rd_req_intake_valid = revb_noc_rx_read_req_valid || revb_noc_rx_read_req_front_fire || remote_rd_enq_valid;
    assign remote_rd_req_intake_bank_idx = revb_noc_rx_read_req_valid ?
        local_addr_to_bank_idx(revb_noc_rx_read_req_addr[LOCAL_ADDR_W-1:0]) :
        (revb_noc_rx_read_req_front_fire ? revb_noc_rx_decoded_bank_idx : remote_rd_enq_bank_idx);
    assign remote_rd_req_intake_line_addr = revb_noc_rx_read_req_valid ?
        local_addr_to_line_addr(revb_noc_rx_read_req_addr[LOCAL_ADDR_W-1:0]) :
        (revb_noc_rx_read_req_front_fire ? revb_noc_rx_decoded_line_addr : remote_rd_enq_line_addr);
    assign remote_rd_req_intake_tag = revb_noc_rx_read_req_valid ? revb_noc_rx_read_req_tag :
                                      (revb_noc_rx_read_req_front_fire ? revb_noc_rx_tag : remote_rd_enq_tag);
    assign remote_rd_req_intake_requester = revb_noc_rx_read_req_valid ? revb_noc_rx_read_req_requester :
                                            (revb_noc_rx_read_req_front_fire ? revb_noc_rx_requester : remote_rd_enq_requester);
    assign remote_rd_req_intake_path = revb_noc_rx_read_req_valid ? revb_noc_rx_read_req_path :
                                       (revb_noc_rx_read_req_front_fire ? revb_noc_rx_path : remote_rd_enq_path);

    assign remote_rd_req_enq_fire = remote_rd_req_intake_valid && remote_rd_req_intake_ready;

    assign remote_rd_rsp_valid = remote_rd_rsp_hold_valid_q;
    assign remote_rd_rsp_data = remote_rd_rsp_hold_data_q;
    assign remote_rd_rsp_tag = remote_rd_rsp_hold_tag_q;
    assign remote_rd_rsp_requester = remote_rd_rsp_hold_requester_q;
    assign remote_rd_rsp_path = remote_rd_rsp_hold_path_q;

    assign revb_noc_tx_read_rsp_valid = remote_rd_rsp_hold_valid_q;
    assign revb_noc_tx_read_rsp_opcode = 2'b00; // READ_RSP
    assign revb_noc_tx_read_rsp_data = remote_rd_rsp_hold_data_q;
    assign revb_noc_tx_read_rsp_tag = remote_rd_rsp_hold_tag_q;
    assign revb_noc_tx_read_rsp_requester = remote_rd_rsp_hold_requester_q;
    assign revb_noc_tx_read_rsp_path = remote_rd_rsp_hold_path_q;
    assign remote_rd_rsp_hold_fire = remote_rd_rsp_hold_valid_q &&
                                     (remote_rd_rsp_ready || revb_noc_tx_read_rsp_ready);

    logic [NUM_BANKS-1:0]                 hit_dma_same_bank;
    logic [NUM_BANKS-1:0]                 hit_dma_same_addr;
    logic [NUM_BANKS-1:0]                 do_forward_read;
    logic [NUM_BANKS-1:0]                 block_pe_write;
    logic [NUM_BANKS-1:0]                 hit_dma_protected_range;
    logic [NUM_BANKS-1:0]                 block_pe_write_range;
    logic [NUM_BANKS-1:0]                 rd_meta_valid;
    logic [NUM_BANKS-1:0][$clog2(NUM_PE)-1:0] rd_meta_pe_idx;
    logic [NUM_BANKS-1:0]                 rd_meta_is_scalar;
    logic [NUM_BANKS-1:0][LANE_IDX_W-1:0] rd_meta_lane_idx;
    logic [NUM_BANKS-1:0][PE_TAG_W-1:0]   rd_meta_tag;
    logic [NUM_BANKS-1:0]                 bank_portA_req_valid_i;
    logic [NUM_BANKS-1:0]                 bank_portA_req_write_i;
    logic [NUM_BANKS-1:0]                 bank_portA_is_scalar_i;
    logic [NUM_BANKS-1:0][LINE_ADDR_W-1:0] bank_portA_line_addr_i;
    logic [NUM_BANKS-1:0][LANE_IDX_W-1:0] bank_portA_lane_idx_i;
    logic [NUM_BANKS-1:0][VECTOR_W-1:0]   bank_portA_wdata_i;
    logic [NUM_BANKS-1:0][WSTRB_W-1:0]    bank_portA_wstrb_i;
    logic [NUM_BANKS-1:0]                 bank_portA_req_accepted_i;
    logic [NUM_BANKS-1:0]                 bank_portA_rsp_valid_i;
    logic [NUM_BANKS-1:0][VECTOR_W-1:0]   bank_portA_rdata_i;
    logic [NUM_BANKS-1:0]                 bank_portB_req_valid_i;
    logic [NUM_BANKS-1:0]                 bank_portB_req_write_i;
    logic [NUM_BANKS-1:0]                 bank_portB_is_scalar_i;
    logic [NUM_BANKS-1:0][LINE_ADDR_W-1:0] bank_portB_line_addr_i;
    logic [NUM_BANKS-1:0][LANE_IDX_W-1:0] bank_portB_lane_idx_i;
    logic [NUM_BANKS-1:0][VECTOR_W-1:0]   bank_portB_wdata_i;
    logic [NUM_BANKS-1:0][WSTRB_W-1:0]    bank_portB_wstrb_i;
    logic [NUM_BANKS-1:0]                 bank_portB_req_accepted_i;
    logic [NUM_BANKS-1:0]                 bank_portB_rsp_valid_i;
    logic [NUM_BANKS-1:0][VECTOR_W-1:0]   bank_portB_rdata_i;
    sv_smu_top #(
        .NUM_BANKS(NUM_BANKS)
    ) u_bank_fabric (
        .clk                    (clk),
        .rst_n                  (rst_n),
        .bank_portA_req_valid   (bank_portA_req_valid_i),
        .bank_portA_req_write   (bank_portA_req_write_i),
        .bank_portA_is_scalar   (bank_portA_is_scalar_i),
        .bank_portA_line_addr   (bank_portA_line_addr_i),
        .bank_portA_lane_idx    (bank_portA_lane_idx_i),
        .bank_portA_wdata       (bank_portA_wdata_i),
        .bank_portA_wstrb       (bank_portA_wstrb_i),
        .bank_portA_req_accepted(bank_portA_req_accepted_i),
        .bank_portA_rsp_valid   (bank_portA_rsp_valid_i),
        .bank_portA_rdata       (bank_portA_rdata_i),
        .bank_portB_req_valid   (bank_portB_req_valid_i),
        .bank_portB_req_write   (bank_portB_req_write_i),
        .bank_portB_is_scalar   (bank_portB_is_scalar_i),
        .bank_portB_line_addr   (bank_portB_line_addr_i),
        .bank_portB_lane_idx    (bank_portB_lane_idx_i),
        .bank_portB_wdata       (bank_portB_wdata_i),
        .bank_portB_wstrb       (bank_portB_wstrb_i),
        .bank_portB_req_accepted(bank_portB_req_accepted_i),
        .bank_portB_rsp_valid   (bank_portB_rsp_valid_i),
        .bank_portB_rdata       (bank_portB_rdata_i),
        .bank_hazard_same_addr  (bank_hazard_same_addr),
        .bank_hazard_blocked    (bank_hazard_blocked)
    );
    always_comb begin
        for (int i = 0; i < NUM_PE; i++) begin
            pe_is_read[i]   = pe_req_valid[i] && (pe_req_type[i] == 2'b00);
            pe_is_write[i]  = pe_req_valid[i] && (pe_req_type[i] == 2'b01);
            pe_is_scalar[i] = ~pe_req_is_vec[i];
            pe_bank_idx[i]  = local_addr_to_bank_idx(pe_req_addr[i]);
            pe_line_addr[i] = local_addr_to_line_addr(pe_req_addr[i]);
            pe_lane_idx[i]  = local_addr_to_lane_idx(pe_req_addr[i]);
            for (int b = 0; b < NUM_BANKS; b++) begin
                pe_hits_bank[i][b] = pe_req_valid[i] && (pe_bank_idx[i] == b[1:0]);
            end
        end
        dma_wb_bank_idx  = local_addr_to_bank_idx(dma_wb_addr);
        dma_wb_line_addr = local_addr_to_line_addr(dma_wb_addr);
    end
    // --------------------------------------------------------------------
    // Block logic: wbq_8entry + portA_service_arbiter candidate generation.
    // --------------------------------------------------------------------
    always_comb begin
        // RevB-RTL4 WBQ slot selection and per-bank drain candidate generation.
        // RTL-CLEAN-1C: this island is intentionally side-effect free with
        // respect to bank accept and NoC RX fire.  It computes only candidate
        // availability from registered state, breaking Verilator's false/real
        // comb loop between PortA service, bank accept, WBQ commit, and NoC RX ready.
        wbq_any_invalid = 1'b0;
        wbq_first_invalid_idx = '0;
        wbq_occupancy_count = '0;
        for (int i = 0; i < DMA_WBQ_DEPTH; i++) begin
            if (wbq_valid_q[i]) begin
                wbq_occupancy_count = wbq_occupancy_count + 4'd1;
            end
            if (!wbq_valid_q[i] && !wbq_any_invalid) begin
                wbq_any_invalid = 1'b1;
                wbq_first_invalid_idx = i[$clog2(DMA_WBQ_DEPTH)-1:0];
            end
        end
        wbq_almost_full = (wbq_occupancy_count >= DMA_WBQ_ALMOST_FULL_LEVEL);

        wbq_drain_valid = '0;
        wbq_drain_idx   = '0;
        for (int b = 0; b < NUM_BANKS; b++) begin
            for (int i = 0; i < DMA_WBQ_DEPTH; i++) begin
                if (wbq_valid_q[i] &&
                    (wbq_bank_idx_q[i] == b[1:0]) &&
                    !wbq_drain_valid[b]) begin
                    wbq_drain_valid[b] = 1'b1;
                    wbq_drain_idx[b]   = i[$clog2(DMA_WBQ_DEPTH)-1:0];
                end
            end
        end

        remote_rd_portA_candidate_valid = '0;
        if (remote_rd_req_hold_valid_q) begin
            remote_rd_portA_candidate_valid[remote_rd_req_hold_bank_idx_q] = 1'b1;
        end
        qr_preload_bank_idx = local_addr_to_bank_idx(qr_preload_req_addr);
        qr_preload_line_addr = local_addr_to_line_addr(qr_preload_req_addr);
        qr_preload_portA_candidate_valid = '0;
        if (qr_preload_req_valid && !qr_preload_pending_q)
            qr_preload_portA_candidate_valid[qr_preload_bank_idx] = 1'b1;

        portA_svc_valid     = '0;
        portA_svc_op        = '0;
        portA_svc_src       = '0;
        portA_svc_line_addr = '0;
        portA_svc_lane_idx  = '0;
        portA_svc_wdata     = '0;
        portA_svc_wstrb     = '0;

        // LP-3BE Port A service arbitration policy.
        // Keep the RevB deadlock-avoidance boost for an almost-full WBQ.
        // Otherwise use a simple per-bank 1-bit anti-starvation toggle:
        //   toggle=1 and remote valid -> remote READ first
        //   toggle=0 or no remote    -> WBQ drain first
        // Fallback order still guarantees service when only one source exists.
        for (int b = 0; b < NUM_BANKS; b++) begin
            if (wbq_almost_full && wbq_drain_valid[b]) begin
                portA_svc_valid[b]     = 1'b1;
                portA_svc_op[b]        = PORTA_OP_WRITE;
                portA_svc_src[b]       = PORTA_SRC_WBQ_DRAIN;
                portA_svc_line_addr[b] = wbq_line_addr_q[wbq_drain_idx[b]];
                portA_svc_lane_idx[b]  = '0;
                portA_svc_wdata[b]     = wbq_data_q[wbq_drain_idx[b]];
                portA_svc_wstrb[b]     = 4'hF;
            end else if (qr_preload_portA_candidate_valid[b]) begin
                portA_svc_valid[b]     = 1'b1;
                portA_svc_op[b]        = PORTA_OP_READ;
                portA_svc_src[b]       = PORTA_SRC_QR_PRELOAD;
                portA_svc_line_addr[b] = qr_preload_line_addr;
                portA_svc_lane_idx[b]  = '0;
                portA_svc_wdata[b]     = '0;
                portA_svc_wstrb[b]     = '0;
            end else if (portA_rr_toggle_q[b] && remote_rd_portA_candidate_valid[b]) begin
                portA_svc_valid[b]     = 1'b1;
                portA_svc_op[b]        = PORTA_OP_READ;
                portA_svc_src[b]       = PORTA_SRC_REMOTE_READ;
                portA_svc_line_addr[b] = remote_rd_req_hold_line_addr_q;
                portA_svc_lane_idx[b]  = '0;
                portA_svc_wdata[b]     = '0;
                portA_svc_wstrb[b]     = '0;
            end else if (wbq_drain_valid[b]) begin
                portA_svc_valid[b]     = 1'b1;
                portA_svc_op[b]        = PORTA_OP_WRITE;
                portA_svc_src[b]       = PORTA_SRC_WBQ_DRAIN;
                portA_svc_line_addr[b] = wbq_line_addr_q[wbq_drain_idx[b]];
                portA_svc_lane_idx[b]  = '0;
                portA_svc_wdata[b]     = wbq_data_q[wbq_drain_idx[b]];
                portA_svc_wstrb[b]     = 4'hF;
            end else if (remote_rd_portA_candidate_valid[b]) begin
                portA_svc_valid[b]     = 1'b1;
                portA_svc_op[b]        = PORTA_OP_READ;
                portA_svc_src[b]       = PORTA_SRC_REMOTE_READ;
                portA_svc_line_addr[b] = remote_rd_req_hold_line_addr_q;
                portA_svc_lane_idx[b]  = '0;
                portA_svc_wdata[b]     = '0;
                portA_svc_wstrb[b]     = '0;
            end
        end
    end

    always_comb begin
        // RTL-CLEAN-1C: bank accept is consumed only here.  Keeping commit/retry
        // generation out of the candidate-selection island prevents PortA service
        // valid from being perceived as depending on its own bank accept.
        wbq_entry_commit_fire = '0;
        wbq_entry_retry_fire  = '0;
        wbq_commit_valid = '0;
        wbq_commit_addr = '0;
        wbq_commit_data = '0;
        for (int b = 0; b < NUM_BANKS; b++) begin
            if (wbq_drain_valid[b] &&
                portA_svc_valid[b] &&
                (portA_svc_src[b] == PORTA_SRC_WBQ_DRAIN)) begin
                if (bank_portA_req_valid_i[b] && bank_portA_req_accepted_i[b]) begin
                    wbq_entry_commit_fire[wbq_drain_idx[b]] = 1'b1;
                    wbq_commit_valid[b] = 1'b1;
                    wbq_commit_addr[b] = wbq_addr_q[wbq_drain_idx[b]];
                    wbq_commit_data[b] = wbq_data_q[wbq_drain_idx[b]];
                end else begin
                    wbq_entry_retry_fire[wbq_drain_idx[b]] = 1'b1;
                end
            end
        end
    end

    always_comb begin
        // Duplicate READ_RSP guard uses registered WBQ state only.  It must not
        // depend on same-cycle WBQ commit/clear, otherwise NoC RX ready can become
        // coupled to the commit side of the WBQ drain pipeline.
        noc_rx_read_rsp_tag_pending_wbq = 1'b0;
        for (int i = 0; i < DMA_WBQ_DEPTH; i++) begin
            if (wbq_valid_q[i] &&
                wbq_completion_credit_q[i] &&
                (wbq_dma_tag_q[i] == revb_noc_rx_tag)) begin
                noc_rx_read_rsp_tag_pending_wbq = 1'b1;
            end
        end
    end

    always_comb begin
        // RTL-CLEAN-1A/1C: enqueue ready is based only on registered WBQ state.
        // Do not reclaim a slot from same-cycle commit for same-cycle enqueue.
        wbq_enq_ready = wbq_any_invalid;
        wbq_enq_idx   = wbq_first_invalid_idx;
    end

    always_comb begin
        // RevB producer-side normalization.
        // Producer priority map:
        //   Priority 0: wbq_enq_*                 = formal/final producer path
        //   Priority 1: revb_noc_rx READ_RSP      = NoC front-door producer
        //   Priority 2: dma_wb_*                  = legacy compatibility adapter
        // The selected request is normalized into wbq_enq_req_* before entering
        // the architectural WBQ storage.
        wbq_enq_req_valid                = wbq_enq_valid || revb_noc_rx_read_rsp_fire || dma_wb_valid;
        wbq_enq_req_bank_idx             = wbq_enq_valid ? wbq_enq_bank_idx :
                                           (revb_noc_rx_read_rsp_fire ? noc_rx_read_rsp_lookup_bank_idx : dma_wb_bank_idx);
        wbq_enq_req_line_addr            = wbq_enq_valid ? wbq_enq_line_addr :
                                           (revb_noc_rx_read_rsp_fire ? noc_rx_read_rsp_lookup_line_addr : dma_wb_line_addr);
        wbq_enq_req_addr                 = wbq_enq_valid ? bank_line_to_local_addr(wbq_enq_bank_idx, wbq_enq_line_addr) :
                                           (revb_noc_rx_read_rsp_fire ? noc_rx_read_rsp_lookup_local_addr : dma_wb_addr);
        wbq_enq_req_data                 = wbq_enq_valid ? wbq_enq_data :
                                           (revb_noc_rx_read_rsp_fire ? revb_noc_rx_data : dma_wb_data);
        wbq_enq_req_tag                  = wbq_enq_valid ? wbq_enq_tag :
                                           (revb_noc_rx_read_rsp_fire ? revb_noc_rx_tag : '0);
        wbq_enq_req_completion_credit    = wbq_enq_valid ? wbq_enq_completion_credit : 1'b1;
        wbq_enq_fire = wbq_enq_req_valid && wbq_enq_ready;

        wbq_any_valid = 1'b0;
        wbq_dbg_idx   = '0;
        for (int i = 0; i < DMA_WBQ_DEPTH; i++) begin
            if (wbq_valid_q[i] && !wbq_any_valid) begin
                wbq_any_valid = 1'b1;
                wbq_dbg_idx   = i[$clog2(DMA_WBQ_DEPTH)-1:0];
            end
        end

        // Compatibility effective-WB mirror.  Use portA_svc_* for architectural Port A
        // architecture reasoning; use wbq_* for final writeback queue state.
        dma_wb_eff_valid     = wbq_any_valid;
        dma_wb_eff_bank_idx  = wbq_any_valid ? wbq_bank_idx_q[wbq_dbg_idx]  : dma_wb_bank_idx;
        dma_wb_eff_line_addr = wbq_any_valid ? wbq_line_addr_q[wbq_dbg_idx] : dma_wb_line_addr;
        dma_wb_eff_lane0     = wbq_any_valid ? wbq_data_q[wbq_dbg_idx][31:0] : dma_wb_data[31:0];

        // Debug mirror of oldest WBQ entry under legacy pending-slot names.
        dma_wb_pending_valid     = wbq_any_valid;
        dma_wb_pending_addr      = wbq_any_valid ? wbq_addr_q[wbq_dbg_idx]      : '0;
    end

    always_comb begin
        qr_preload_req_ready = 1'b0;
        qr_preload_issue_fire = 1'b0;
        if (qr_preload_req_valid && !qr_preload_pending_q &&
            portA_svc_valid[qr_preload_bank_idx] &&
            (portA_svc_src[qr_preload_bank_idx] == PORTA_SRC_QR_PRELOAD) &&
            bank_portA_req_valid_i[qr_preload_bank_idx] &&
            bank_portA_req_accepted_i[qr_preload_bank_idx]) begin
            qr_preload_req_ready = 1'b1;
            qr_preload_issue_fire = 1'b1;
        end
        qr_preload_rsp_valid = qr_preload_pending_q &&
                               bank_portA_rsp_valid_i[qr_preload_pending_bank_q];
        qr_preload_rsp_data = bank_portA_rdata_i[qr_preload_pending_bank_q];
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            qr_preload_pending_q <= 1'b0;
            qr_preload_pending_bank_q <= '0;
        end else begin
            if (qr_preload_rsp_valid)
                qr_preload_pending_q <= 1'b0;
            if (qr_preload_issue_fire) begin
                qr_preload_pending_q <= 1'b1;
                qr_preload_pending_bank_q <= qr_preload_bank_idx;
            end
        end
    end

    always_comb begin
        remote_rd_req_issue_fire = 1'b0;
        for (int b = 0; b < NUM_BANKS; b++) begin
            remote_rd_rsp_capture_fire[b] = 1'b0;
        end
        remote_rd_rsp_hold_capture_fire = 1'b0;
        remote_rd_rsp_hold_capture_bank = '0;

        if (remote_rd_req_hold_valid_q) begin
            remote_rd_req_issue_fire =
                portA_svc_valid[remote_rd_req_hold_bank_idx_q] &&
                (portA_svc_src[remote_rd_req_hold_bank_idx_q] == PORTA_SRC_REMOTE_READ) &&
                bank_portA_req_valid_i[remote_rd_req_hold_bank_idx_q] &&
                bank_portA_req_accepted_i[remote_rd_req_hold_bank_idx_q];
        end

        for (int b = 0; b < NUM_BANKS; b++) begin
            remote_rd_rsp_capture_fire[b] = remote_rd_pending_rsp_valid_q[b] &&
                                            bank_portA_rsp_valid_i[b] &&
                                            (!remote_rd_rsp_hold_valid_q || remote_rd_rsp_hold_fire) &&
                                            !remote_rd_rsp_hold_capture_fire;
            if (remote_rd_rsp_capture_fire[b]) begin
                remote_rd_rsp_hold_capture_fire = 1'b1;
                remote_rd_rsp_hold_capture_bank = b[1:0];
            end
        end
    end

    always_comb begin
        wbq_valid_count = '0;
        wbq_parallel_candidate_count = '0;
        wbq_parallel_commit_count = '0;
        for (int i = 0; i < DMA_WBQ_DEPTH; i++) begin
            if (wbq_valid_q[i]) begin
                wbq_valid_count = wbq_valid_count + 4'd1;
            end
            if (wbq_entry_commit_fire[i]) begin
                wbq_parallel_commit_count = wbq_parallel_commit_count + 3'd1;
            end
        end
        for (int b = 0; b < NUM_BANKS; b++) begin
            if (wbq_drain_valid[b]) begin
                wbq_parallel_candidate_count = wbq_parallel_candidate_count + 3'd1;
            end
        end
    end

    always_comb begin
        for (int b = 0; b < NUM_BANKS; b++) begin
            sel_pe_valid[b]      = 1'b0;
            sel_pe_idx[b]        = '0;
            sel_pe_is_read[b]    = 1'b0;
            sel_pe_is_write[b]   = 1'b0;
            sel_pe_is_scalar[b]  = 1'b0;
            sel_pe_line_addr[b]  = '0;
            sel_pe_lane_idx[b]   = '0;
            sel_pe_wdata[b]      = '0;
            sel_pe_wstrb[b]      = '0;
            sel_pe_tag[b]        = '0;
            if (pe_hits_bank[0][b]) begin
                sel_pe_valid[b] = 1'b1;
                sel_pe_idx[b]   = 0;
            end else if (pe_hits_bank[1][b]) begin
                sel_pe_valid[b] = 1'b1;
                sel_pe_idx[b]   = 1;
            end else if (pe_hits_bank[2][b]) begin
                sel_pe_valid[b] = 1'b1;
                sel_pe_idx[b]   = 2;
            end else if (pe_hits_bank[3][b]) begin
                sel_pe_valid[b] = 1'b1;
                sel_pe_idx[b]   = 3;
            end
            if (sel_pe_valid[b]) begin
                sel_pe_is_read[b]   = pe_is_read[sel_pe_idx[b]];
                sel_pe_is_write[b]  = pe_is_write[sel_pe_idx[b]];
                sel_pe_is_scalar[b] = pe_is_scalar[sel_pe_idx[b]];
                sel_pe_line_addr[b] = pe_line_addr[sel_pe_idx[b]];
                sel_pe_lane_idx[b]  = pe_lane_idx[sel_pe_idx[b]];
                sel_pe_wdata[b]     = pe_req_data[sel_pe_idx[b]];
                sel_pe_wstrb[b]     = pe_req_wstrb[sel_pe_idx[b]];
                sel_pe_tag[b]       = pe_req_tag[sel_pe_idx[b]];
            end
        end
    end
    always_comb begin
        for (int b = 0; b < NUM_BANKS; b++) begin
            hit_dma_same_bank[b] = portA_svc_valid[b] && (portA_svc_op[b] == PORTA_OP_WRITE);
            hit_dma_same_addr[b] = hit_dma_same_bank[b] &&
                                   sel_pe_valid[b] &&
                                   (portA_svc_line_addr[b] == sel_pe_line_addr[b]);
            do_forward_read[b]   = hit_dma_same_addr[b] && sel_pe_is_read[b];
            block_pe_write[b]    = sel_pe_is_write[b] &&
                                   sel_pe_valid[b] &&
                                   portA_svc_valid[b] &&
                                   (portA_svc_line_addr[b] == sel_pe_line_addr[b]) &&
                                   ((portA_svc_op[b] == PORTA_OP_WRITE) ||
                                    (portA_svc_op[b] == PORTA_OP_READ));
            hit_dma_protected_range[b] = sel_pe_valid[b] &&
                                         dma_local_dst_active &&
                                         sel_pe_is_write[b] &&
                                         (bank_line_to_local_addr(b[1:0], sel_pe_line_addr[b]) >= dma_local_dst_start) &&
                                         (bank_line_to_local_addr(b[1:0], sel_pe_line_addr[b]) <= dma_local_dst_end);
            block_pe_write_range[b] = hit_dma_protected_range[b];
        end
    end
    always_comb begin
        bank_portA_req_valid_i = '0;
        bank_portA_req_write_i = '0;
        bank_portA_is_scalar_i = '0;
        bank_portA_line_addr_i = '0;
        bank_portA_lane_idx_i  = '0;
        bank_portA_wdata_i     = '0;
        bank_portA_wstrb_i     = '0;
        bank_portB_req_valid_i = '0;
        bank_portB_req_write_i = '0;
        bank_portB_is_scalar_i = '0;
        bank_portB_line_addr_i = '0;
        bank_portB_lane_idx_i  = '0;
        bank_portB_wdata_i     = '0;
        bank_portB_wstrb_i     = '0;
        pe_req_ready           = '0;
        for (int b = 0; b < NUM_BANKS; b++) begin
            if (portA_svc_valid[b]) begin
                bank_portA_req_valid_i[b] = 1'b1;
                bank_portA_req_write_i[b] = (portA_svc_op[b] == PORTA_OP_WRITE);
                bank_portA_is_scalar_i[b] = 1'b0;
                bank_portA_line_addr_i[b] = portA_svc_line_addr[b];
                bank_portA_lane_idx_i[b]  = portA_svc_lane_idx[b];
                bank_portA_wstrb_i[b]     = portA_svc_wstrb[b];
                bank_portA_wdata_i[b]     = portA_svc_wdata[b];
            end
            if (sel_pe_valid[b]) begin
                if (do_forward_read[b]) begin
                    pe_req_ready[sel_pe_idx[b]] = 1'b1;
                end else if (block_pe_write[b]) begin
                    pe_req_ready[sel_pe_idx[b]] = 1'b0;
                end else if (block_pe_write_range[b]) begin
                    pe_req_ready[sel_pe_idx[b]] = 1'b0;
                end else begin
                    bank_portB_req_valid_i[b] = 1'b1;
                    bank_portB_req_write_i[b] = sel_pe_is_write[b];
                    bank_portB_is_scalar_i[b] = sel_pe_is_scalar[b];
                    bank_portB_line_addr_i[b] = sel_pe_line_addr[b];
                    bank_portB_lane_idx_i[b]  = sel_pe_lane_idx[b];
                    bank_portB_wstrb_i[b]     = sel_pe_wstrb[b];
                    bank_portB_wdata_i[b]     = sel_pe_wdata[b];
                    pe_req_ready[sel_pe_idx[b]] = bank_portB_req_accepted_i[b];
                end
            end
        end
    end
    always_comb begin
        for (int i = 0; i < NUM_PE; i++) begin
            pe_rsp_valid[i] = 1'b0;
            pe_rsp_kind[i]  = 1'b0; // READ_RSP
            pe_rsp_err[i]   = 1'b0;
            pe_rsp_data[i]  = '0;
            pe_rsp_tag[i]   = '0;
        end
        for (int b = 0; b < NUM_BANKS; b++) begin
            if (sel_pe_valid[b] && do_forward_read[b]) begin
                pe_rsp_valid[sel_pe_idx[b]] = 1'b1;
                pe_rsp_kind[sel_pe_idx[b]]  = 1'b0; // READ_RSP
                pe_rsp_err[sel_pe_idx[b]]   = 1'b0;
                pe_rsp_tag[sel_pe_idx[b]]   = sel_pe_tag[b];
                if (sel_pe_is_scalar[b]) begin
                    pe_rsp_data[sel_pe_idx[b]]        = '0;
                    pe_rsp_data[sel_pe_idx[b]][31:0]  = vec_lane32(portA_svc_wdata[b], sel_pe_lane_idx[b]);
                end else begin
                    pe_rsp_data[sel_pe_idx[b]] = portA_svc_wdata[b];
                end
            end
        end
        for (int b = 0; b < NUM_BANKS; b++) begin
            if (rd_meta_valid[b] && bank_portB_rsp_valid_i[b]) begin
                pe_rsp_valid[rd_meta_pe_idx[b]] = 1'b1;
                pe_rsp_kind[rd_meta_pe_idx[b]]  = 1'b0; // READ_RSP
                pe_rsp_err[rd_meta_pe_idx[b]]   = 1'b0;
                pe_rsp_tag[rd_meta_pe_idx[b]]   = rd_meta_tag[b];
                if (rd_meta_is_scalar[b]) begin
                    pe_rsp_data[rd_meta_pe_idx[b]]       = '0;
                    pe_rsp_data[rd_meta_pe_idx[b]][31:0] = vec_lane32(bank_portB_rdata_i[b], rd_meta_lane_idx[b]);
                end else begin
                    pe_rsp_data[rd_meta_pe_idx[b]] = bank_portB_rdata_i[b];
                end
            end
        end
    end
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (int b = 0; b < NUM_BANKS; b++) begin
                rd_meta_valid[b]     <= 1'b0;
                rd_meta_pe_idx[b]    <= '0;
                rd_meta_is_scalar[b] <= 1'b0;
                rd_meta_lane_idx[b]  <= '0;
                rd_meta_tag[b]       <= '0;
            end
        end else begin
            for (int b = 0; b < NUM_BANKS; b++) begin
                if (bank_portB_req_valid_i[b] && bank_portB_req_accepted_i[b] && ~bank_portB_req_write_i[b]) begin
                    rd_meta_valid[b]     <= 1'b1;
                    rd_meta_pe_idx[b]    <= sel_pe_idx[b];
                    rd_meta_is_scalar[b] <= sel_pe_is_scalar[b];
                    rd_meta_lane_idx[b]  <= sel_pe_lane_idx[b];
                    rd_meta_tag[b]       <= sel_pe_tag[b];
                end else if (bank_portB_rsp_valid_i[b]) begin
                    rd_meta_valid[b] <= 1'b0;
                end
            end
        end
    end
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            dma_issue_active_q <= 1'b0;
            dma_issue_tag_candidate_q <= '0;
            phase11p_outstanding_valid_q <= '0;
            phase11p_outstanding_count_q <= '0;
            for (int i = 0; i < DMA_OUTSTANDING_SHADOW_MAX; i++) begin
                phase11p_outstanding_tag_q[i]        <= '0;
                phase11p_outstanding_dst_global_q[i] <= '0;
            end
        end else begin
            dma_issue_active_q <= dma_issue_active;
            dma_issue_tag_candidate_q <= dma_issue_tag_candidate;
            phase11p_outstanding_valid_q <= phase11p_valid_next;
            phase11p_outstanding_count_q <= phase11p_count_next;

            if (phase11p_insert_fire) begin
                phase11p_outstanding_tag_q[phase11p_insert_idx]        <= dma_issue_tag_candidate;
                phase11p_outstanding_dst_global_q[phase11p_insert_idx] <= dma_issue_dst_base;
            end

            if (phase11p_clear_fire && !phase11p_insert_fire) begin
                phase11p_outstanding_tag_q[phase11p_clear_idx]        <= '0;
                phase11p_outstanding_dst_global_q[phase11p_clear_idx] <= '0;
            end
        end
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            portA_rr_toggle_q <= '0;
        end else begin
            for (int b = 0; b < NUM_BANKS; b++) begin
                if (portA_svc_valid[b] &&
                    bank_portA_req_valid_i[b] &&
                    bank_portA_req_accepted_i[b]) begin
                    if (portA_svc_src[b] == PORTA_SRC_WBQ_DRAIN) begin
                        // After WBQ service, give same-bank remote READ the next
                        // normal-priority opportunity.
                        portA_rr_toggle_q[b] <= 1'b1;
                    end else if (portA_svc_src[b] == PORTA_SRC_REMOTE_READ) begin
                        // After remote service, give same-bank WBQ drain the next
                        // normal-priority opportunity.
                        portA_rr_toggle_q[b] <= 1'b0;
                    end
                end
            end
        end
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            remote_rd_req_hold_valid_q      <= 1'b0;
            remote_rd_req_hold_bank_idx_q   <= '0;
            remote_rd_req_hold_line_addr_q  <= '0;
            remote_rd_req_hold_tag_q        <= '0;
            remote_rd_req_hold_requester_q  <= '0;
            remote_rd_req_hold_path_q       <= 1'b0;
            remote_rd_pending_rsp_valid_q   <= '0;
            remote_rd_pending_rsp_tag_q     <= '0;
            remote_rd_pending_rsp_requester_q <= '0;
            remote_rd_pending_rsp_path_q    <= '0;
            remote_rd_rsp_hold_valid_q      <= 1'b0;
            remote_rd_rsp_hold_data_q       <= '0;
            remote_rd_rsp_hold_tag_q        <= '0;
            remote_rd_rsp_hold_requester_q  <= '0;
            remote_rd_rsp_hold_path_q       <= 1'b0;
        end else begin
            // RevB-RTL3 adds an explicit internal enqueue side for remote READ_REQ.
            // It is still protocol-neutral: a future NoC RX decoder can drive
            // remote_rd_enq_* without changing the Port A service datapath.
            if (remote_rd_req_issue_fire) begin
                remote_rd_req_hold_valid_q <= 1'b0;
                remote_rd_pending_rsp_valid_q[remote_rd_req_hold_bank_idx_q] <= 1'b1;
                remote_rd_pending_rsp_tag_q[remote_rd_req_hold_bank_idx_q] <= remote_rd_req_hold_tag_q;
                remote_rd_pending_rsp_requester_q[remote_rd_req_hold_bank_idx_q] <= remote_rd_req_hold_requester_q;
                remote_rd_pending_rsp_path_q[remote_rd_req_hold_bank_idx_q] <= remote_rd_req_hold_path_q;
            end

            if (remote_rd_req_enq_fire) begin
                remote_rd_req_hold_valid_q     <= 1'b1;
                remote_rd_req_hold_bank_idx_q  <= remote_rd_req_intake_bank_idx;
                remote_rd_req_hold_line_addr_q <= remote_rd_req_intake_line_addr;
                remote_rd_req_hold_tag_q       <= remote_rd_req_intake_tag;
                remote_rd_req_hold_requester_q <= remote_rd_req_intake_requester;
                remote_rd_req_hold_path_q      <= remote_rd_req_intake_path;
            end

            if (remote_rd_rsp_hold_fire) begin
                remote_rd_rsp_hold_valid_q <= 1'b0;
            end

            if (remote_rd_rsp_hold_capture_fire) begin
                remote_rd_rsp_hold_valid_q <= 1'b1;
                remote_rd_rsp_hold_data_q  <= bank_portA_rdata_i[remote_rd_rsp_hold_capture_bank];
                remote_rd_rsp_hold_tag_q   <= remote_rd_pending_rsp_tag_q[remote_rd_rsp_hold_capture_bank];
                remote_rd_rsp_hold_requester_q <= remote_rd_pending_rsp_requester_q[remote_rd_rsp_hold_capture_bank];
                remote_rd_rsp_hold_path_q  <= remote_rd_pending_rsp_path_q[remote_rd_rsp_hold_capture_bank];
                remote_rd_pending_rsp_valid_q[remote_rd_rsp_hold_capture_bank] <= 1'b0;
            end
        end
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wbq_valid_q       <= '0;
            wbq_addr_q        <= '0;
            wbq_data_q        <= '0;
            wbq_bank_idx_q    <= '0;
            wbq_line_addr_q   <= '0;
            wbq_dma_tag_q     <= '0;
            wbq_completion_credit_q <= '0;
            wbq_retry_count_q <= '0;
        end else begin
            for (int i = 0; i < DMA_WBQ_DEPTH; i++) begin
                if (wbq_entry_commit_fire[i] &&
                    !(wbq_enq_fire && (wbq_enq_idx == i[$clog2(DMA_WBQ_DEPTH)-1:0]))) begin
                    wbq_valid_q[i] <= 1'b0;
                    wbq_completion_credit_q[i] <= 1'b0;
                end else if (wbq_entry_retry_fire[i] && wbq_valid_q[i]) begin
                    wbq_retry_count_q[i] <= wbq_retry_count_q[i] + 4'd1;
                end
            end

            if (wbq_enq_fire) begin
                wbq_valid_q[wbq_enq_idx]       <= 1'b1;
                wbq_addr_q[wbq_enq_idx]        <= wbq_enq_req_addr;
                wbq_data_q[wbq_enq_idx]        <= wbq_enq_req_data;
                wbq_bank_idx_q[wbq_enq_idx]    <= wbq_enq_req_bank_idx;
                wbq_line_addr_q[wbq_enq_idx]   <= wbq_enq_req_line_addr;
                wbq_dma_tag_q[wbq_enq_idx]     <= wbq_enq_req_tag;
                wbq_completion_credit_q[wbq_enq_idx] <= wbq_enq_req_completion_credit;
                wbq_retry_count_q[wbq_enq_idx] <= '0;
            end
        end
    end
    assign dma_wb_meta_valid          = dma_wb_eff_valid;
    assign dma_wb_meta_pending        = dma_wb_pending_valid;
    assign dma_wb_meta_local_addr     = dma_wb_eff_valid ? (dma_wb_pending_valid ? dma_wb_pending_addr : dma_wb_addr) : '0;
    assign dma_wb_meta_bank_idx       = dma_wb_eff_valid ? dma_wb_eff_bank_idx : '0;
    assign dma_wb_meta_line_addr      = dma_wb_eff_valid ? dma_wb_eff_line_addr : '0;
    assign dma_wb_meta_lane0          = dma_wb_eff_valid ? dma_wb_eff_lane0 : '0;
    assign pe_protect_hit                 = hit_dma_protected_range;
// ============================================================================
// End of sv_smu_sched_top_lean_internal boundary region.
// ============================================================================
endmodule


// ============================================================================
// SYNTHESIS-FACING CLEAN TOP-LEVEL
// ----------------------------------------------------------------------------
// This module intentionally keeps the synthesis-facing sv_smu_sched_top
// boundary free of dbg_*, *_shadow*, perf*, contract/evidence, and revb_obs_*
// ports.  Legacy observation signals are local-only compatibility adapters and
// do not appear on the public RTL boundary.  Use this file/top for the
// synthesis-facing Lean Performance build.
// ============================================================================
module sv_smu_sched_top #(

    parameter int NUM_PE       = 4,
    parameter int NUM_BANKS    = 4,
    parameter int LOCAL_ADDR_W = 15,
    parameter int LINE_ADDR_W  = 8,
    parameter int GLOBAL_ADDR_W = 19,
    parameter int VECTOR_W     = 256,
    parameter int PE_TAG_W     = 4,
    parameter int WSTRB_W      = 4,
    parameter int DMA_TAG_W    = 4,
    parameter int DMA_CNT_W    = 8

) (
    input  logic                         clk,
    input  logic                         rst_n,
    input  logic [NUM_PE-1:0]                    pe_req_valid,
    output logic [NUM_PE-1:0]                    pe_req_ready,
    input  logic [NUM_PE-1:0][1:0]               pe_req_type,
    input  logic [NUM_PE-1:0]                    pe_req_is_vec,
    input  logic [NUM_PE-1:0][LOCAL_ADDR_W-1:0]  pe_req_addr,
    input  logic [NUM_PE-1:0][VECTOR_W-1:0]      pe_req_data,
    input  logic [NUM_PE-1:0][WSTRB_W-1:0]       pe_req_wstrb,
    input  logic [NUM_PE-1:0][PE_TAG_W-1:0]      pe_req_tag,
    // Dedicated QR pivot-preload vector read on the architectural non-PE
    // service Port A. One request may be outstanding.
    input  logic                                 qr_preload_req_valid,
    output logic                                 qr_preload_req_ready,
    input  logic [LOCAL_ADDR_W-1:0]              qr_preload_req_addr,
    output logic                                 qr_preload_rsp_valid,
    output logic [VECTOR_W-1:0]                  qr_preload_rsp_data,
    input  logic                                 dma_wb_valid,
    input  logic [LOCAL_ADDR_W-1:0]              dma_wb_addr,
    input  logic [VECTOR_W-1:0]                  dma_wb_data,
    input  logic                                 wbq_enq_valid,
    output logic                                 wbq_enq_ready,
    input  logic [1:0]                           wbq_enq_bank_idx,
    input  logic [LINE_ADDR_W-1:0]               wbq_enq_line_addr,
    input  logic [VECTOR_W-1:0]                  wbq_enq_data,
    input  logic [DMA_TAG_W-1:0]                 wbq_enq_tag,
    input  logic [2:0]                           wbq_enq_src_kind,
    input  logic                                 wbq_enq_completion_credit,
    input  logic                                 dma_local_dst_active,
    input  logic [LOCAL_ADDR_W-1:0]              dma_local_dst_start,
    input  logic [LOCAL_ADDR_W-1:0]              dma_local_dst_end,
    input  logic                                 dma_issue_active,
    input  logic                                 dma_issue_error,
    input  logic [7:0]                           dma_issue_holdoff,
    input  logic [GLOBAL_ADDR_W-1:0]             dma_issue_src_base,
    input  logic [GLOBAL_ADDR_W-1:0]             dma_issue_dst_base,
    input  logic [DMA_TAG_W-1:0]                 dma_issue_tag_candidate,
    input  logic                                 revb_noc_rx_valid,
    output logic                                 revb_noc_rx_ready,
    input  logic [1:0]                           revb_noc_rx_opcode,
    input  logic [GLOBAL_ADDR_W-1:0]             revb_noc_rx_addr,
    input  logic [VECTOR_W-1:0]                  revb_noc_rx_data,
    input  logic [DMA_TAG_W-1:0]                 revb_noc_rx_tag,
    input  logic [3:0]                           revb_noc_rx_requester,
    input  logic                                 revb_noc_rx_path,
    input  logic                                 revb_noc_rx_read_req_valid,
    output logic                                 revb_noc_rx_read_req_ready,
    input  logic [GLOBAL_ADDR_W-1:0]             revb_noc_rx_read_req_addr,
    input  logic [DMA_TAG_W-1:0]                 revb_noc_rx_read_req_tag,
    input  logic [3:0]                           revb_noc_rx_read_req_requester,
    input  logic                                 revb_noc_rx_read_req_path,
    output logic                                 revb_noc_tx_read_rsp_valid,
    input  logic                                 revb_noc_tx_read_rsp_ready,
    output logic [1:0]                           revb_noc_tx_read_rsp_opcode,
    output logic [VECTOR_W-1:0]                  revb_noc_tx_read_rsp_data,
    output logic [DMA_TAG_W-1:0]                 revb_noc_tx_read_rsp_tag,
    output logic [3:0]                           revb_noc_tx_read_rsp_requester,
    output logic                                 revb_noc_tx_read_rsp_path,
    input  logic                                 remote_rd_enq_valid,
    output logic                                 remote_rd_enq_ready,
    input  logic [1:0]                           remote_rd_enq_bank_idx,
    input  logic [LINE_ADDR_W-1:0]               remote_rd_enq_line_addr,
    input  logic [DMA_TAG_W-1:0]                 remote_rd_enq_tag,
    input  logic [3:0]                           remote_rd_enq_requester,
    input  logic                                 remote_rd_enq_path,
    output logic                                 remote_rd_rsp_valid,
    input  logic                                 remote_rd_rsp_ready,
    output logic [VECTOR_W-1:0]                  remote_rd_rsp_data,
    output logic [DMA_TAG_W-1:0]                 remote_rd_rsp_tag,
    output logic [3:0]                           remote_rd_rsp_requester,
    output logic                                 remote_rd_rsp_path,
    output logic [NUM_PE-1:0]                    pe_rsp_valid,
    input  logic [NUM_PE-1:0]                    pe_rsp_ready,
    output logic [NUM_PE-1:0]                    pe_rsp_kind,
    output logic [NUM_PE-1:0]                    pe_rsp_err,
    output logic [NUM_PE-1:0][VECTOR_W-1:0]      pe_rsp_data,
    output logic [NUM_PE-1:0][PE_TAG_W-1:0]      pe_rsp_tag,
    output logic [NUM_BANKS-1:0]                 bank_hazard_same_addr,
    output logic [NUM_BANKS-1:0]                 bank_hazard_blocked,
    output logic                                 dma_wb_meta_valid,
    output logic                                 dma_wb_meta_pending,
    output logic [LOCAL_ADDR_W-1:0]              dma_wb_meta_local_addr,
    output logic [1:0]                           dma_wb_meta_bank_idx,
    output logic [LINE_ADDR_W-1:0]               dma_wb_meta_line_addr,
    output logic [31:0]                          dma_wb_meta_lane0,
    output logic [NUM_BANKS-1:0]                 wbq_commit_valid,
    output logic [NUM_BANKS-1:0][LOCAL_ADDR_W-1:0] wbq_commit_addr,
    output logic [NUM_BANKS-1:0][VECTOR_W-1:0]   wbq_commit_data,
    output logic [NUM_PE-1:0]                    pe_protect_hit
);

    sv_smu_sched_top_lean_internal #(
        .NUM_PE(NUM_PE),
        .NUM_BANKS(NUM_BANKS),
        .LOCAL_ADDR_W(LOCAL_ADDR_W),
        .LINE_ADDR_W(LINE_ADDR_W),
        .GLOBAL_ADDR_W(GLOBAL_ADDR_W),
        .VECTOR_W(VECTOR_W),
        .PE_TAG_W(PE_TAG_W),
        .WSTRB_W(WSTRB_W),
        .DMA_TAG_W(DMA_TAG_W),
        .DMA_CNT_W(DMA_CNT_W)
    ) u_lean_internal (
        .clk(clk),
        .rst_n(rst_n),
        .pe_req_valid(pe_req_valid),
        .pe_req_ready(pe_req_ready),
        .pe_req_type(pe_req_type),
        .pe_req_is_vec(pe_req_is_vec),
        .pe_req_addr(pe_req_addr),
        .pe_req_data(pe_req_data),
        .pe_req_wstrb(pe_req_wstrb),
        .pe_req_tag(pe_req_tag),
        .qr_preload_req_valid(qr_preload_req_valid),
        .qr_preload_req_ready(qr_preload_req_ready),
        .qr_preload_req_addr(qr_preload_req_addr),
        .qr_preload_rsp_valid(qr_preload_rsp_valid),
        .qr_preload_rsp_data(qr_preload_rsp_data),
        .dma_wb_valid(dma_wb_valid),
        .dma_wb_addr(dma_wb_addr),
        .dma_wb_data(dma_wb_data),
        .wbq_enq_valid(wbq_enq_valid),
        .wbq_enq_ready(wbq_enq_ready),
        .wbq_enq_bank_idx(wbq_enq_bank_idx),
        .wbq_enq_line_addr(wbq_enq_line_addr),
        .wbq_enq_data(wbq_enq_data),
        .wbq_enq_tag(wbq_enq_tag),
        .wbq_enq_src_kind(wbq_enq_src_kind),
        .wbq_enq_completion_credit(wbq_enq_completion_credit),
        .dma_local_dst_active(dma_local_dst_active),
        .dma_local_dst_start(dma_local_dst_start),
        .dma_local_dst_end(dma_local_dst_end),
        .dma_issue_active(dma_issue_active),
        .dma_issue_error(dma_issue_error),
        .dma_issue_holdoff(dma_issue_holdoff),
        .dma_issue_src_base(dma_issue_src_base),
        .dma_issue_dst_base(dma_issue_dst_base),
        .dma_issue_tag_candidate(dma_issue_tag_candidate),
        .revb_noc_rx_valid(revb_noc_rx_valid),
        .revb_noc_rx_ready(revb_noc_rx_ready),
        .revb_noc_rx_opcode(revb_noc_rx_opcode),
        .revb_noc_rx_addr(revb_noc_rx_addr),
        .revb_noc_rx_data(revb_noc_rx_data),
        .revb_noc_rx_tag(revb_noc_rx_tag),
        .revb_noc_rx_requester(revb_noc_rx_requester),
        .revb_noc_rx_path(revb_noc_rx_path),
        .revb_noc_rx_read_req_valid(revb_noc_rx_read_req_valid),
        .revb_noc_rx_read_req_ready(revb_noc_rx_read_req_ready),
        .revb_noc_rx_read_req_addr(revb_noc_rx_read_req_addr),
        .revb_noc_rx_read_req_tag(revb_noc_rx_read_req_tag),
        .revb_noc_rx_read_req_requester(revb_noc_rx_read_req_requester),
        .revb_noc_rx_read_req_path(revb_noc_rx_read_req_path),
        .revb_noc_tx_read_rsp_valid(revb_noc_tx_read_rsp_valid),
        .revb_noc_tx_read_rsp_ready(revb_noc_tx_read_rsp_ready),
        .revb_noc_tx_read_rsp_opcode(revb_noc_tx_read_rsp_opcode),
        .revb_noc_tx_read_rsp_data(revb_noc_tx_read_rsp_data),
        .revb_noc_tx_read_rsp_tag(revb_noc_tx_read_rsp_tag),
        .revb_noc_tx_read_rsp_requester(revb_noc_tx_read_rsp_requester),
        .revb_noc_tx_read_rsp_path(revb_noc_tx_read_rsp_path),
        .remote_rd_enq_valid(remote_rd_enq_valid),
        .remote_rd_enq_ready(remote_rd_enq_ready),
        .remote_rd_enq_bank_idx(remote_rd_enq_bank_idx),
        .remote_rd_enq_line_addr(remote_rd_enq_line_addr),
        .remote_rd_enq_tag(remote_rd_enq_tag),
        .remote_rd_enq_requester(remote_rd_enq_requester),
        .remote_rd_enq_path(remote_rd_enq_path),
        .remote_rd_rsp_valid(remote_rd_rsp_valid),
        .remote_rd_rsp_ready(remote_rd_rsp_ready),
        .remote_rd_rsp_data(remote_rd_rsp_data),
        .remote_rd_rsp_tag(remote_rd_rsp_tag),
        .remote_rd_rsp_requester(remote_rd_rsp_requester),
        .remote_rd_rsp_path(remote_rd_rsp_path),
        .pe_rsp_valid(pe_rsp_valid),
        .pe_rsp_ready(pe_rsp_ready),
        .pe_rsp_kind(pe_rsp_kind),
        .pe_rsp_err(pe_rsp_err),
        .pe_rsp_data(pe_rsp_data),
        .pe_rsp_tag(pe_rsp_tag),
        .bank_hazard_same_addr(bank_hazard_same_addr),
        .bank_hazard_blocked(bank_hazard_blocked),
        .dma_wb_meta_valid(dma_wb_meta_valid),
        .dma_wb_meta_pending(dma_wb_meta_pending),
        .dma_wb_meta_local_addr(dma_wb_meta_local_addr),
        .dma_wb_meta_bank_idx(dma_wb_meta_bank_idx),
        .dma_wb_meta_line_addr(dma_wb_meta_line_addr),
        .dma_wb_meta_lane0(dma_wb_meta_lane0),
        .wbq_commit_valid(wbq_commit_valid),
        .wbq_commit_addr(wbq_commit_addr),
        .wbq_commit_data(wbq_commit_data),
        .pe_protect_hit(pe_protect_hit)
    );
endmodule
