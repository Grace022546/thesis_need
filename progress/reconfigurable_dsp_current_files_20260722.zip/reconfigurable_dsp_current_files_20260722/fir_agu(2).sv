`timescale 1ns/1ps
import cgra_rtl_pkg::*;

module fir_agu #(
  parameter int P_N_PE = N_PE,
  parameter int P_LANES = LANES,
  parameter int P_INDEX_W = FIR_INDEX_W
) (
  input  logic clk_i,
  input  logic rst_ni,

  input  logic                     start_valid_i,
  output logic                     start_ready_o,
  input  logic [FIR_BATCH_W-1:0]   batch_id_i,
  input  logic [FIR_TAPS_W-1:0]    n_taps_i,
  input  logic [FIR_SAMPLES_W-1:0] n_samples_i,
  input  logic [2:0]               active_count_i,

  input  logic                     advance_i,
  output logic                     active_o,
  output logic                     group_done_o,
  output logic [7:0]               k_group_o,
  output logic [7:0]               k_group_limit_o,

  // Flattened [PE][lane] scalar indices and validity.  Index order is
  // ((pe * P_LANES) + lane).
  output logic [P_N_PE*P_LANES-1:0]               x_valid_o,
  output logic [P_N_PE*P_LANES*P_INDEX_W-1:0]     x_index_o,
  output logic [P_LANES-1:0]                      h_valid_o,
  output logic [P_LANES*FIR_TAPS_W-1:0]           h_index_o,
  output logic [P_N_PE*FIR_SAMPLES_W-1:0]         sample_index_o
);

  logic active_q;
  logic [FIR_BATCH_W-1:0] batch_id_q;
  logic [FIR_TAPS_W-1:0] n_taps_q;
  logic [FIR_SAMPLES_W-1:0] n_samples_q;
  logic [2:0] active_count_q;
  logic [7:0] k_group_q;
  logic [7:0] k_group_limit_q;

  integer pe, lane;
  integer sample_base;
  integer sample_idx;
  integer tap_idx;
  integer causal_groups;
  integer total_groups;
  integer group_limit;
  integer x_idx;

  always_comb begin
    start_ready_o = !active_q;
    active_o = active_q;
    k_group_o = k_group_q;
    k_group_limit_o = k_group_limit_q;
    group_done_o = active_q && (k_group_q + 8'd1 >= k_group_limit_q);

    x_valid_o = '0;
    x_index_o = '0;
    h_valid_o = '0;
    h_index_o = '0;
    sample_index_o = '0;

    sample_base = int'(batch_id_q) * P_N_PE;
    for (pe = 0; pe < P_N_PE; pe++) begin
      sample_idx = sample_base + pe;
      sample_index_o[pe*FIR_SAMPLES_W +: FIR_SAMPLES_W] =
          FIR_SAMPLES_W'(sample_idx);
      for (lane = 0; lane < P_LANES; lane++) begin
        tap_idx = int'(k_group_q) * P_LANES + lane;
        x_idx = sample_idx - tap_idx;
        if (active_q && (pe < active_count_q) &&
            (sample_idx < n_samples_q) && (tap_idx < n_taps_q) &&
            (x_idx >= 0) && (x_idx < n_samples_q)) begin
          x_valid_o[pe*P_LANES + lane] = 1'b1;
          x_index_o[(pe*P_LANES + lane)*P_INDEX_W +: P_INDEX_W] =
              P_INDEX_W'(x_idx);
        end
      end
    end
    for (lane = 0; lane < P_LANES; lane++) begin
      tap_idx = int'(k_group_q) * P_LANES + lane;
      if (active_q && (tap_idx < n_taps_q)) begin
        h_valid_o[lane] = 1'b1;
        h_index_o[lane*FIR_TAPS_W +: FIR_TAPS_W] = FIR_TAPS_W'(tap_idx);
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      active_q <= 1'b0;
      batch_id_q <= '0;
      n_taps_q <= '0;
      n_samples_q <= '0;
      active_count_q <= '0;
      k_group_q <= '0;
      k_group_limit_q <= '0;
    end else begin
      if (start_valid_i && start_ready_o) begin
        total_groups = (int'(n_taps_i) + P_LANES - 1) / P_LANES;
        // Dynamic causal bound from the Python model:
        // min(total_groups, ceil((sample_base + active_count)/LANES)).
        causal_groups =
            (int'(batch_id_i) * P_N_PE + int'(active_count_i) + P_LANES - 1) / P_LANES;
        group_limit = (causal_groups < total_groups) ? causal_groups : total_groups;
        active_q <= (group_limit > 0);
        batch_id_q <= batch_id_i;
        n_taps_q <= n_taps_i;
        n_samples_q <= n_samples_i;
        active_count_q <= (active_count_i > P_N_PE) ? 3'(P_N_PE) : active_count_i;
        k_group_q <= '0;
        k_group_limit_q <= 8'(group_limit);
      end else if (active_q && advance_i) begin
        if (k_group_q + 8'd1 >= k_group_limit_q) begin
          active_q <= 1'b0;
        end else begin
          k_group_q <= k_group_q + 8'd1;
        end
      end
    end
  end

endmodule
