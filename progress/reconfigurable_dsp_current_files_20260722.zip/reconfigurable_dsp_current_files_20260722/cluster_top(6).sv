`timescale 1ns/1ps
import cgra_rtl_pkg::*;

module cluster_top #(
  parameter int CLUSTER_ID = 0,
  parameter int XBAR_FIFO_DEPTH = 1,
  // Current headline FFT/MM/FIR/QR mappings do not issue DIR_PE_RING or
  // CORDIC-to-PE broadcast traffic.  Set to 0 for the workload-frozen area
  // build; unsupported local-forwarding instructions fault explicitly.
  parameter bit ENABLE_LOCAL_XBAR = 1'b1
) (
  input  logic clk_i,
  input  logic rst_ni,

  // Program/configuration ports.
  input  logic                  imem_wr_en_i,
  input  logic [PC_W-1:0]       imem_wr_addr_i,
  input  logic [63:0]           imem_wr_data_i,
  input  logic                  ctx_wr_en_i,
  input  logic [CTX_ADDR_W-1:0] ctx_wr_addr_i,
  input  logic [CTX_W-1:0]      ctx_wr_data_i,
  input  logic                  start_i,
  input  logic [PC_W:0]         program_words_i,

  output logic                  done_o,
  output logic                  active_o,
  output logic                  fault_o,
  output logic [7:0]            fault_code_o,

  // Global barrier interface.
  output logic                  barrier_req_o,
  output logic [15:0]           barrier_token_o,
  input  logic                  barrier_release_i,

  // Direct DMA request to the SMU/DMA engine.
  output logic                  dma_req_valid_o,
  input  logic                  dma_req_ready_i,
  output logic [CLUSTER_ID_W-1:0] dma_src_cluster_o,
  output logic [CLUSTER_ID_W-1:0] dma_dst_cluster_o,
  output logic [LOCAL_ADDR_W-1:0] dma_src_local_o,
  output logic [LOCAL_ADDR_W-1:0] dma_dst_local_o,
  output logic [7:0]            dma_len_vec_o,
  output logic [1:0]            dma_requester_pe_o,
  output logic [2:0]            dma_tag_o,
  input  logic                  dma_idle_i,

  // Shared local SRAM Port-A client used by explicit QR pivot preload.
  output logic                  qr_mem_req_valid_o,
  input  logic                  qr_mem_req_ready_i,
  output logic                  qr_mem_req_write_o,
  output logic [LOCAL_ADDR_W-1:0] qr_mem_req_addr_o,
  input  logic                  qr_mem_rsp_valid_i,
  input  logic [VECTOR_W-1:0]   qr_mem_rsp_data_i,

  // PE issue and completion interface. Arithmetic cores are intentionally
  // separate modules so Python/RTL cycle equivalence can be established per PE.
  output logic                  pe_issue_valid_o,
  input  logic                  pe_issue_ready_i,
  output logic [35:0]           pe_slots_o,
  output logic [PARAM_ID_W-1:0] pe_param_id_o,
  output logic [2:0]            pe_legacy_ctx_id_o,
  output logic [EXEC_IMM_W-1:0] pe_immediate_o,
  output logic [CTX_W-1:0]      pe_context_o,
  output logic                  pe_param_valid_o,
  output logic [VECTOR_W-1:0]   pe_param_vector_o,
  output logic [PARAM_TAG_W-1:0] pe_param_tag_o,
  // Narrow FIR-only address generator controls; the generic AGU is absent.
  output logic                  fir_agu_active_o,
  output logic [7:0]            fir_k_group_o,
  output logic [7:0]            fir_k_group_limit_o,
  output logic [N_PE*LANES-1:0] fir_x_valid_o,
  output logic [N_PE*LANES*FIR_INDEX_W-1:0] fir_x_index_o,
  output logic [LANES-1:0]      fir_h_valid_o,
  output logic [LANES*FIR_TAPS_W-1:0] fir_h_index_o,
  output logic [N_PE*FIR_SAMPLES_W-1:0] fir_sample_index_o,
  input  logic [N_PE-1:0]       pe_busy_i,
  input  logic                  ru_busy_i,

  // Explicit QR CROT interleaved inputs generated from pivot preload + landed
  // target row.  The PE core consumes these when issuing QR_CROT.
  input  logic [VECTOR_W-1:0]   qr_target_vec0_i,
  input  logic [VECTOR_W-1:0]   qr_target_vec1_i,
  output logic                  qr_pe_pairs_valid_o,
  input  logic                  qr_pe_pairs_ready_i,
  output logic [N_PE*VECTOR_W-1:0] qr_pe_pairs_o,

  // Local CORDIC interface. mode_twiddle=1 uses j/m rotation mode; 0 uses the
  // ordinary vectoring/one-pass control encoded by context/immediate.
  output logic                  cordic_req_valid_o,
  input  logic                  cordic_req_ready_i,
  output logic                  cordic_mode_twiddle_o,
  output logic [15:0]           cordic_twiddle_j_o,
  output logic [3:0]            cordic_twiddle_m_log2_o,
  output logic [PARAM_ID_W-1:0] cordic_param_id_o,
  output logic [EXEC_IMM_W-1:0] cordic_immediate_o,
  output logic [CTX_W-1:0]      cordic_context_o,
  input  logic                  cordic_rsp_valid_i,
  input  logic [VECTOR_W-1:0]   cordic_rsp_vector_i,
  input  logic signed [LANE_W-1:0] cordic_rsp_cos_i,
  input  logic signed [LANE_W-1:0] cordic_rsp_sin_i,
  input  logic                  cordic_idle_i,

  // Additional parameter producer, e.g. PARAM_LOAD from landed SRAM.
  input  logic                  ext_param_wr_valid_i,
  output logic                  ext_param_wr_ready_o,
  input  param_write_op_e       ext_param_wr_op_i,
  input  logic [PARAM_ID_W-1:0] ext_param_wr_pid_i,
  input  logic [VECTOR_W-1:0]   ext_param_wr_data_i,
  input  logic [LANE_W-1:0]     ext_param_wr_pair_c_i,
  input  logic [LANE_W-1:0]     ext_param_wr_pair_s_i,
  input  logic [PARAM_TAG_W-1:0] ext_param_wr_tag_i,

  // Local PE/CORDIC forwarding fabric.
  input  logic [N_PE-1:0]       pe_result_valid_i,
  output logic [N_PE-1:0]       pe_result_ready_o,
  input  logic [N_PE*VECTOR_W-1:0] pe_result_data_i,
  input  logic [N_PE*PARAM_ID_W-1:0] pe_result_pid_i,

  // PE results whose context downstream is MEM/WRITEBACK.  The external
  // SMU/WBQ consumes these with the original issue immediate retained per PE.
  output logic [N_PE-1:0]       pe_writeback_valid_o,
  input  logic [N_PE-1:0]       pe_writeback_ready_i,
  output logic [N_PE*VECTOR_W-1:0] pe_writeback_data_o,
  output logic [N_PE*PARAM_ID_W-1:0] pe_writeback_pid_o,
  output logic [N_PE*EXEC_IMM_W-1:0] pe_writeback_immediate_o,

  input  logic                  cordic_broadcast_valid_i,
  output logic                  cordic_broadcast_ready_o,
  input  logic [VECTOR_W-1:0]   cordic_broadcast_data_i,
  input  logic [PARAM_ID_W-1:0] cordic_broadcast_pid_i,
  output logic [N_PE-1:0]       xbar_dst_valid_o,
  input  logic [N_PE-1:0]       xbar_dst_pop_i,
  output logic [N_PE*VECTOR_W-1:0] xbar_dst_data_o,
  output logic [N_PE*PARAM_ID_W-1:0] xbar_dst_pid_o
);

  logic fe_issue_valid, fe_issue_ready;
  logic [PC_W-1:0] fe_issue_pc;
  logic [63:0] fe_issue_instr;
  logic [CTX_W-1:0] fe_issue_ctx;

  // Instruction SRAM and inferred Context RAM interfaces.
  logic                  imem_rd_en;
  logic [PC_W-1:0]       imem_rd_addr;
  logic [63:0]           imem_rd_data;
  logic                  imem_rd_valid;

  logic                  ctx_rd_en;
  logic [CTX_ADDR_W-1:0] ctx_rd_addr;
  logic [CTX_W-1:0]      ctx_rd_data;
  logic                  ctx_rd_valid;
  logic local_quiescent, all_units_idle;
  logic fe_fault;
  logic [7:0] fe_fault_code;

  isa_opcode_e issue_opcode;
  micro_kind_e issue_kind;
  sync_flag_e issue_sync;
  logic [EXEC_IMM_W-1:0] issue_imm;
  logic [PARAM_ID_W-1:0] resolved_param_id;
  logic [2:0] resolved_legacy_ctx;
  logic [3:0] issue_flags;
  logic [QR_ROT_W-1:0] issue_rotation_id;
  logic [1:0] qr_entity;

  logic [8:0] slot [N_PE];
  logic uses_pe, uses_ru, uses_param, uses_local_xbar, invalid_dir;
  logic param_ready, param_read_tag_valid, cordic_reserve_tag;
  logic qr_cordic_requires_preload;
  logic [PARAM_TAG_W-1:0] expected_tag;
  logic local_fault;
  logic [7:0] local_fault_code;
  logic unsupported_kind;

  logic fir_start, fir_advance;
  logic fir_start_ready, fir_active, fir_group_done;
  logic [7:0] fir_k_group, fir_group_limit;
  logic [N_PE*LANES-1:0] fir_x_valid;
  logic [N_PE*LANES*FIR_INDEX_W-1:0] fir_x_index;
  logic [LANES-1:0] fir_h_valid;
  logic [LANES*FIR_TAPS_W-1:0] fir_h_index;
  logic [N_PE*FIR_SAMPLES_W-1:0] fir_sample_index;

  logic qr_preload_start, qr_preload_ready, qr_preload_busy, qr_preload_valid;
  logic [QR_ROT_W-1:0] qr_preload_rotation;
  logic [VECTOR_W-1:0] qr_pivot_r0, qr_pivot_r1, qr_pivot_qt0, qr_pivot_qt1;
  logic qr_interleave_start, qr_interleave_ready;

  logic [PARAM_ID_W-1:0] prf_rd_pid;
  logic prf_rd_ready, prf_rd_valid;
  logic [VECTOR_W-1:0] prf_rd_data;
  logic [PARAM_TAG_W-1:0] prf_rd_tag;
  logic prf_wr_valid, prf_wr_ready;
  param_write_op_e prf_wr_op;
  logic [PARAM_ID_W-1:0] prf_wr_pid;
  logic [VECTOR_W-1:0] prf_wr_data;
  logic [LANE_W-1:0] prf_wr_c, prf_wr_s;
  logic [1:0] prf_wr_pair_slot;
  logic [PARAM_TAG_W-1:0] prf_wr_tag;

  logic [N_PE:0] xbar_src_valid, xbar_src_ready;
  logic [(N_PE+1)*VECTOR_W-1:0] xbar_src_data;
  logic [(N_PE+1)*PARAM_ID_W-1:0] xbar_src_pid;
  logic [(N_PE+1)*N_PE-1:0] xbar_src_mask;
  logic [N_PE-1:0] xbar_pid_match;
  logic xbar_empty;

  // One in-flight result descriptor per PE.  PE issue is blocked while any PE
  // is busy, so a single retained downstream/PID/immediate is sufficient and
  // exactly matches the Python model's one outstanding operation per PE.
  pe_dir_e pending_downstream_q [N_PE];
  logic [N_PE-1:0] pending_result_q;
  logic [N_PE*PARAM_ID_W-1:0] pending_pid_q;
  logic [N_PE*EXEC_IMM_W-1:0] pending_imm_q;
  micro_kind_e pending_kind_q [N_PE];
  logic [N_PE-1:0] result_consumed;
  logic param_result_select_valid;
  logic [$clog2(N_PE)-1:0] param_result_select;
  logic param_result_grant;

  // Tagged CORDIC reservation is queued for the ParamRF write port instead of
  // being generated combinationally from fe_issue_ready.  This breaks the
  // cordic_req_ready_i -> ParamRF -> pe_result_ready_o timing path while
  // preserving the request/response protocol.
  logic reserve_pending_q;
  logic reserve_write_grant;
  logic [PARAM_ID_W-1:0] reserve_pid_q;
  logic [PARAM_TAG_W-1:0] reserve_tag_q;

  logic [PARAM_ID_W-1:0] normal_cordic_pid_q;
  logic [PARAM_TAG_W-1:0] normal_cordic_tag_q;
  logic normal_cordic_tagged_q;
  logic normal_cordic_twiddle_q;
  logic normal_cordic_eligible;
  logic hardwired_seed_request, hardwired_seed_port_free, hardwired_seed_grant;
  logic [VECTOR_W-1:0] hardwired_seed_vector;
  logic [3:0] fft_stage_id;
  logic [9:0] fft_batch_id;
  logic [15:0] fft_seed_j;

  function automatic logic [VECTOR_W-1:0] fft_hardwired_vector(input logic [3:0] stage_id);
    logic [VECTOR_W-1:0] v;
    begin
      v = '0;
      case (stage_id)
        4'd0: begin
          for (int q = 0; q < 4; q++) begin
            v[(2*q)*LANE_W +: LANE_W] = 32'sd32767;
            v[(2*q+1)*LANE_W +: LANE_W] = -32'sd1;
          end
        end
        4'd1: begin
          v[0*LANE_W +: LANE_W] = 32'sd32767; v[1*LANE_W +: LANE_W] = -32'sd1;
          v[2*LANE_W +: LANE_W] = 32'sd1;     v[3*LANE_W +: LANE_W] = -32'sd32768;
          v[4*LANE_W +: LANE_W] = 32'sd32767; v[5*LANE_W +: LANE_W] = -32'sd1;
          v[6*LANE_W +: LANE_W] = 32'sd1;     v[7*LANE_W +: LANE_W] = -32'sd32768;
        end
        default: begin
          v[0*LANE_W +: LANE_W] = 32'sd32767;  v[1*LANE_W +: LANE_W] = -32'sd1;
          v[2*LANE_W +: LANE_W] = 32'sd23170;  v[3*LANE_W +: LANE_W] = -32'sd23169;
          v[4*LANE_W +: LANE_W] = 32'sd1;      v[5*LANE_W +: LANE_W] = -32'sd32768;
          v[6*LANE_W +: LANE_W] = -32'sd23171; v[7*LANE_W +: LANE_W] = -32'sd23170;
        end
      endcase
      fft_hardwired_vector = v;
    end
  endfunction

  integer p;
  always_comb begin
    issue_opcode = isa_opcode_e'(fe_issue_instr[63:58]);
    issue_kind = micro_kind_e'(fe_issue_ctx[CTX_KIND_LSB +: 5]);
    issue_flags = fe_issue_ctx[CTX_FLAGS_LSB +: 4];
    issue_imm = fe_issue_instr[EXEC_IMM_W-1:0];
    issue_sync = (issue_opcode == ISA_EXEC_DMA_DIRECT) ?
                 sync_flag_e'(fe_issue_instr[6:5]) : sync_flag_e'(fe_issue_instr[40:39]);
    issue_rotation_id = issue_imm[7:0];
    qr_entity = issue_imm[21:20];

    for (p = 0; p < N_PE; p++) begin
      slot[p] = ctx_pe_slot(fe_issue_ctx, p);
      pe_slots_o[p*9 +: 9] = slot[p];
    end

    // Dynamic ParamRF/context fields follow pack_descriptor_immediate().
    resolved_param_id = fe_issue_ctx[CTX_PARAM_LSB +: PARAM_ID_W];
    resolved_legacy_ctx = fe_issue_ctx[CTX_LEGACY_CTX_LSB +: 3];
    case (issue_kind)
      M_FIR_X_WINDOW, M_FIR_H_VECTOR, M_FIR_MAC, M_FIR_REDUCE, M_FIR_PACK,
      M_MM_A_LOAD, M_MM_A_LATCH, M_MM_B_LOAD, M_MM_MAC, M_MM_REDUCE, M_MM_PACK: begin
        resolved_param_id = issue_imm[21:18];
        resolved_legacy_ctx = issue_imm[24:22];
      end
      M_QR_LOAD, M_QR_CORDIC, M_QR_CROT, M_QR_PACK, M_QR_WRITEBACK,
      M_QR_TOKEN_ACQUIRE, M_QR_TOKEN_ROTATE, M_QR_TOKEN_FLUSH: begin
        resolved_param_id = issue_imm[31:28];
        resolved_legacy_ctx = issue_imm[34:32];
      end
      M_FFT_OPT_CACHE_SEED, M_FFT_OPT_CACHE_STEP, M_FFT_OPT_FUSED_BFLY: begin
        // PID = {stage[0], batch[2:0]}: two 8-entry ping-pong banks.
        resolved_param_id = {issue_imm[11], issue_imm[17:15]};
      end
      default: begin end
    endcase

    uses_pe = 1'b0;
    uses_ru = 1'b0;
    uses_param = 1'b0;
    uses_local_xbar = 1'b0;
    invalid_dir = 1'b0;
    for (p = 0; p < N_PE; p++) begin
      if (pe_slot_active(slot[p])) begin
        uses_pe = 1'b1;
        if (pe_op_e'(slot[p][8:6]) == PE_RU_PACK) uses_ru = 1'b1;
        if ((pe_dir_e'(slot[p][5:3]) == DIR_PARAM_RF) ||
            (pe_op_e'(slot[p][8:6]) == PE_CMUL) ||
            (pe_op_e'(slot[p][8:6]) == PE_CROT)) uses_param = 1'b1;
        if ((pe_dir_e'(slot[p][5:3]) == DIR_PE_RING) ||
            (pe_dir_e'(slot[p][2:0]) == DIR_PE_RING)) uses_local_xbar = 1'b1;
        if ((pe_dir_e'(slot[p][5:3]) == DIR_RESERVED) ||
            (pe_dir_e'(slot[p][2:0]) == DIR_RESERVED)) invalid_dir = 1'b1;
      end
    end

    if (fe_issue_ctx[CTX_CORDIC_EN_BIT] &&
        ((fe_issue_ctx[CTX_CORDIC_SRC_LSB +: 2] == 2'd2) ||
         (fe_issue_ctx[CTX_CORDIC_DST_LSB +: 2] == 2'd1) ||
         (fe_issue_ctx[CTX_CORDIC_DST_LSB +: 2] == 2'd2)))
      uses_local_xbar = 1'b1;

    // QR_CORDIC reserves/writes a tagged ParamRF entry; QR_CROT consumes it.
    // Token-controller kinds require a separate token-directory RTL block and
    // are rejected by this cluster shell rather than being approximated.
    param_read_tag_valid = (issue_kind == M_QR_CROT);
    cordic_reserve_tag = (issue_kind == M_QR_CORDIC);
    qr_cordic_requires_preload = (issue_kind == M_QR_CORDIC);
    expected_tag = issue_rotation_id;
    prf_rd_pid = resolved_param_id;
    param_ready = !uses_param || prf_rd_ready;
    unsupported_kind = (issue_kind == M_RESERVED_23) ||
                       (issue_kind == M_FFT_TWIDDLE_FILL) ||
                       (issue_kind == M_QR_TOKEN_ACQUIRE) ||
                       (issue_kind == M_QR_TOKEN_ROTATE) ||
                       (issue_kind == M_QR_TOKEN_FLUSH);
    local_fault = invalid_dir || unsupported_kind ||
                  (!ENABLE_LOCAL_XBAR && uses_local_xbar);
    local_fault_code = invalid_dir ? 8'h20 :
                       (issue_kind == M_FFT_TWIDDLE_FILL) ? 8'h22 :
                       unsupported_kind ? 8'h21 :
                       (!ENABLE_LOCAL_XBAR && uses_local_xbar) ? 8'h23 : 8'h00;

    fir_start = fe_issue_valid && !local_fault && (issue_kind == M_FIR_AGU_START);
    fir_advance = pe_issue_valid_o && pe_issue_ready_i && (issue_kind == M_FIR_MAC);
    qr_preload_start = fe_issue_valid && !local_fault && (issue_kind == M_QR_LOAD) &&
                       ((issue_flags & MICRO_FLAG_QR_PIVOT_PRELOAD) != 0);
    qr_interleave_start = fe_issue_valid && !local_fault && (issue_kind == M_QR_CROT) &&
                          qr_preload_valid &&
                          (qr_preload_rotation == issue_rotation_id) &&
                          !qr_pe_pairs_valid_o;
    fft_stage_id = issue_imm[14:11];
    fft_batch_id = issue_imm[24:15];
    if (fft_stage_id == 0)
      fft_seed_j = 16'd0;
    else
      fft_seed_j = ({6'd0, fft_batch_id} << 2) & ((16'd1 << fft_stage_id) - 16'd1);
    hardwired_seed_request = fe_issue_valid && !local_fault &&
                             (issue_kind == M_FFT_OPT_CACHE_SEED) && issue_imm[2];
    hardwired_seed_vector = fft_hardwired_vector(fft_stage_id);
    hardwired_seed_port_free = !cordic_rsp_valid_i && !reserve_pending_q &&
                               !(|pending_result_q) && !ext_param_wr_valid_i;

    pe_issue_valid_o = fe_issue_valid && uses_pe && !local_fault && param_ready &&
                       (!(issue_kind == M_QR_CROT) || qr_pe_pairs_valid_o);
    pe_param_id_o = resolved_param_id;
    pe_legacy_ctx_id_o = resolved_legacy_ctx;
    pe_immediate_o = issue_imm;
    pe_context_o = fe_issue_ctx;
    pe_param_valid_o = prf_rd_ready;
    pe_param_vector_o = prf_rd_data;
    pe_param_tag_o = prf_rd_tag;
    fir_agu_active_o = fir_active;
    fir_k_group_o = fir_k_group;
    fir_k_group_limit_o = fir_group_limit;
    fir_x_valid_o = fir_x_valid;
    fir_x_index_o = fir_x_index;
    fir_h_valid_o = fir_h_valid;
    fir_h_index_o = fir_h_index;
    fir_sample_index_o = fir_sample_index;

    dma_req_valid_o = fe_issue_valid && !local_fault && (issue_opcode == ISA_EXEC_DMA_DIRECT);
    dma_src_local_o = fe_issue_instr[52:38];
    dma_dst_local_o = fe_issue_instr[37:23];
    dma_src_cluster_o = fe_issue_instr[22:19];
    dma_dst_cluster_o = fe_issue_instr[18:15];
    dma_len_vec_o = fe_issue_instr[14:7];
    dma_requester_pe_o = fe_issue_instr[4:3];
    dma_tag_o = fe_issue_instr[2:0];

    normal_cordic_eligible = fe_issue_valid && !local_fault &&
      ((issue_opcode == ISA_EXEC_CORDIC) || fe_issue_ctx[CTX_CORDIC_EN_BIT]) &&
      !hardwired_seed_request &&
      (!qr_cordic_requires_preload ||
       (qr_preload_valid && (qr_preload_rotation == issue_rotation_id))) &&
      (!cordic_reserve_tag || !reserve_pending_q);

    // Frontend resource acceptance for the current in-order head.
    fe_issue_ready = 1'b0;
    if (local_fault) begin
      fe_issue_ready = 1'b0;
    end else if (issue_opcode == ISA_EXEC_DMA_DIRECT) begin
      fe_issue_ready = dma_req_ready_i;
    end else if (issue_kind == M_FIR_AGU_START) begin
      fe_issue_ready = fir_start_ready;
    end else if ((issue_kind == M_QR_LOAD) &&
                 ((issue_flags & MICRO_FLAG_QR_PIVOT_PRELOAD) != 0)) begin
      fe_issue_ready = qr_preload_ready;
    end else if (hardwired_seed_request) begin
      fe_issue_ready = hardwired_seed_port_free && hardwired_seed_grant && prf_wr_ready;
    end else if (issue_opcode == ISA_EXEC_CORDIC ||
                 fe_issue_ctx[CTX_CORDIC_EN_BIT]) begin
      fe_issue_ready = normal_cordic_eligible && cordic_req_ready_i && cordic_idle_i;
    end else if (uses_pe) begin
      fe_issue_ready = pe_issue_ready_i && !(|pe_busy_i) && !(|pending_result_q) && !ru_busy_i &&
                       param_ready &&
                       (!(issue_kind == M_QR_CROT) || qr_pe_pairs_valid_o);
    end else begin
      fe_issue_ready = 1'b1;
    end

    cordic_req_valid_o = normal_cordic_eligible;
    cordic_mode_twiddle_o = (issue_kind == M_FFT_OPT_CACHE_SEED);
    cordic_twiddle_j_o = fft_seed_j;
    cordic_twiddle_m_log2_o = fft_stage_id + 4'd1;
    cordic_param_id_o = resolved_param_id;
    cordic_immediate_o = issue_imm;
    cordic_context_o = fe_issue_ctx;

    // Route each completed PE result according to the downstream encoded in
    // the context that launched it.  Python semantics:
    //   MEM(0)      -> SMU/WBQ writeback
    //   PE_RING(2)  -> local PE forwarding fabric
    //   PARAM_RF(3) -> shared ParamRF update
    //   PE_LOCAL/ACC/OPERAND_RF remain inside the PE/cluster and are consumed.
    xbar_src_valid = '0;
    xbar_src_data = '0;
    xbar_src_pid = '0;
    xbar_src_mask = '0;
    pe_writeback_valid_o = '0;
    pe_writeback_data_o = '0;
    pe_writeback_pid_o = '0;
    pe_writeback_immediate_o = '0;
    result_consumed = '0;
    param_result_select_valid = 1'b0;
    param_result_select = '0;

    // Single ParamRF write port: oldest/lowest PE id wins and other writers
    // remain back-pressured until a following cycle.
    for (p = 0; p < N_PE; p++) begin
      if (!param_result_select_valid && pending_result_q[p] &&
          pe_result_valid_i[p] && (pending_downstream_q[p] == DIR_PARAM_RF)) begin
        param_result_select_valid = 1'b1;
        param_result_select = p[$clog2(N_PE)-1:0];
      end
    end

    for (p = 0; p < N_PE; p++) begin
      pe_result_ready_o[p] = 1'b0;
      case (pending_downstream_q[p])
        DIR_MEM: begin
          pe_writeback_valid_o[p] = pending_result_q[p] && pe_result_valid_i[p];
          pe_writeback_data_o[p*VECTOR_W +: VECTOR_W] = pe_result_data_i[p*VECTOR_W +: VECTOR_W];
          pe_writeback_pid_o[p*PARAM_ID_W +: PARAM_ID_W] = pending_pid_q[p*PARAM_ID_W +: PARAM_ID_W];
          pe_writeback_immediate_o[p*EXEC_IMM_W +: EXEC_IMM_W] = pending_imm_q[p*EXEC_IMM_W +: EXEC_IMM_W];
          pe_result_ready_o[p] = pe_writeback_ready_i[p];
        end
        DIR_PE_RING: begin
          xbar_src_valid[p] = pending_result_q[p] && pe_result_valid_i[p];
          pe_result_ready_o[p] = xbar_src_ready[p];
          xbar_src_data[p*VECTOR_W +: VECTOR_W] = pe_result_data_i[p*VECTOR_W +: VECTOR_W];
          xbar_src_pid[p*PARAM_ID_W +: PARAM_ID_W] = pending_pid_q[p*PARAM_ID_W +: PARAM_ID_W];
          case (p)
            0: xbar_src_mask[p*N_PE +: N_PE] = 4'b0010;
            1: xbar_src_mask[p*N_PE +: N_PE] = 4'b0100;
            2: xbar_src_mask[p*N_PE +: N_PE] = 4'b1000;
            default: xbar_src_mask[p*N_PE +: N_PE] = 4'b0001;
          endcase
        end
        DIR_PARAM_RF: begin
          // PRF_WRITE_VECTOR is unconditionally accepted by param_rf.  Ready
          // therefore depends on the actual arbitration grant, not on the
          // generic wr_ready_o path (which contains tagged-write checking).
          pe_result_ready_o[p] = param_result_grant &&
                                 (param_result_select == p[$clog2(N_PE)-1:0]);
        end
        default: begin
          // PE_LOCAL/SCALE/ACC/OPERAND_RF are retained local state in the
          // Python model; no external transport is required.
          pe_result_ready_o[p] = pending_result_q[p];
        end
      endcase
      result_consumed[p] = pending_result_q[p] && pe_result_valid_i[p] && pe_result_ready_o[p];
    end

    xbar_src_valid[N_PE] = cordic_broadcast_valid_i;
    cordic_broadcast_ready_o = xbar_src_ready[N_PE];
    xbar_src_data[N_PE*VECTOR_W +: VECTOR_W] = cordic_broadcast_data_i;
    xbar_src_pid[N_PE*PARAM_ID_W +: PARAM_ID_W] = cordic_broadcast_pid_i;
    xbar_src_mask[N_PE*N_PE +: N_PE] = {N_PE{1'b1}};

    local_quiescent = dma_idle_i && cordic_idle_i && !(|pe_busy_i) && !ru_busy_i &&
                      !qr_preload_busy && !qr_pe_pairs_valid_o &&
                      !fir_active && !(|pending_result_q) && xbar_empty;
    all_units_idle = local_quiescent;

    fault_o = fe_fault;
    fault_code_o = fe_fault_code;
  end

  // 2048 x 64 instruction memory: compiled TSMC SRAM macro wrapper.
  instruction_ram u_instruction_ram (
    .clk_i         (clk_i),
    .rst_ni       (rst_ni),
    .wr_en       (imem_wr_en_i),
    .wr_addr     (imem_wr_addr_i),
    .wr_data     (imem_wr_data_i),
    .rd_en       (imem_rd_en),
    .rd_addr     (imem_rd_addr),
    .rd_data     (imem_rd_data),
    .rd_valid    (imem_rd_valid)
  );

  // Context RAM is intentionally still synthesizable RTL/inferred memory.
  // It can be replaced by a compiled macro later without changing the
  // autonomous_frontend interface.
  context_ram u_context_ram (
    .clk_i      (clk_i),
    .rst_ni    (rst_ni),
    .wr_en    (ctx_wr_en_i),
    .wr_addr  (ctx_wr_addr_i),
    .wr_data  (ctx_wr_data_i),
    .rd_en    (ctx_rd_en),
    .rd_addr  (ctx_rd_addr),
    .rd_data  (ctx_rd_data),
    .rd_valid (ctx_rd_valid)
  );

  autonomous_frontend u_frontend (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .imem_rd_en_o(imem_rd_en),
    .imem_rd_addr_o(imem_rd_addr),
    .imem_rd_data_i(imem_rd_data),
    .imem_rd_valid_i(imem_rd_valid),
    .ctx_rd_en_o(ctx_rd_en),
    .ctx_rd_addr_o(ctx_rd_addr),
    .ctx_rd_data_i(ctx_rd_data),
    .ctx_rd_valid_i(ctx_rd_valid),
    .start_i(start_i), .program_words_i(program_words_i),
    .active_o(active_o), .done_o(done_o), .fault_o(fe_fault), .fault_code_o(fe_fault_code),
    .issue_valid_o(fe_issue_valid), .issue_ready_i(fe_issue_ready),
    .issue_pc_o(fe_issue_pc), .issue_instr_o(fe_issue_instr), .issue_ctx_o(fe_issue_ctx),
    .dma_idle_i(dma_idle_i), .local_quiescent_i(local_quiescent), .all_units_idle_i(all_units_idle),
    .resource_fault_i(local_fault), .resource_fault_code_i(local_fault_code),
    .barrier_req_o(barrier_req_o), .barrier_token_o(barrier_token_o), .barrier_release_i(barrier_release_i)
  );

  fir_agu u_fir_agu (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .start_valid_i(fir_start), .start_ready_o(fir_start_ready),
    .batch_id_i(issue_imm[9:0]), .n_taps_i(issue_imm[21:13]),
    .n_samples_i(issue_imm[31:22]), .active_count_i(issue_imm[12:10]),
    .advance_i(fir_advance), .active_o(fir_active), .group_done_o(fir_group_done),
    .k_group_o(fir_k_group), .k_group_limit_o(fir_group_limit),
    .x_valid_o(fir_x_valid), .x_index_o(fir_x_index), .h_valid_o(fir_h_valid),
    .h_index_o(fir_h_index), .sample_index_o(fir_sample_index)
  );

  qr_pivot_preload u_qr_preload (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .start_valid_i(qr_preload_start), .start_ready_o(qr_preload_ready),
    .rotation_id_i(issue_rotation_id), .pivot_row_i(issue_imm[11:8]),
    .mem_req_valid_o(qr_mem_req_valid_o), .mem_req_ready_i(qr_mem_req_ready_i),
    .mem_req_write_o(qr_mem_req_write_o), .mem_req_addr_o(qr_mem_req_addr_o),
    .mem_rsp_valid_i(qr_mem_rsp_valid_i), .mem_rsp_data_i(qr_mem_rsp_data_i),
    .preload_busy_o(qr_preload_busy), .preload_valid_o(qr_preload_valid),
    .preload_rotation_id_o(qr_preload_rotation),
    .pivot_r_vec0_o(qr_pivot_r0), .pivot_r_vec1_o(qr_pivot_r1),
    .pivot_qt_vec0_o(qr_pivot_qt0), .pivot_qt_vec1_o(qr_pivot_qt1),
    .interleave_valid_i(qr_interleave_start), .interleave_ready_o(qr_interleave_ready),
    .interleave_entity_qt_i(qr_entity == 2'd2),
    .target_vec0_i(qr_target_vec0_i), .target_vec1_i(qr_target_vec1_i),
    .pe_pairs_valid_o(qr_pe_pairs_valid_o), .pe_pairs_ready_i(qr_pe_pairs_ready_i),
    .pe_pairs_o(qr_pe_pairs_o)
  );

  param_rf u_param_rf (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .rd_pid_i(prf_rd_pid), .rd_expected_tag_valid_i(param_read_tag_valid),
    .rd_expected_tag_i(expected_tag), .rd_ready_o(prf_rd_ready),
    .rd_data_o(prf_rd_data), .rd_tag_o(prf_rd_tag), .rd_valid_o(prf_rd_valid),
    .wr_valid_i(prf_wr_valid), .wr_ready_o(prf_wr_ready), .wr_op_i(prf_wr_op),
    .wr_pid_i(prf_wr_pid), .wr_data_i(prf_wr_data),
    .wr_pair_c_i(prf_wr_c), .wr_pair_s_i(prf_wr_s), .wr_pair_slot_i(prf_wr_pair_slot),
    .wr_tag_i(prf_wr_tag), .invalidate_clear_tag_i(1'b1)
  );

  generate
    if (ENABLE_LOCAL_XBAR) begin : g_local_xbar
      pe_local_interconnect #(.P_FIFO_DEPTH(XBAR_FIFO_DEPTH)) u_xbar (
        .clk_i(clk_i), .rst_ni(rst_ni),
        .src_valid_i(xbar_src_valid), .src_ready_o(xbar_src_ready),
        .src_data_i(xbar_src_data), .src_pid_i(xbar_src_pid),
        .src_dst_mask_i(xbar_src_mask),
        .dst_valid_o(xbar_dst_valid_o), .dst_pop_i(xbar_dst_pop_i),
        .dst_expected_pid_i({N_PE{resolved_param_id}}),
        .dst_pid_match_o(xbar_pid_match),
        .dst_data_o(xbar_dst_data_o), .dst_pid_o(xbar_dst_pid_o),
        .empty_o(xbar_empty)
      );
    end else begin : g_no_local_xbar
      always_comb begin
        xbar_src_ready = '0;
        xbar_pid_match = '0;
        xbar_dst_valid_o = '0;
        xbar_dst_data_o = '0;
        xbar_dst_pid_o = '0;
        xbar_empty = 1'b1;
      end
    end
  endgenerate

  // Parameter write arbitration:
  //   completed CORDIC > queued tag reservation > PE result > hardwired seed > external.
  // The reservation request is registered at CORDIC acceptance, so the PRF
  // write mux no longer depends combinationally on cordic_req_ready_i.
  always_comb begin
    prf_wr_valid = 1'b0;
    prf_wr_op = PRF_WRITE_NONE;
    prf_wr_pid = '0;
    prf_wr_data = '0;
    prf_wr_c = '0;
    prf_wr_s = '0;
    prf_wr_tag = '0;
    prf_wr_pair_slot = '0;
    ext_param_wr_ready_o = 1'b0;
    reserve_write_grant = 1'b0;
    param_result_grant = 1'b0;
    hardwired_seed_grant = 1'b0;

    if (cordic_rsp_valid_i) begin
      prf_wr_valid = 1'b1;
      prf_wr_pid = normal_cordic_pid_q;
      prf_wr_tag = normal_cordic_tag_q;
      if (normal_cordic_tagged_q && !normal_cordic_twiddle_q) begin
        prf_wr_op = PRF_WRITE_TAGGED_PAIR;
        prf_wr_c = cordic_rsp_cos_i;
        prf_wr_s = cordic_rsp_sin_i;
      end else begin
        prf_wr_op = PRF_WRITE_VECTOR;
        prf_wr_data = cordic_rsp_vector_i;
      end
    end else if (reserve_pending_q) begin
      prf_wr_valid = 1'b1;
      prf_wr_op = PRF_RESERVE_TAG;
      prf_wr_pid = reserve_pid_q;
      prf_wr_tag = reserve_tag_q;
      reserve_write_grant = 1'b1;
    end else if (param_result_select_valid) begin
      prf_wr_valid = 1'b1;
      prf_wr_pid = pending_pid_q[param_result_select*PARAM_ID_W +: PARAM_ID_W];
      if (pending_kind_q[param_result_select] == M_FFT_OPT_CACHE_STEP) begin
        prf_wr_op = PRF_WRITE_PAIR_SLOT;
        prf_wr_pair_slot = param_result_select[1:0];
        prf_wr_c = pe_result_data_i[param_result_select*VECTOR_W +: LANE_W];
        prf_wr_s = pe_result_data_i[param_result_select*VECTOR_W + LANE_W +: LANE_W];
      end else begin
        prf_wr_op = PRF_WRITE_VECTOR;
        prf_wr_data = pe_result_data_i[param_result_select*VECTOR_W +: VECTOR_W];
      end
      param_result_grant = 1'b1;
    end else if (hardwired_seed_request && hardwired_seed_port_free) begin
      prf_wr_valid = 1'b1;
      prf_wr_op = PRF_WRITE_VECTOR;
      prf_wr_pid = resolved_param_id;
      prf_wr_data = hardwired_seed_vector;
      hardwired_seed_grant = 1'b1;
    end else if (ext_param_wr_valid_i) begin
      prf_wr_valid = 1'b1;
      prf_wr_op = ext_param_wr_op_i;
      prf_wr_pid = ext_param_wr_pid_i;
      prf_wr_data = ext_param_wr_data_i;
      prf_wr_c = ext_param_wr_pair_c_i;
      prf_wr_s = ext_param_wr_pair_s_i;
      prf_wr_tag = ext_param_wr_tag_i;
      ext_param_wr_ready_o = prf_wr_ready;
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      normal_cordic_pid_q <= '0;
      normal_cordic_tag_q <= '0;
      normal_cordic_tagged_q <= 1'b0;
      normal_cordic_twiddle_q <= 1'b0;
      pending_result_q <= '0;
      pending_pid_q <= '0;
      pending_imm_q <= '0;
      reserve_pending_q <= 1'b0;
      reserve_pid_q <= '0;
      reserve_tag_q <= '0;
      for (int r = 0; r < N_PE; r++) begin
        pending_downstream_q[r] <= DIR_PE_LOCAL;
        pending_kind_q[r] <= M_NONE;
      end
    end else begin
      if (reserve_write_grant)
        reserve_pending_q <= 1'b0;

      if (cordic_req_valid_o && cordic_req_ready_i && cordic_reserve_tag) begin
        reserve_pending_q <= 1'b1;
        reserve_pid_q <= resolved_param_id;
        reserve_tag_q <= expected_tag;
      end

      if (pe_issue_valid_o && pe_issue_ready_i) begin
        for (int r = 0; r < N_PE; r++) begin
          if (pe_slot_active(slot[r])) begin
            pending_result_q[r] <= 1'b1;
            pending_downstream_q[r] <= pe_dir_e'(slot[r][2:0]);
            pending_pid_q[r*PARAM_ID_W +: PARAM_ID_W] <= resolved_param_id;
            pending_imm_q[r*EXEC_IMM_W +: EXEC_IMM_W] <= issue_imm;
            pending_kind_q[r] <= issue_kind;
          end
        end
      end

      for (int r = 0; r < N_PE; r++) begin
        if (result_consumed[r])
          pending_result_q[r] <= 1'b0;
      end

      if (cordic_req_valid_o && cordic_req_ready_i) begin
        normal_cordic_pid_q <= resolved_param_id;
        normal_cordic_tag_q <= expected_tag;
        normal_cordic_tagged_q <= cordic_reserve_tag;
        normal_cordic_twiddle_q <= (issue_kind == M_FFT_OPT_CACHE_SEED);
      end
    end
  end

endmodule
