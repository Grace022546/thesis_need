// =============================================================================
// context_ram.sv
// Per-cluster autonomous Context RAM: 32 x 94-bit payload (96-bit serialized
// alignment for programming).
//
// SOURCE OF TRUTH: cgra_v4_no_tsu_paramrf_pingpong_full(1).py, class ContextRAM /
// ContextRAMEntry. The 94 payload bits carry the static datapath controls
// (4x PE slots, ParamRF/CORDIC controls, micro-op kind, dependency class,
// reserved address-generator bits, arithmetic-policy bits); dynamic workload
// indices are NOT stored here -- they travel in the EXEC instruction's
// 39-bit immediate field instead.
//
// Measured worst case across the 19-workload regression: QR16 uses 30/32
// entries.
//
// This module only defines the memory array and its port timing. The payload is opaque to this RAM wrapper; cgra_rtl_pkg defines the bit
// positions consumed by the frontend and cluster controller.
// =============================================================================

import cgra_rtl_pkg::*;

module context_ram (
  input  logic                            clk_i,
  input  logic                            rst_ni,

  // Programming (write) port -- one-time resident image load
  input  logic                            wr_en,
  input  logic [CTX_ADDR_W-1:0]          wr_addr,
  input  logic [CTX_W-1:0]               wr_data,

  // Read port -- context_idx-indexed, 1 cycle latency
  input  logic                            rd_en,
  input  logic [CTX_ADDR_W-1:0]          rd_addr,
  output logic [CTX_W-1:0]               rd_data,
  output logic                            rd_valid
);

  // rd_addr/wr_addr are CTX_ADDR_W wide (5b), which by construction
  // spans exactly [0, CTX_DEPTH-1] (32 entries) -- no OOB case exists
  // at this port width, unlike instruction_ram's PC which is checked against
  // a to-be-confirmed image size at load time.

  logic [CTX_W-1:0] mem [0:CTX_DEPTH-1];

  always_ff @(posedge clk_i) begin
    if (wr_en) begin
      mem[wr_addr] <= wr_data;
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rd_valid <= 1'b0;
      rd_data  <= '0;
    end else begin
      rd_valid <= rd_en;
      if (rd_en) begin
        rd_data <= mem[rd_addr];
      end
    end
  end

endmodule : context_ram
