`timescale 1ns/1ps

// =============================================================================
// single_cluster_integration_top.sv
//
// One physical cluster synthesis/integration boundary:
//   * 1 x cluster_top control/issue hierarchy
//   * 4 x pe Q1.15 arithmetic cores
//   * 1 x registered iterative CORDIC (QR two-pass / FFT seed generation)
//   * 1 x V4.1 FFT stream controller + two-CMUL TEU + two-entry result FIFO
//   * 1 x sv_smu_sched_top local SRAM / WBQ / NoC scheduler
//
// Important contract boundaries:
//   * The same registered CORDIC performs 36-cycle QR two-pass and 18-cycle
//     FFT twiddle rotation-only operations. No dedicated twiddle block or separate parameter memory exists.
//   * Workload-specific memory address generation is not encoded uniformly in
//     pe_immediate_o. PE writeback addresses are consequently explicit wrapper
//     inputs (pe_writeback_addr_i), rather than guessed from immediate bits.
//   * SMU PE request tag 4'hF on port 0 is reserved for QR pivot preload.
// =============================================================================

module single_cluster_integration_top #(
  parameter int CLUSTER_ID = 0,
  parameter int XBAR_FIFO_DEPTH = 1,
  // Workload-frozen production default.  Override to 1 only for legacy
  // DIR_PE_RING/CORDIC broadcast contexts.
  parameter bit ENABLE_LOCAL_XBAR = 1'b0
) (
  input  logic clk_i,
  input  logic rst_ni,

  // --------------------------------------------------------------------------
  // Instruction/context programming and kernel control
  // --------------------------------------------------------------------------
  input  logic                         imem_wr_en_i,
  input  logic [cgra_rtl_pkg::PC_W-1:0] imem_wr_addr_i,
  input  logic [63:0]                  imem_wr_data_i,
  input  logic                         ctx_wr_en_i,
  input  logic [cgra_rtl_pkg::CTX_ADDR_W-1:0] ctx_wr_addr_i,
  input  logic [cgra_rtl_pkg::CTX_W-1:0] ctx_wr_data_i,
  input  logic                         start_i,
  input  logic [cgra_rtl_pkg::PC_W:0] program_words_i,

  output logic                         done_o,
  output logic                         active_o,
  output logic                         fault_o,
  output logic [7:0]                   fault_code_o,

  output logic                         barrier_req_o,
  output logic [15:0]                  barrier_token_o,
  input  logic                         barrier_release_i,

  // --------------------------------------------------------------------------
  // Direct DMA command boundary. A complete multi-cluster DMA controller / NoC
  // remains outside this single-cluster wrapper.
  // --------------------------------------------------------------------------
  output logic                         dma_req_valid_o,
  input  logic                         dma_req_ready_i,
  output logic [cgra_rtl_pkg::CLUSTER_ID_W-1:0] dma_src_cluster_o,
  output logic [cgra_rtl_pkg::CLUSTER_ID_W-1:0] dma_dst_cluster_o,
  output logic [cgra_rtl_pkg::LOCAL_ADDR_W-1:0] dma_src_local_o,
  output logic [cgra_rtl_pkg::LOCAL_ADDR_W-1:0] dma_dst_local_o,
  output logic [7:0]                   dma_len_vec_o,
  output logic [1:0]                   dma_requester_pe_o,
  output logic [2:0]                   dma_tag_o,
  input  logic                         dma_idle_i,

  // --------------------------------------------------------------------------
  // V4.1 block-distributed FFT stream ingress.
  // --------------------------------------------------------------------------
  input  logic                         fft_stream_enable_i,
  input  logic                         fft_task_valid_i,
  output logic                         fft_task_ready_o,
  output logic                         fft_task_slot_o,
  input  logic signed [15:0]           fft_task_seed_re_i,
  input  logic signed [15:0]           fft_task_seed_im_i,
  input  logic signed [15:0]           fft_task_step_re_i,
  input  logic signed [15:0]           fft_task_step_im_i,
  input  logic [cgra_rtl_pkg::LOCAL_ADDR_W-1:0] fft_task_dst0_addr_i,
  input  logic [cgra_rtl_pkg::LOCAL_ADDR_W-1:0] fft_task_dst1_addr_i,
  input  logic                         fft_input_fill_valid_i,
  output logic                         fft_input_fill_ready_o,
  input  logic                         fft_input_fill_slot_i,
  input  logic                         fft_input_fill_vector_i,
  input  logic [cgra_rtl_pkg::VECTOR_W-1:0] fft_input_fill_data_i,
  input  logic                         fft_stage_close_i,
  output logic                         fft_stage_done_o,
  output logic                         fft_stream_busy_o,

  // --------------------------------------------------------------------------
  // Workload operand boundary for sources not yet backed by a dedicated RTL RF.
  // Each 256-bit vector contains eight signed 32-bit containers; PE consumes
  // the low signed 16 bits of each lane as Q1.15.
  // --------------------------------------------------------------------------
  input  logic [cgra_rtl_pkg::N_PE*cgra_rtl_pkg::VECTOR_W-1:0] pe_operand_i,
  input  logic [cgra_rtl_pkg::N_PE*cgra_rtl_pkg::VECTOR_W-1:0] pe_twiddle_i,
  // PE CMUL second operand V.  Two signed Q1.15 components per PE replace
  // the former full 256-bit auxiliary vector and model-only latency override.
  input  logic [cgra_rtl_pkg::N_PE*2*16-1:0] pe_cmul_v_i,

  // Explicit local SRAM destination for each PE MEM/WRITEBACK result.
  input  logic [cgra_rtl_pkg::N_PE*cgra_rtl_pkg::LOCAL_ADDR_W-1:0] pe_writeback_addr_i,

  // QR target rows are no longer external operands.  They are mirrored from
  // every accepted architectural write to the landing addresses: WBQ/Port-A
  // commits for DMA/direct transitions and accepted Port-B writes for initial
  // configuration or explicit local writes.

  // Optional external ParamRF producer.
  input  logic                         ext_param_wr_valid_i,
  output logic                         ext_param_wr_ready_o,
  input  cgra_rtl_pkg::param_write_op_e ext_param_wr_op_i,
  input  logic [cgra_rtl_pkg::PARAM_ID_W-1:0] ext_param_wr_pid_i,
  input  logic [cgra_rtl_pkg::VECTOR_W-1:0] ext_param_wr_data_i,
  input  logic [cgra_rtl_pkg::LANE_W-1:0] ext_param_wr_pair_c_i,
  input  logic [cgra_rtl_pkg::LANE_W-1:0] ext_param_wr_pair_s_i,
  input  logic [cgra_rtl_pkg::PARAM_TAG_W-1:0] ext_param_wr_tag_i,

  // --------------------------------------------------------------------------
  // External local-memory requests sharing the four SMU PE ports.
  // Priority per port: FFT result drain (port0) > cluster PE writeback > internal MM B prefetch > external.
  // Read tag 4'hE is reserved for internal MM B-stationary prefetch.
  // QR pivot preload uses the independent SMU Port-A service interface.
  // --------------------------------------------------------------------------
  input  logic [cgra_rtl_pkg::N_PE-1:0] ext_pe_mem_req_valid_i,
  output logic [cgra_rtl_pkg::N_PE-1:0] ext_pe_mem_req_ready_o,
  input  logic [cgra_rtl_pkg::N_PE-1:0][1:0] ext_pe_mem_req_type_i,
  input  logic [cgra_rtl_pkg::N_PE-1:0] ext_pe_mem_req_is_vec_i,
  input  logic [cgra_rtl_pkg::N_PE-1:0][cgra_rtl_pkg::LOCAL_ADDR_W-1:0] ext_pe_mem_req_addr_i,
  input  logic [cgra_rtl_pkg::N_PE-1:0][cgra_rtl_pkg::VECTOR_W-1:0] ext_pe_mem_req_data_i,
  input  logic [cgra_rtl_pkg::N_PE-1:0][3:0] ext_pe_mem_req_wstrb_i,
  input  logic [cgra_rtl_pkg::N_PE-1:0][3:0] ext_pe_mem_req_tag_i,

  output logic [cgra_rtl_pkg::N_PE-1:0] smu_pe_rsp_valid_o,
  output logic [cgra_rtl_pkg::N_PE-1:0] smu_pe_rsp_kind_o,
  output logic [cgra_rtl_pkg::N_PE-1:0] smu_pe_rsp_err_o,
  output logic [cgra_rtl_pkg::N_PE-1:0][cgra_rtl_pkg::VECTOR_W-1:0] smu_pe_rsp_data_o,
  output logic [cgra_rtl_pkg::N_PE-1:0][3:0] smu_pe_rsp_tag_o,

  // --------------------------------------------------------------------------
  // SMU DMA/WBQ compatibility and formal producer interfaces
  // --------------------------------------------------------------------------
  input  logic                         dma_wb_valid_i,
  input  logic [cgra_rtl_pkg::LOCAL_ADDR_W-1:0] dma_wb_addr_i,
  input  logic [cgra_rtl_pkg::VECTOR_W-1:0] dma_wb_data_i,

  input  logic                         wbq_enq_valid_i,
  output logic                         wbq_enq_ready_o,
  input  logic [1:0]                   wbq_enq_bank_idx_i,
  input  logic [7:0]                   wbq_enq_line_addr_i,
  input  logic [cgra_rtl_pkg::VECTOR_W-1:0] wbq_enq_data_i,
  input  logic [3:0]                   wbq_enq_tag_i,
  input  logic                         wbq_enq_completion_credit_i,

  input  logic                         dma_local_dst_active_i,
  input  logic [cgra_rtl_pkg::LOCAL_ADDR_W-1:0] dma_local_dst_start_i,
  input  logic [cgra_rtl_pkg::LOCAL_ADDR_W-1:0] dma_local_dst_end_i,
  input  logic                         dma_issue_active_i,
  input  logic                         dma_issue_error_i,
  input  logic [cgra_rtl_pkg::GLOBAL_ADDR_W-1:0] dma_issue_dst_base_i,
  input  logic [3:0]                   dma_issue_tag_candidate_i,

  // --------------------------------------------------------------------------
  // SMU / NoC receive and transmit boundaries
  // --------------------------------------------------------------------------
  input  logic                         revb_noc_rx_valid_i,
  output logic                         revb_noc_rx_ready_o,
  input  logic [1:0]                   revb_noc_rx_opcode_i,
  input  logic [cgra_rtl_pkg::GLOBAL_ADDR_W-1:0] revb_noc_rx_addr_i,
  input  logic [cgra_rtl_pkg::VECTOR_W-1:0] revb_noc_rx_data_i,
  input  logic [3:0]                   revb_noc_rx_tag_i,
  input  logic [3:0]                   revb_noc_rx_requester_i,
  input  logic                         revb_noc_rx_path_i,

  input  logic                         revb_noc_rx_read_req_valid_i,
  output logic                         revb_noc_rx_read_req_ready_o,
  input  logic [cgra_rtl_pkg::GLOBAL_ADDR_W-1:0] revb_noc_rx_read_req_addr_i,
  input  logic [3:0]                   revb_noc_rx_read_req_tag_i,
  input  logic [3:0]                   revb_noc_rx_read_req_requester_i,
  input  logic                         revb_noc_rx_read_req_path_i,

  output logic                         revb_noc_tx_read_rsp_valid_o,
  input  logic                         revb_noc_tx_read_rsp_ready_i,
  output logic [1:0]                   revb_noc_tx_read_rsp_opcode_o,
  output logic [cgra_rtl_pkg::VECTOR_W-1:0] revb_noc_tx_read_rsp_data_o,
  output logic [3:0]                   revb_noc_tx_read_rsp_tag_o,
  output logic [3:0]                   revb_noc_tx_read_rsp_requester_o,
  output logic                         revb_noc_tx_read_rsp_path_o,

  input  logic                         remote_rd_enq_valid_i,
  output logic                         remote_rd_enq_ready_o,
  input  logic [1:0]                   remote_rd_enq_bank_idx_i,
  input  logic [7:0]                   remote_rd_enq_line_addr_i,
  input  logic [3:0]                   remote_rd_enq_tag_i,
  input  logic [3:0]                   remote_rd_enq_requester_i,
  input  logic                         remote_rd_enq_path_i,

  output logic                         remote_rd_rsp_valid_o,
  input  logic                         remote_rd_rsp_ready_i,
  output logic [cgra_rtl_pkg::VECTOR_W-1:0] remote_rd_rsp_data_o,
  output logic [3:0]                   remote_rd_rsp_tag_o,
  output logic [3:0]                   remote_rd_rsp_requester_o,
  output logic                         remote_rd_rsp_path_o
);

  import cgra_rtl_pkg::*;


  logic [N_PE-1:0] pe_busy;
  logic [N_PE*VECTOR_W-1:0] pe_result_data;
  logic cordic_busy, cordic_done;
  logic signed [15:0] cordic_r, cordic_c, cordic_s;

  // --------------------------------------------------------------------------
  // cluster_top interface wires
  // --------------------------------------------------------------------------
  logic                  qr_mem_req_valid;
  logic                  qr_mem_req_ready;
  logic                  qr_mem_req_write;
  logic [LOCAL_ADDR_W-1:0] qr_mem_req_addr;
  logic                  qr_mem_rsp_valid;
  logic [VECTOR_W-1:0]   qr_mem_rsp_data;

  logic                  pe_issue_valid;
  logic                  pe_issue_ready;
  logic [35:0]           pe_slots;
  logic [PARAM_ID_W-1:0] pe_param_id;
  logic [2:0]            pe_legacy_ctx_id;
  logic [EXEC_IMM_W-1:0] pe_immediate;
  logic [CTX_W-1:0]      pe_context;
  logic                  pe_param_valid;
  logic [VECTOR_W-1:0]   pe_param_vector;
  logic [PARAM_TAG_W-1:0] pe_param_tag;

  logic                  fir_agu_active;
  logic [7:0]            fir_k_group;
  logic [7:0]            fir_k_group_limit;
  logic [N_PE*LANES-1:0] fir_x_valid;
  logic [N_PE*LANES*FIR_INDEX_W-1:0] fir_x_index;
  logic [LANES-1:0]      fir_h_valid;
  logic [LANES*FIR_TAPS_W-1:0] fir_h_index;
  logic [N_PE*FIR_SAMPLES_W-1:0] fir_sample_index;

  logic                  qr_pe_pairs_valid;
  logic                  qr_pe_pairs_ready;
  logic [N_PE*VECTOR_W-1:0] qr_pe_pairs;
  logic                  qr_target_reset;
  logic [QR_TARGET_INPUT_VECS-1:0] qr_target_valid_q;
  logic [QR_TARGET_INPUT_VECS*VECTOR_W-1:0] qr_target_vectors_q;
  logic                  cordic_qr_pair_valid;
  logic signed [LANE_W-1:0] cordic_qr_pivot;
  logic signed [LANE_W-1:0] cordic_qr_target;

  logic                  cordic_req_valid;
  logic                  cordic_req_ready;
  logic                  cordic_mode_twiddle;
  logic [15:0]           cordic_twiddle_j;
  logic [3:0]            cordic_twiddle_m_log2;
  logic [PARAM_ID_W-1:0] cordic_param_id;
  logic [EXEC_IMM_W-1:0] cordic_immediate;
  logic [CTX_W-1:0]      cordic_context;
  logic                  cordic_rsp_valid;
  logic [VECTOR_W-1:0]   cordic_rsp_vector;
  logic signed [LANE_W-1:0] cordic_rsp_cos;
  logic signed [LANE_W-1:0] cordic_rsp_sin;
  logic                  cordic_idle;

  logic [N_PE-1:0]       pe_result_ready;
  logic [N_PE*PARAM_ID_W-1:0] pe_result_pid;
  logic [N_PE-1:0]       pe_writeback_valid;
  logic [N_PE-1:0]       pe_writeback_ready;
  logic [N_PE*VECTOR_W-1:0] pe_writeback_data;
  logic [N_PE*PARAM_ID_W-1:0] pe_writeback_pid;
  logic [N_PE*EXEC_IMM_W-1:0] pe_writeback_immediate;

  logic                  cordic_broadcast_valid;
  logic                  cordic_broadcast_ready;
  logic [VECTOR_W-1:0]   cordic_broadcast_data;
  logic [PARAM_ID_W-1:0] cordic_broadcast_pid;
  logic [N_PE-1:0]       xbar_dst_valid;
  logic [N_PE-1:0]       xbar_dst_pop;
  logic [N_PE*VECTOR_W-1:0] xbar_dst_data;

  // --------------------------------------------------------------------------
  // PE core wiring and result holding buffers
  // --------------------------------------------------------------------------
  logic [N_PE-1:0] pe_done;
  logic [N_PE-1:0][LANES*16-1:0] pe_reg_out_flat;
  logic [N_PE-1:0] result_valid_q;
  logic [N_PE-1:0][VECTOR_W-1:0] result_data_q;

  logic [N_PE-1:0][8:0] slot_bits;
  logic [N_PE-1:0] slot_active;
  logic [N_PE-1:0][2:0] slot_upstream;
  logic [N_PE-1:0][2:0] slot_downstream;
  logic [N_PE-1:0][2:0] slot_op;
  logic [N_PE-1:0] pe_fire;
  logic [N_PE-1:0] pe_core_ready;

  logic signed [15:0] pe_fire_din [N_PE][LANES];
  logic signed [15:0] pe_fire_tw  [N_PE][LANES];
  logic signed [15:0] pe_fire_cmul_v_re [N_PE];
  logic signed [15:0] pe_fire_cmul_v_im [N_PE];

  // One-entry local-memory operand buffer per PE.
  logic [N_PE-1:0] mem_operand_valid_q;
  logic [N_PE-1:0][VECTOR_W-1:0] mem_operand_data_q;

  // MM V4.1 operand landing / B-stationary prefetch.
  logic                  mm_mac_valid;
  logic                  mm_issue_fire;
  logic                  mm_operands_ready;
  logic [VECTOR_W-1:0]   mm_a_vector;
  logic [N_PE*VECTOR_W-1:0] mm_b_vectors;
  logic [N_PE-1:0]       mm_b_req_valid;
  logic [N_PE-1:0]       mm_b_req_ready;
  logic [N_PE-1:0][LOCAL_ADDR_W-1:0] mm_b_req_addr;
  logic [N_PE-1:0][3:0]  mm_b_req_tag;

  // V4.1 FFT streaming controller and shared-PE handshake.
  logic                  fft_task_ready_int;
  logic                  fft_input_fill_ready_int;
  logic                  fft_stage_done_int;
  logic                  fft_stream_busy_int;
  logic                  fft_pe_req_valid;
  logic                  fft_pe_req_ready;
  logic                  fft_pe_req_slot;
  logic [VECTOR_W-1:0]   fft_pe_req_input0;
  logic [VECTOR_W-1:0]   fft_pe_req_input1;
  logic [VECTOR_W-1:0]   fft_pe_req_twiddles;
  logic                  fft_pe_rsp_valid;
  logic                  fft_pe_rsp_ready;
  logic                  fft_pe_rsp_slot;
  logic [VECTOR_W-1:0]   fft_pe_rsp_result0;
  logic [VECTOR_W-1:0]   fft_pe_rsp_result1;
  logic                  fft_result_valid;
  logic                  fft_result_ready;
  logic [VECTOR_W-1:0]   fft_result_vec0;
  logic [VECTOR_W-1:0]   fft_result_vec1;
  logic [LOCAL_ADDR_W-1:0] fft_result_dst0_addr;
  logic [LOCAL_ADDR_W-1:0] fft_result_dst1_addr;
  logic                  fft_pe_launch;
  logic                  fft_pe_active_q;
  logic                  fft_pe_active_slot_q;
  logic                  fft_rsp_hold_valid_q;
  logic                  fft_rsp_hold_slot_q;
  logic [VECTOR_W-1:0]   fft_rsp_hold_vec0_q;
  logic [VECTOR_W-1:0]   fft_rsp_hold_vec1_q;
  logic [VECTOR_W-1:0]   pe_selected_din [N_PE];
  logic [VECTOR_W-1:0]   pe_selected_tw [N_PE];
  context_entry_pkg::pe_op_e pe_fire_op [N_PE];

  typedef enum logic [2:0] {
    FFT_DRAIN_IDLE, FFT_PACK0_1, FFT_PACK0_2, FFT_WRITE0,
    FFT_PACK1_1, FFT_PACK1_2, FFT_WRITE1
  } fft_drain_state_e;
  fft_drain_state_e      fft_drain_state_q;
  logic [VECTOR_W-1:0]   fft_drain_vec0_q, fft_drain_vec1_q;
  logic [LOCAL_ADDR_W-1:0] fft_drain_addr0_q, fft_drain_addr1_q;
  logic                  fft_drain_write_valid;
  logic                  fft_drain_write_ready;
  logic [LOCAL_ADDR_W-1:0] fft_drain_write_addr;
  logic [VECTOR_W-1:0]   fft_drain_write_data;

  // --------------------------------------------------------------------------
  // SMU request mux and response wires
  // --------------------------------------------------------------------------
  logic [N_PE-1:0] smu_pe_req_valid;
  logic [N_PE-1:0] smu_pe_req_ready;
  logic [N_PE-1:0][1:0] smu_pe_req_type;
  logic [N_PE-1:0] smu_pe_req_is_vec;
  logic [N_PE-1:0][LOCAL_ADDR_W-1:0] smu_pe_req_addr;
  logic [N_PE-1:0][VECTOR_W-1:0] smu_pe_req_data;
  logic [N_PE-1:0][3:0] smu_pe_req_wstrb;
  logic [N_PE-1:0][3:0] smu_pe_req_tag;

  logic [N_PE-1:0] smu_pe_rsp_valid;
  logic [N_PE-1:0] smu_pe_rsp_kind;
  logic [N_PE-1:0] smu_pe_rsp_err;
  logic [N_PE-1:0][VECTOR_W-1:0] smu_pe_rsp_data;
  logic [N_PE-1:0][3:0] smu_pe_rsp_tag;
  logic [LOCAL_BANKS-1:0] wbq_commit_valid;
  logic [LOCAL_BANKS-1:0][LOCAL_ADDR_W-1:0] wbq_commit_addr;
  logic [LOCAL_BANKS-1:0][VECTOR_W-1:0] wbq_commit_data;


  // --------------------------------------------------------------------------
  // Cluster control/issue hierarchy
  // --------------------------------------------------------------------------
  cluster_top #(
    .CLUSTER_ID(CLUSTER_ID),
    .XBAR_FIFO_DEPTH(XBAR_FIFO_DEPTH),
    .ENABLE_LOCAL_XBAR(ENABLE_LOCAL_XBAR)
  ) u_cluster (
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .imem_wr_en_i(imem_wr_en_i),
    .imem_wr_addr_i(imem_wr_addr_i),
    .imem_wr_data_i(imem_wr_data_i),
    .ctx_wr_en_i(ctx_wr_en_i),
    .ctx_wr_addr_i(ctx_wr_addr_i),
    .ctx_wr_data_i(ctx_wr_data_i),
    .start_i(start_i),
    .program_words_i(program_words_i),
    .done_o(done_o),
    .active_o(active_o),
    .fault_o(fault_o),
    .fault_code_o(fault_code_o),
    .barrier_req_o(barrier_req_o),
    .barrier_token_o(barrier_token_o),
    .barrier_release_i(barrier_release_i),
    .dma_req_valid_o(dma_req_valid_o),
    .dma_req_ready_i(dma_req_ready_i),
    .dma_src_cluster_o(dma_src_cluster_o),
    .dma_dst_cluster_o(dma_dst_cluster_o),
    .dma_src_local_o(dma_src_local_o),
    .dma_dst_local_o(dma_dst_local_o),
    .dma_len_vec_o(dma_len_vec_o),
    .dma_requester_pe_o(dma_requester_pe_o),
    .dma_tag_o(dma_tag_o),
    .dma_idle_i(dma_idle_i),
    .qr_mem_req_valid_o(qr_mem_req_valid),
    .qr_mem_req_ready_i(qr_mem_req_ready),
    .qr_mem_req_write_o(qr_mem_req_write),
    .qr_mem_req_addr_o(qr_mem_req_addr),
    .qr_mem_rsp_valid_i(qr_mem_rsp_valid),
    .qr_mem_rsp_data_i(qr_mem_rsp_data),
    .pe_issue_valid_o(pe_issue_valid),
    .pe_issue_ready_i(pe_issue_ready),
    .pe_slots_o(pe_slots),
    .pe_param_id_o(pe_param_id),
    .pe_legacy_ctx_id_o(pe_legacy_ctx_id),
    .pe_immediate_o(pe_immediate),
    .pe_context_o(pe_context),
    .pe_param_valid_o(pe_param_valid),
    .pe_param_vector_o(pe_param_vector),
    .pe_param_tag_o(pe_param_tag),
    .fir_agu_active_o(fir_agu_active),
    .fir_k_group_o(fir_k_group),
    .fir_k_group_limit_o(fir_k_group_limit),
    .fir_x_valid_o(fir_x_valid),
    .fir_x_index_o(fir_x_index),
    .fir_h_valid_o(fir_h_valid),
    .fir_h_index_o(fir_h_index),
    .fir_sample_index_o(fir_sample_index),
    .pe_busy_i(pe_busy),
    .ru_busy_i(1'b0),
    .qr_target_valid_i(qr_target_valid_q),
    .qr_target_vectors_i(qr_target_vectors_q),
    .qr_target_reset_o(qr_target_reset),
    .qr_pe_pairs_valid_o(qr_pe_pairs_valid),
    .qr_pe_pairs_ready_i(qr_pe_pairs_ready),
    .qr_pe_pairs_o(qr_pe_pairs),
    .cordic_qr_pair_valid_o(cordic_qr_pair_valid),
    .cordic_qr_pivot_o(cordic_qr_pivot),
    .cordic_qr_target_o(cordic_qr_target),
    .cordic_req_valid_o(cordic_req_valid),
    .cordic_req_ready_i(cordic_req_ready),
    .cordic_mode_twiddle_o(cordic_mode_twiddle),
    .cordic_twiddle_j_o(cordic_twiddle_j),
    .cordic_twiddle_m_log2_o(cordic_twiddle_m_log2),
    .cordic_param_id_o(cordic_param_id),
    .cordic_immediate_o(cordic_immediate),
    .cordic_context_o(cordic_context),
    .cordic_rsp_valid_i(cordic_rsp_valid),
    .cordic_rsp_vector_i(cordic_rsp_vector),
    .cordic_rsp_cos_i(cordic_rsp_cos),
    .cordic_rsp_sin_i(cordic_rsp_sin),
    .cordic_idle_i(cordic_idle),
    .ext_param_wr_valid_i(ext_param_wr_valid_i),
    .ext_param_wr_ready_o(ext_param_wr_ready_o),
    .ext_param_wr_op_i(ext_param_wr_op_i),
    .ext_param_wr_pid_i(ext_param_wr_pid_i),
    .ext_param_wr_data_i(ext_param_wr_data_i),
    .ext_param_wr_pair_c_i(ext_param_wr_pair_c_i),
    .ext_param_wr_pair_s_i(ext_param_wr_pair_s_i),
    .ext_param_wr_tag_i(ext_param_wr_tag_i),
    .pe_result_valid_i(result_valid_q),
    .pe_result_ready_o(pe_result_ready),
    .pe_result_data_i(pe_result_data),
    .pe_result_pid_i(pe_result_pid),
    .pe_writeback_valid_o(pe_writeback_valid),
    .pe_writeback_ready_i(pe_writeback_ready),
    .pe_writeback_data_o(pe_writeback_data),
    .pe_writeback_pid_o(pe_writeback_pid),
    .pe_writeback_immediate_o(pe_writeback_immediate),
    .cordic_broadcast_valid_i(cordic_broadcast_valid),
    .cordic_broadcast_ready_o(cordic_broadcast_ready),
    .cordic_broadcast_data_i(cordic_broadcast_data),
    .cordic_broadcast_pid_i(cordic_broadcast_pid),
    .xbar_dst_valid_o(xbar_dst_valid),
    .xbar_dst_pop_i(xbar_dst_pop),
    .xbar_dst_data_o(xbar_dst_data)
  );

  assign mm_mac_valid = pe_issue_valid &&
                        (micro_kind_e'(pe_context[CTX_KIND_LSB +: 5]) == M_MM_MAC) &&
                        ((pe_immediate[28:25] & MICRO_FLAG_MM_PINGPONG) != 0);
  assign mm_issue_fire = mm_mac_valid && pe_issue_ready;

  mm_operand_buffer u_mm_operand_buffer (
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .commit_valid_i(wbq_commit_valid),
    .commit_addr_i(wbq_commit_addr),
    .commit_data_i(wbq_commit_data),
    .dma_cmd_fire_i(dma_req_valid_o && dma_req_ready_i),
    .dma_kind_i(pe_context[CTX_KIND_LSB +: 5]),
    .dma_flags_i(pe_context[CTX_FLAGS_LSB +: 4]),
    .dma_dst_local_i(dma_dst_local_o),
    .mm_mac_valid_i(mm_mac_valid),
    .immediate_i(pe_immediate),
    .context_i(pe_context),
    .issue_fire_i(mm_issue_fire),
    .operands_ready_o(mm_operands_ready),
    .a_vector_o(mm_a_vector),
    .b_vectors_o(mm_b_vectors),
    .b_req_valid_o(mm_b_req_valid),
    .b_req_ready_i(mm_b_req_ready),
    .b_req_addr_o(mm_b_req_addr),
    .b_req_tag_o(mm_b_req_tag),
    .b_rsp_valid_i(smu_pe_rsp_valid),
    .b_rsp_err_i(smu_pe_rsp_err),
    .b_rsp_kind_i(smu_pe_rsp_kind),
    .b_rsp_data_i(smu_pe_rsp_data),
    .b_rsp_tag_i(smu_pe_rsp_tag)
  );

  assign fft_task_ready_o = fft_stream_enable_i && fft_task_ready_int;
  assign fft_input_fill_ready_o = fft_stream_enable_i && fft_input_fill_ready_int;
  assign fft_stage_done_o = fft_stage_done_int;
  assign fft_stream_busy_o = fft_stream_busy_int || fft_pe_active_q ||
                             fft_rsp_hold_valid_q ||
                             (fft_drain_state_q != FFT_DRAIN_IDLE);

  fft_stream_engine u_fft_stream (
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .task_valid_i(fft_stream_enable_i && fft_task_valid_i),
    .task_ready_o(fft_task_ready_int),
    .task_slot_o(fft_task_slot_o),
    .task_seed_re_i(fft_task_seed_re_i),
    .task_seed_im_i(fft_task_seed_im_i),
    .task_step_re_i(fft_task_step_re_i),
    .task_step_im_i(fft_task_step_im_i),
    .task_dst0_addr_i(fft_task_dst0_addr_i),
    .task_dst1_addr_i(fft_task_dst1_addr_i),
    .input_fill_valid_i(fft_stream_enable_i && fft_input_fill_valid_i),
    .input_fill_ready_o(fft_input_fill_ready_int),
    .input_fill_slot_i(fft_input_fill_slot_i),
    .input_fill_vector_i(fft_input_fill_vector_i),
    .input_fill_data_i(fft_input_fill_data_i),
    .pe_req_valid_o(fft_pe_req_valid),
    .pe_req_ready_i(fft_pe_req_ready),
    .pe_req_slot_o(fft_pe_req_slot),
    .pe_req_input0_o(fft_pe_req_input0),
    .pe_req_input1_o(fft_pe_req_input1),
    .pe_req_twiddles_o(fft_pe_req_twiddles),
    .pe_rsp_valid_i(fft_pe_rsp_valid),
    .pe_rsp_ready_o(fft_pe_rsp_ready),
    .pe_rsp_slot_i(fft_pe_rsp_slot),
    .pe_rsp_result0_i(fft_pe_rsp_result0),
    .pe_rsp_result1_i(fft_pe_rsp_result1),
    .result_valid_o(fft_result_valid),
    .result_ready_i(fft_result_ready),
    .result_vec0_o(fft_result_vec0),
    .result_vec1_o(fft_result_vec1),
    .result_dst0_addr_o(fft_result_dst0_addr),
    .result_dst1_addr_o(fft_result_dst1_addr),
    .stage_close_i(fft_stream_enable_i && fft_stage_close_i),
    .stage_done_o(fft_stage_done_int),
    .busy_o(fft_stream_busy_int)
  );

  // --------------------------------------------------------------------------
  // PE slot decode, operand selection and issue readiness
  // --------------------------------------------------------------------------
  always_comb begin
    // Autonomous instructions and the FFT stream engine share the same four
    // non-pipelined PEs.  FFT mode reserves the complete bundle.
    pe_issue_ready = !fft_stream_enable_i && !fft_pe_active_q &&
                     !fft_rsp_hold_valid_q;
    qr_pe_pairs_ready = 1'b0;
    xbar_dst_pop = '0;

    for (int p = 0; p < N_PE; p++) begin
      slot_bits[p]       = pe_slots[p*9 +: 9];
      slot_op[p]         = slot_bits[p][8:6];
      slot_upstream[p]   = slot_bits[p][5:3];
      slot_downstream[p] = slot_bits[p][2:0];
      slot_active[p]     = (slot_op[p] != PE_NOP);

      pe_core_ready[p] = !pe_busy[p] && !result_valid_q[p];
      if (slot_active[p]) begin
        if (slot_upstream[p] == DIR_MEM)
          pe_core_ready[p] &= mem_operand_valid_q[p];
        if (slot_upstream[p] == DIR_PE_RING)
          pe_core_ready[p] &= xbar_dst_valid[p];
        if (slot_upstream[p] == DIR_PARAM_RF)
          pe_core_ready[p] &= pe_param_valid;
        if (slot_op[p] == PE_CROT)
          pe_core_ready[p] &= qr_pe_pairs_valid;
        pe_issue_ready &= pe_core_ready[p];
      end
    end

    if (mm_mac_valid)
      pe_issue_ready &= mm_operands_ready;

    qr_pe_pairs_ready = !fft_stream_enable_i && pe_issue_valid && pe_issue_ready;

    fft_pe_req_ready = fft_stream_enable_i && !fft_pe_active_q &&
                       !fft_rsp_hold_valid_q && !(|pe_busy) &&
                       !(|result_valid_q);
    fft_pe_launch = fft_pe_req_valid && fft_pe_req_ready;

    for (int p = 0; p < N_PE; p++) begin
      pe_fire[p] = fft_pe_launch ||
                   (!fft_stream_enable_i && pe_issue_valid &&
                    pe_issue_ready && slot_active[p]);
      pe_fire_op[p] = fft_pe_launch ? context_entry_pkg::OP_CMUL :
                       context_entry_pkg::pe_op_e'(slot_op[p]);
      if (!fft_stream_enable_i && pe_fire[p] &&
          (slot_upstream[p] == DIR_PE_RING))
        xbar_dst_pop[p] = 1'b1;

      pe_selected_din[p] = pe_operand_i[p*VECTOR_W +: VECTOR_W];
      if (slot_upstream[p] == DIR_MEM)
        pe_selected_din[p] = mem_operand_data_q[p];
      else if (slot_upstream[p] == DIR_PE_RING)
        pe_selected_din[p] = xbar_dst_data[p*VECTOR_W +: VECTOR_W];
      else if (slot_upstream[p] == DIR_PARAM_RF)
        pe_selected_din[p] = pe_param_vector;
      if ((slot_op[p] == PE_CROT) && qr_pe_pairs_valid)
        pe_selected_din[p] = qr_pe_pairs[p*VECTOR_W +: VECTOR_W];
      if (mm_mac_valid)
        pe_selected_din[p] = mm_a_vector;

      pe_selected_tw[p] = pe_twiddle_i[p*VECTOR_W +: VECTOR_W];
      if (pe_param_valid)
        pe_selected_tw[p] = pe_param_vector;
      if (mm_mac_valid)
        pe_selected_tw[p] = mm_b_vectors[p*VECTOR_W +: VECTOR_W];

      pe_fire_cmul_v_re[p] =
        $signed(pe_cmul_v_i[(p*2+0)*16 +: 16]);
      pe_fire_cmul_v_im[p] =
        $signed(pe_cmul_v_i[(p*2+1)*16 +: 16]);

      if (fft_pe_launch) begin
        pe_selected_din[p] = '0;
        pe_selected_tw[p] = '0;
        pe_selected_din[p][0*LANE_W +: LANE_W] =
          fft_pe_req_input0[(p*2+0)*LANE_W +: LANE_W];
        pe_selected_din[p][1*LANE_W +: LANE_W] =
          fft_pe_req_input0[(p*2+1)*LANE_W +: LANE_W];
        pe_selected_tw[p][0*LANE_W +: LANE_W] =
          fft_pe_req_twiddles[(p*2+0)*LANE_W +: LANE_W];
        pe_selected_tw[p][1*LANE_W +: LANE_W] =
          fft_pe_req_twiddles[(p*2+1)*LANE_W +: LANE_W];
        pe_fire_cmul_v_re[p] =
          $signed(fft_pe_req_input1[(p*2+0)*LANE_W +: 16]);
        pe_fire_cmul_v_im[p] =
          $signed(fft_pe_req_input1[(p*2+1)*LANE_W +: 16]);
      end
    end

    if (!fft_stream_enable_i && cordic_req_valid && cordic_req_ready &&
        (cordic_src_sel == 2'd2))
      xbar_dst_pop[0] = 1'b1;
  end

  generate
    for (genvar gp = 0; gp < N_PE; gp++) begin : g_pe
      for (genvar gl = 0; gl < LANES; gl++) begin : g_operand_unpack
        always_comb begin
          pe_fire_din[gp][gl] =
            $signed(pe_selected_din[gp][gl*LANE_W +: 16]);
          pe_fire_tw[gp][gl] =
            $signed(pe_selected_tw[gp][gl*LANE_W +: 16]);
        end
      end

      pe u_pe (
        .clk(clk_i),
        .rst_n(rst_ni),
        .fire(pe_fire[gp]),
        .fire_op(pe_fire_op[gp]),
        .fire_din(pe_fire_din[gp]),
        .fire_tw(pe_fire_tw[gp]),
        .fire_cmul_v_re(pe_fire_cmul_v_re[gp]),
        .fire_cmul_v_im(pe_fire_cmul_v_im[gp]),
        .fire_mac_acc_clear(!fft_pe_launch && (slot_op[gp] == PE_MAC) &&
                            !pe_context[CTX_ACC_BIT]),
        .fire_reduce_acc_raw(!fft_pe_launch && (slot_upstream[gp] == DIR_ACC)),
        .fire_acc_context(!fft_pe_launch && pe_legacy_ctx_id[0]),
        .busy(pe_busy[gp]),
        .done(pe_done[gp]),
        .reg_out_flat(pe_reg_out_flat[gp])
      );

      always_comb begin
        result_data_q[gp] = '0;
        for (int l = 0; l < LANES; l++) begin
          result_data_q[gp][l*LANE_W +: LANE_W] =
            {{(LANE_W-16){pe_reg_out_flat[gp][l*16+15]}},
              pe_reg_out_flat[gp][l*16 +: 16]};
        end
      end
    end
  endgenerate

  // Autonomous results are held until cluster_top accepts/reroutes them.
  // FFT results bypass that path and are packed into two vectors below.
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      result_valid_q <= '0;
    end else begin
      for (int p = 0; p < N_PE; p++) begin
        if (result_valid_q[p] && pe_result_ready[p])
          result_valid_q[p] <= 1'b0;
        if (pe_done[p] && !fft_pe_active_q)
          result_valid_q[p] <= 1'b1;
      end
    end
  end

  // Four PE CMUL results are packed as two architectural vectors.  A holding
  // register preserves the ready/valid response when the two-entry FIFO is full.
  always_comb begin
    fft_pe_rsp_valid = fft_rsp_hold_valid_q;
    fft_pe_rsp_slot = fft_rsp_hold_slot_q;
    fft_pe_rsp_result0 = fft_rsp_hold_vec0_q;
    fft_pe_rsp_result1 = fft_rsp_hold_vec1_q;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin : p_fft_pe_response
    logic [VECTOR_W-1:0] packed0, packed1;
    if (!rst_ni) begin
      fft_pe_active_q <= 1'b0;
      fft_pe_active_slot_q <= 1'b0;
      fft_rsp_hold_valid_q <= 1'b0;
      fft_rsp_hold_slot_q <= 1'b0;
      fft_rsp_hold_vec0_q <= '0;
      fft_rsp_hold_vec1_q <= '0;
    end else begin
      if (fft_pe_launch) begin
        fft_pe_active_q <= 1'b1;
        fft_pe_active_slot_q <= fft_pe_req_slot;
      end

      if (fft_pe_active_q && (&pe_done)) begin
        packed0 = '0;
        packed1 = '0;
        for (int p = 0; p < N_PE; p++) begin
          packed0[(p*2+0)*LANE_W +: LANE_W] =
            {{(LANE_W-16){pe_reg_out_flat[p][0*16+15]}},
              pe_reg_out_flat[p][0*16 +: 16]};
          packed0[(p*2+1)*LANE_W +: LANE_W] =
            {{(LANE_W-16){pe_reg_out_flat[p][1*16+15]}},
              pe_reg_out_flat[p][1*16 +: 16]};
          packed1[(p*2+0)*LANE_W +: LANE_W] =
            {{(LANE_W-16){pe_reg_out_flat[p][2*16+15]}},
              pe_reg_out_flat[p][2*16 +: 16]};
          packed1[(p*2+1)*LANE_W +: LANE_W] =
            {{(LANE_W-16){pe_reg_out_flat[p][3*16+15]}},
              pe_reg_out_flat[p][3*16 +: 16]};
        end
        fft_rsp_hold_valid_q <= 1'b1;
        fft_rsp_hold_slot_q <= fft_pe_active_slot_q;
        fft_rsp_hold_vec0_q <= packed0;
        fft_rsp_hold_vec1_q <= packed1;
        fft_pe_active_q <= 1'b0;
      end

      if (fft_rsp_hold_valid_q && fft_pe_rsp_ready)
        fft_rsp_hold_valid_q <= 1'b0;
    end
  end

  always_comb begin
    pe_result_data = '0;
    pe_result_pid = '0;
    for (int p = 0; p < N_PE; p++) begin
      pe_result_data[p*VECTOR_W +: VECTOR_W] = result_data_q[p];
      pe_result_pid[p*PARAM_ID_W +: PARAM_ID_W] = pe_param_id;
    end
  end

  // --------------------------------------------------------------------------
  // Registered local CORDIC integration
  // --------------------------------------------------------------------------
  logic signed [15:0] cordic_a;
  logic signed [15:0] cordic_b;
  logic [1:0] cordic_src_sel;
  logic [1:0] cordic_dst_sel;
  logic [PARAM_ID_W-1:0] cordic_pid_q;
  logic [1:0] cordic_dst_q;
  logic cordic_mode_q;
  logic cordic_source_ready;
  logic cordic_broadcast_valid_q;
  logic [PARAM_ID_W-1:0] cordic_broadcast_pid_q;

  always_comb begin
    cordic_src_sel = cordic_context[CTX_CORDIC_SRC_LSB +: 2];
    cordic_dst_sel = cordic_context[CTX_CORDIC_DST_LSB +: 2];
    cordic_a = $signed(mem_operand_data_q[0][0 +: 16]);
    cordic_b = $signed(mem_operand_data_q[0][LANE_W +: 16]);
    cordic_source_ready = mem_operand_valid_q[0];
    case (cordic_src_sel)
      2'd1: begin
        cordic_a = $signed(result_data_q[0][0 +: 16]);
        cordic_b = $signed(result_data_q[0][LANE_W +: 16]);
        cordic_source_ready = 1'b1;
      end
      2'd2: begin
        cordic_a = $signed(xbar_dst_data[0 +: 16]);
        cordic_b = $signed(xbar_dst_data[LANE_W +: 16]);
        cordic_source_ready = xbar_dst_valid[0];
      end
      default: begin end
    endcase
    // Production QR path: use the explicit pivot preload cache and the target-R
    // landing buffer, not PE0's generic operand slot.
    if (cordic_qr_pair_valid) begin
      cordic_a = $signed(cordic_qr_pivot[15:0]);
      cordic_b = $signed(cordic_qr_target[15:0]);
      cordic_source_ready = 1'b1;
    end
  end

  assign cordic_req_ready = !cordic_busy && !cordic_broadcast_valid_q &&
                            (cordic_mode_twiddle || cordic_source_ready);
  assign cordic_idle = !cordic_busy;

  cordic_unit u_cordic (
    .clk(clk_i),
    .rst_n(rst_ni),
    .start(cordic_req_valid && cordic_req_ready),
    .mode_twiddle_i(cordic_mode_twiddle),
    .a_in(cordic_a),
    .b_in(cordic_b),
    .twiddle_j_i(cordic_twiddle_j),
    .twiddle_m_log2_i(cordic_twiddle_m_log2),
    .busy(cordic_busy),
    .done(cordic_done),
    .r_out(cordic_r),
    .c_out(cordic_c),
    .s_out(cordic_s)
  );

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cordic_pid_q <= '0;
      cordic_dst_q <= 2'd0;
      cordic_broadcast_valid_q <= 1'b0;
      cordic_broadcast_pid_q <= '0;
      cordic_mode_q <= 1'b0;
    end else begin
      if (cordic_req_valid && cordic_req_ready) begin
        cordic_pid_q <= cordic_param_id;
        cordic_dst_q <= cordic_dst_sel;
        cordic_mode_q <= cordic_mode_twiddle;
      end
      if (cordic_broadcast_valid_q && cordic_broadcast_ready)
        cordic_broadcast_valid_q <= 1'b0;
      if (cordic_done && ((cordic_dst_q == 2'd1) || (cordic_dst_q == 2'd2))) begin
        cordic_broadcast_valid_q <= 1'b1;
        cordic_broadcast_pid_q <= cordic_pid_q;
      end
    end
  end

  always_comb begin
    cordic_rsp_vector = '0;
    if (cordic_mode_q) begin
      // FFT seed vector: first complex pair is {cos,sin}.
      cordic_rsp_vector[0*LANE_W +: LANE_W] = {{(LANE_W-16){cordic_c[15]}}, cordic_c};
      cordic_rsp_vector[1*LANE_W +: LANE_W] = {{(LANE_W-16){cordic_s[15]}}, cordic_s};
    end else begin
      // QR result vector: {r,c,s}.
      cordic_rsp_vector[0*LANE_W +: LANE_W] = {{(LANE_W-16){cordic_r[15]}}, cordic_r};
      cordic_rsp_vector[1*LANE_W +: LANE_W] = {{(LANE_W-16){cordic_c[15]}}, cordic_c};
      cordic_rsp_vector[2*LANE_W +: LANE_W] = {{(LANE_W-16){cordic_s[15]}}, cordic_s};
    end
    cordic_rsp_cos = {{(LANE_W-16){cordic_c[15]}}, cordic_c};
    cordic_rsp_sin = {{(LANE_W-16){cordic_s[15]}}, cordic_s};
    cordic_rsp_valid = cordic_done;

    cordic_broadcast_valid = cordic_broadcast_valid_q;
    // CORDIC outputs remain stable until the next accepted start. New starts
    // are blocked while the broadcast buffer is pending, so the live packed
    // result safely supplies the held ready/valid transaction.
    cordic_broadcast_data = cordic_rsp_vector;
    cordic_broadcast_pid = cordic_broadcast_pid_q;
  end

  // --------------------------------------------------------------------------
  // FFT RU/WBQ-equivalent result drain.  Each vector pays two registered pack
  // cycles followed by one accepted local-SRAM write, matching the model's
  // 2 * (RU_PACK=2 + WBQ_STORE=1) visibility cost.
  // --------------------------------------------------------------------------
  always_comb begin
    fft_drain_write_valid = (fft_drain_state_q == FFT_WRITE0) ||
                            (fft_drain_state_q == FFT_WRITE1);
    fft_drain_write_addr = (fft_drain_state_q == FFT_WRITE1) ?
                           fft_drain_addr1_q : fft_drain_addr0_q;
    fft_drain_write_data = (fft_drain_state_q == FFT_WRITE1) ?
                           fft_drain_vec1_q : fft_drain_vec0_q;
    fft_result_ready = (fft_drain_state_q == FFT_WRITE1) &&
                       fft_drain_write_ready;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin : p_fft_result_drain
    if (!rst_ni) begin
      fft_drain_state_q <= FFT_DRAIN_IDLE;
      fft_drain_vec0_q <= '0;
      fft_drain_vec1_q <= '0;
      fft_drain_addr0_q <= '0;
      fft_drain_addr1_q <= '0;
    end else begin
      unique case (fft_drain_state_q)
        FFT_DRAIN_IDLE: begin
          if (fft_result_valid) begin
            fft_drain_vec0_q <= fft_result_vec0;
            fft_drain_vec1_q <= fft_result_vec1;
            fft_drain_addr0_q <= fft_result_dst0_addr;
            fft_drain_addr1_q <= fft_result_dst1_addr;
            fft_drain_state_q <= FFT_PACK0_1;
          end
        end
        FFT_PACK0_1: fft_drain_state_q <= FFT_PACK0_2;
        FFT_PACK0_2: fft_drain_state_q <= FFT_WRITE0;
        FFT_WRITE0: begin
          if (fft_drain_write_ready)
            fft_drain_state_q <= FFT_PACK1_1;
        end
        FFT_PACK1_1: fft_drain_state_q <= FFT_PACK1_2;
        FFT_PACK1_2: fft_drain_state_q <= FFT_WRITE1;
        FFT_WRITE1: begin
          if (fft_drain_write_ready)
            fft_drain_state_q <= FFT_DRAIN_IDLE;
        end
        default: fft_drain_state_q <= FFT_DRAIN_IDLE;
      endcase
    end
  end

  // --------------------------------------------------------------------------
  // QR target landing buffer
  // --------------------------------------------------------------------------
  // Valid bits change only on a reset-input QR load or on an accepted SRAM
  // write. WBQ/Port-A commits cover DMA/direct transitions; accepted Port-B
  // vector writes cover the model's one direct-initial target preload and any
  // explicit local initialization. This prevents CORDIC/CROT from consuming
  // enqueued-but-not-yet-visible data.
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      qr_target_valid_q <= '0;
      qr_target_vectors_q <= '0;
    end else begin
      if (qr_target_reset)
        qr_target_valid_q <= '0;
      for (int b = 0; b < LOCAL_BANKS; b++) begin
        if (wbq_commit_valid[b]) begin
          case (wbq_commit_addr[b])
            LOCAL_ADDR_W'((QR_TARGET_INPUT_BASE_VEC + 0) * VECTOR_BYTES): begin
              qr_target_vectors_q[0*VECTOR_W +: VECTOR_W] <= wbq_commit_data[b];
              qr_target_valid_q[0] <= 1'b1;
            end
            LOCAL_ADDR_W'((QR_TARGET_INPUT_BASE_VEC + 1) * VECTOR_BYTES): begin
              qr_target_vectors_q[1*VECTOR_W +: VECTOR_W] <= wbq_commit_data[b];
              qr_target_valid_q[1] <= 1'b1;
            end
            LOCAL_ADDR_W'((QR_TARGET_INPUT_BASE_VEC + 2) * VECTOR_BYTES): begin
              qr_target_vectors_q[2*VECTOR_W +: VECTOR_W] <= wbq_commit_data[b];
              qr_target_valid_q[2] <= 1'b1;
            end
            LOCAL_ADDR_W'((QR_TARGET_INPUT_BASE_VEC + 3) * VECTOR_BYTES): begin
              qr_target_vectors_q[3*VECTOR_W +: VECTOR_W] <= wbq_commit_data[b];
              qr_target_valid_q[3] <= 1'b1;
            end
            default: begin end
          endcase
        end
      end
      // Port-B acceptance is the actual SRAM write visibility event for
      // external initialization and cluster-local writes.
      for (int p = 0; p < N_PE; p++) begin
        if (smu_pe_req_valid[p] && smu_pe_req_ready[p] &&
            (smu_pe_req_type[p] == 2'b01) && smu_pe_req_is_vec[p]) begin
          case (smu_pe_req_addr[p])
            LOCAL_ADDR_W'((QR_TARGET_INPUT_BASE_VEC + 0) * VECTOR_BYTES): begin
              qr_target_vectors_q[0*VECTOR_W +: VECTOR_W] <= smu_pe_req_data[p];
              qr_target_valid_q[0] <= 1'b1;
            end
            LOCAL_ADDR_W'((QR_TARGET_INPUT_BASE_VEC + 1) * VECTOR_BYTES): begin
              qr_target_vectors_q[1*VECTOR_W +: VECTOR_W] <= smu_pe_req_data[p];
              qr_target_valid_q[1] <= 1'b1;
            end
            LOCAL_ADDR_W'((QR_TARGET_INPUT_BASE_VEC + 2) * VECTOR_BYTES): begin
              qr_target_vectors_q[2*VECTOR_W +: VECTOR_W] <= smu_pe_req_data[p];
              qr_target_valid_q[2] <= 1'b1;
            end
            LOCAL_ADDR_W'((QR_TARGET_INPUT_BASE_VEC + 3) * VECTOR_BYTES): begin
              qr_target_vectors_q[3*VECTOR_W +: VECTOR_W] <= smu_pe_req_data[p];
              qr_target_valid_q[3] <= 1'b1;
            end
            default: begin end
          endcase
        end
      end
    end
  end

  // --------------------------------------------------------------------------
  // SMU request arbitration
  // --------------------------------------------------------------------------
  always_comb begin
    smu_pe_req_valid = '0;
    smu_pe_req_type = '0;
    smu_pe_req_is_vec = '0;
    smu_pe_req_addr = '0;
    smu_pe_req_data = '0;
    smu_pe_req_wstrb = '0;
    smu_pe_req_tag = '0;
    ext_pe_mem_req_ready_o = '0;
    pe_writeback_ready = '0;
    mm_b_req_ready = '0;
    fft_drain_write_ready = 1'b0;
    for (int p = 0; p < N_PE; p++) begin
      if ((p == 0) && fft_drain_write_valid) begin
        smu_pe_req_valid[p] = 1'b1;
        smu_pe_req_type[p] = 2'b01;
        smu_pe_req_is_vec[p] = 1'b1;
        smu_pe_req_addr[p] = fft_drain_write_addr;
        smu_pe_req_data[p] = fft_drain_write_data;
        smu_pe_req_wstrb[p] = 4'hF;
        smu_pe_req_tag[p] = 4'hD;
        fft_drain_write_ready = smu_pe_req_ready[p];
      end else if (pe_writeback_valid[p]) begin
        smu_pe_req_valid[p] = 1'b1;
        smu_pe_req_type[p] = 2'b01;
        smu_pe_req_is_vec[p] = 1'b1;
        smu_pe_req_addr[p] = pe_writeback_addr_i[p*LOCAL_ADDR_W +: LOCAL_ADDR_W];
        smu_pe_req_data[p] = pe_writeback_data[p*VECTOR_W +: VECTOR_W];
        smu_pe_req_wstrb[p] = 4'hF;
        smu_pe_req_tag[p] = pe_writeback_pid[p*PARAM_ID_W +: PARAM_ID_W];
        pe_writeback_ready[p] = smu_pe_req_ready[p];
      end else if (mm_b_req_valid[p]) begin
        smu_pe_req_valid[p] = 1'b1;
        smu_pe_req_type[p] = 2'b00;
        smu_pe_req_is_vec[p] = 1'b1;
        smu_pe_req_addr[p] = mm_b_req_addr[p];
        smu_pe_req_data[p] = '0;
        smu_pe_req_wstrb[p] = 4'h0;
        smu_pe_req_tag[p] = mm_b_req_tag[p];
        mm_b_req_ready[p] = smu_pe_req_ready[p];
      end else begin
        // The SMU response port is registered but has no downstream ready.
        // Do not accept a second ordinary read until its one-entry operand
        // latch is empty, and reserve tag E for the internal MM reader.
        if (!((ext_pe_mem_req_type_i[p] == 2'b00) &&
              (mem_operand_valid_q[p] || (ext_pe_mem_req_tag_i[p] == 4'hE)))) begin
          smu_pe_req_valid[p] = ext_pe_mem_req_valid_i[p];
          smu_pe_req_type[p] = ext_pe_mem_req_type_i[p];
          smu_pe_req_is_vec[p] = ext_pe_mem_req_is_vec_i[p];
          smu_pe_req_addr[p] = ext_pe_mem_req_addr_i[p];
          smu_pe_req_data[p] = ext_pe_mem_req_data_i[p];
          smu_pe_req_wstrb[p] = ext_pe_mem_req_wstrb_i[p];
          smu_pe_req_tag[p] = ext_pe_mem_req_tag_i[p];
          ext_pe_mem_req_ready_o[p] = smu_pe_req_ready[p];
        end
      end
    end
  end

  // Ordinary PE read responses are buffered as DIR_MEM operands. QR pivot
  // preload has its own non-PE Port-A response channel below.
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      mem_operand_valid_q <= '0;
      mem_operand_data_q <= '0;
    end else begin
      for (int p = 0; p < N_PE; p++) begin
        if (!fft_pe_launch && pe_fire[p] && (slot_upstream[p] == DIR_MEM))
          mem_operand_valid_q[p] <= 1'b0;
        if ((p == 0) && cordic_req_valid && cordic_req_ready &&
            !cordic_mode_twiddle && (cordic_src_sel == 2'd0))
          mem_operand_valid_q[p] <= 1'b0;

        if (smu_pe_rsp_valid[p] &&
            !smu_pe_rsp_err[p] && !smu_pe_rsp_kind[p] &&
            (smu_pe_rsp_tag[p] != 4'hE)) begin
          mem_operand_valid_q[p] <= 1'b1;
          mem_operand_data_q[p] <= smu_pe_rsp_data[p];
        end
      end
    end
  end

  assign smu_pe_rsp_valid_o = smu_pe_rsp_valid;
  assign smu_pe_rsp_kind_o = smu_pe_rsp_kind;
  assign smu_pe_rsp_err_o = smu_pe_rsp_err;
  assign smu_pe_rsp_data_o = smu_pe_rsp_data;
  assign smu_pe_rsp_tag_o = smu_pe_rsp_tag;

  // --------------------------------------------------------------------------
  // Local SRAM / WBQ / NoC scheduler
  // --------------------------------------------------------------------------
  sv_smu_sched_top #(
    .NUM_PE(N_PE),
    .NUM_BANKS(4),
    .LOCAL_ADDR_W(LOCAL_ADDR_W),
    .LINE_ADDR_W(8),
    .GLOBAL_ADDR_W(GLOBAL_ADDR_W),
    .VECTOR_W(VECTOR_W),
    .PE_TAG_W(4),
    .WSTRB_W(4),
    .DMA_TAG_W(4),
    .DMA_CNT_W(8)
  ) u_smu (
    .clk(clk_i),
    .rst_n(rst_ni),
    .pe_req_valid(smu_pe_req_valid),
    .pe_req_ready(smu_pe_req_ready),
    .pe_req_type(smu_pe_req_type),
    .pe_req_is_vec(smu_pe_req_is_vec),
    .pe_req_addr(smu_pe_req_addr),
    .pe_req_data(smu_pe_req_data),
    .pe_req_wstrb(smu_pe_req_wstrb),
    .pe_req_tag(smu_pe_req_tag),
    .qr_preload_req_valid(qr_mem_req_valid),
    .qr_preload_req_ready(qr_mem_req_ready),
    .qr_preload_req_addr(qr_mem_req_addr),
    .qr_preload_rsp_valid(qr_mem_rsp_valid),
    .qr_preload_rsp_data(qr_mem_rsp_data),
    .dma_wb_valid(dma_wb_valid_i),
    .dma_wb_addr(dma_wb_addr_i),
    .dma_wb_data(dma_wb_data_i),
    .wbq_enq_valid(wbq_enq_valid_i),
    .wbq_enq_ready(wbq_enq_ready_o),
    .wbq_enq_bank_idx(wbq_enq_bank_idx_i),
    .wbq_enq_line_addr(wbq_enq_line_addr_i),
    .wbq_enq_data(wbq_enq_data_i),
    .wbq_enq_tag(wbq_enq_tag_i),
    .wbq_enq_completion_credit(wbq_enq_completion_credit_i),
    .dma_local_dst_active(dma_local_dst_active_i),
    .dma_local_dst_start(dma_local_dst_start_i),
    .dma_local_dst_end(dma_local_dst_end_i),
    .dma_issue_active(dma_issue_active_i),
    .dma_issue_error(dma_issue_error_i),
    .dma_issue_dst_base(dma_issue_dst_base_i),
    .dma_issue_tag_candidate(dma_issue_tag_candidate_i),
    .revb_noc_rx_valid(revb_noc_rx_valid_i),
    .revb_noc_rx_ready(revb_noc_rx_ready_o),
    .revb_noc_rx_opcode(revb_noc_rx_opcode_i),
    .revb_noc_rx_addr(revb_noc_rx_addr_i),
    .revb_noc_rx_data(revb_noc_rx_data_i),
    .revb_noc_rx_tag(revb_noc_rx_tag_i),
    .revb_noc_rx_requester(revb_noc_rx_requester_i),
    .revb_noc_rx_path(revb_noc_rx_path_i),
    .revb_noc_rx_read_req_valid(revb_noc_rx_read_req_valid_i),
    .revb_noc_rx_read_req_ready(revb_noc_rx_read_req_ready_o),
    .revb_noc_rx_read_req_addr(revb_noc_rx_read_req_addr_i),
    .revb_noc_rx_read_req_tag(revb_noc_rx_read_req_tag_i),
    .revb_noc_rx_read_req_requester(revb_noc_rx_read_req_requester_i),
    .revb_noc_rx_read_req_path(revb_noc_rx_read_req_path_i),
    .revb_noc_tx_read_rsp_valid(revb_noc_tx_read_rsp_valid_o),
    .revb_noc_tx_read_rsp_ready(revb_noc_tx_read_rsp_ready_i),
    .revb_noc_tx_read_rsp_opcode(revb_noc_tx_read_rsp_opcode_o),
    .revb_noc_tx_read_rsp_data(revb_noc_tx_read_rsp_data_o),
    .revb_noc_tx_read_rsp_tag(revb_noc_tx_read_rsp_tag_o),
    .revb_noc_tx_read_rsp_requester(revb_noc_tx_read_rsp_requester_o),
    .revb_noc_tx_read_rsp_path(revb_noc_tx_read_rsp_path_o),
    .remote_rd_enq_valid(remote_rd_enq_valid_i),
    .remote_rd_enq_ready(remote_rd_enq_ready_o),
    .remote_rd_enq_bank_idx(remote_rd_enq_bank_idx_i),
    .remote_rd_enq_line_addr(remote_rd_enq_line_addr_i),
    .remote_rd_enq_tag(remote_rd_enq_tag_i),
    .remote_rd_enq_requester(remote_rd_enq_requester_i),
    .remote_rd_enq_path(remote_rd_enq_path_i),
    .remote_rd_rsp_valid(remote_rd_rsp_valid_o),
    .remote_rd_rsp_ready(remote_rd_rsp_ready_i),
    .remote_rd_rsp_data(remote_rd_rsp_data_o),
    .remote_rd_rsp_tag(remote_rd_rsp_tag_o),
    .remote_rd_rsp_requester(remote_rd_rsp_requester_o),
    .remote_rd_rsp_path(remote_rd_rsp_path_o),
    .pe_rsp_valid(smu_pe_rsp_valid),
    .pe_rsp_kind(smu_pe_rsp_kind),
    .pe_rsp_err(smu_pe_rsp_err),
    .pe_rsp_data(smu_pe_rsp_data),
    .pe_rsp_tag(smu_pe_rsp_tag),
    .wbq_commit_valid(wbq_commit_valid),
    .wbq_commit_addr(wbq_commit_addr),
    .wbq_commit_data(wbq_commit_data)
  );

endmodule : single_cluster_integration_top
