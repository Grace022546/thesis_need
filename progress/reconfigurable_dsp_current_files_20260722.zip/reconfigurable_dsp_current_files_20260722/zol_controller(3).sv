`timescale 1ns/1ps
import cgra_rtl_pkg::*;

module zol_controller #(
  parameter int P_PC_W = PC_W,
  parameter int P_LOOP_COUNT = LOOP_COUNT
) (
  input  logic                  clk_i,
  input  logic                  rst_ni,

  input  logic                  cfg_valid_i,
  input  logic [3:0]            cfg_loop_id_i,
  input  logic [15:0]           cfg_iterations_i,
  input  logic [P_PC_W-1:0]     cfg_start_pc_i,
  input  logic [P_PC_W-1:0]     cfg_end_pc_i,
  input  logic [5:0]            cfg_flags_i,
  output logic                  cfg_error_o,

  input  logic                  retire_valid_i,
  input  logic [P_PC_W-1:0]     retire_pc_i,
  output logic                  redirect_valid_o,
  output logic [P_PC_W-1:0]     redirect_pc_o,

  input  logic                  barrier_clear_i,
  output logic [P_LOOP_COUNT-1:0] loop_active_o
);

  logic [P_LOOP_COUNT-1:0] configured_q, active_q;
  logic [15:0] iterations_q [P_LOOP_COUNT];
  logic [15:0] remaining_q  [P_LOOP_COUNT];
  logic [P_PC_W-1:0] start_pc_q [P_LOOP_COUNT];
  logic [P_PC_W-1:0] end_pc_q   [P_LOOP_COUNT];
  logic [5:0] flags_q [P_LOOP_COUNT];

  logic selected_valid;
  logic [$clog2(P_LOOP_COUNT)-1:0] selected_idx;
  logic [P_PC_W-1:0] selected_start;
  integer i;

  always_comb begin
    selected_valid = 1'b0;
    selected_idx = '0;
    selected_start = '0;
    // Match Python: among loops ending at this PC, choose the most deeply
    // nested loop, represented by the greatest start_pc.
    for (i = 0; i < P_LOOP_COUNT; i++) begin
      if (configured_q[i] && active_q[i] && (end_pc_q[i] == retire_pc_i)) begin
        if (!selected_valid || (start_pc_q[i] >= selected_start)) begin
          selected_valid = 1'b1;
          selected_idx = i[$clog2(P_LOOP_COUNT)-1:0];
          selected_start = start_pc_q[i];
        end
      end
    end
  end

  always_comb begin
    redirect_valid_o = retire_valid_i && selected_valid &&
                       (remaining_q[selected_idx] > 16'd1);
    redirect_pc_o = selected_start;
    cfg_error_o = cfg_valid_i &&
                  ((cfg_loop_id_i >= P_LOOP_COUNT) ||
                   (cfg_iterations_i == 16'd0) ||
                   (cfg_start_pc_i > cfg_end_pc_i));
    loop_active_o = active_q;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      configured_q <= '0;
      active_q <= '0;
      for (i = 0; i < P_LOOP_COUNT; i++) begin
        iterations_q[i] <= '0;
        remaining_q[i] <= '0;
        start_pc_q[i] <= '0;
        end_pc_q[i] <= '0;
        flags_q[i] <= '0;
      end
    end else begin
      if (barrier_clear_i) begin
        configured_q <= '0;
        active_q <= '0;
        for (i = 0; i < P_LOOP_COUNT; i++) begin
          remaining_q[i] <= '0;
        end
      end

      if (cfg_valid_i && !cfg_error_o) begin
        configured_q[cfg_loop_id_i] <= 1'b1;
        active_q[cfg_loop_id_i] <= 1'b1;
        iterations_q[cfg_loop_id_i] <= cfg_iterations_i;
        remaining_q[cfg_loop_id_i] <= cfg_iterations_i;
        start_pc_q[cfg_loop_id_i] <= cfg_start_pc_i;
        end_pc_q[cfg_loop_id_i] <= cfg_end_pc_i;
        flags_q[cfg_loop_id_i] <= cfg_flags_i;
      end

      if (retire_valid_i && selected_valid) begin
        if (remaining_q[selected_idx] > 16'd1) begin
          remaining_q[selected_idx] <= remaining_q[selected_idx] - 16'd1;
          // Reset nested child loops for the next outer iteration.
          for (i = 0; i < P_LOOP_COUNT; i++) begin
            if ((i != selected_idx) && configured_q[i] &&
                (start_pc_q[i] >= start_pc_q[selected_idx]) &&
                (end_pc_q[i] <= end_pc_q[selected_idx])) begin
              remaining_q[i] <= iterations_q[i];
              active_q[i] <= 1'b1;
            end
          end
        end else begin
          remaining_q[selected_idx] <= '0;
          active_q[selected_idx] <= 1'b0;
        end
      end
    end
  end

endmodule
