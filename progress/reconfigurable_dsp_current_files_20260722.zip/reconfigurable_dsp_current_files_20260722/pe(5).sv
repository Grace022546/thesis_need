`timescale 1ns/1ps
import context_entry_pkg::*;

// =============================================================================
// Non-pipelined eight-lane fixed-point processing element.
//
// Arithmetic contract matches cgra_v4_no_tsu_paramrf_pingpong_full(1).py:
//   PASS/NOP  1 cycle
//   MAC      12 cycles, signed Q2.30 products, two 40-bit accumulator contexts
//   CMUL     17 cycles, radix-2 complex butterfly with 1/2 stage scaling
//   ADD       3 cycles, lane reduction or raw-accumulator reduction
//   CROT     12 cycles, four Q1.15 Givens pairs
//   CVEC     reserved PE encoding; data pass-through only
//   RU_PACK   2-cycle compatibility pass-through (normally intercepted above PE)
//
// Only functional state is exposed. Model-only utilization and saturation
// telemetry is intentionally not synthesized.
// =============================================================================
module pe #(
  parameter int LANES = 8,
  parameter int DATA_W = 16,
  parameter int ACC_W = 40
) (
  input  logic                         clk,
  input  logic                         rst_n,
  input  logic                         fire,
  input  pe_op_e                       fire_op,
  input  logic signed [DATA_W-1:0]     fire_din [LANES],
  input  logic signed [DATA_W-1:0]     fire_tw  [LANES],
  input  logic signed [DATA_W-1:0]     fire_aux [LANES],
  input  logic [7:0]                   fire_extra_latency,
  input  logic                         fire_mac_acc_clear,
  input  logic                         fire_reduce_acc_raw,
  input  logic                         fire_acc_context,

  output logic                         busy,
  output logic                         done,
  output logic                         illegal_fire_while_busy,
  output logic [LANES*DATA_W-1:0]      reg_out_flat
);

  localparam logic signed [63:0] Q_MAX_C   = 64'sd32767;
  localparam logic signed [63:0] Q_MIN_C   = -64'sd32768;
  localparam logic signed [63:0] Q_ROUND_C = 64'sd16384;
  localparam logic signed [63:0] ACC_MAX_C = (64'sd1 <<< (ACC_W-1)) - 1;
  localparam logic signed [63:0] ACC_MIN_C = -(64'sd1 <<< (ACC_W-1));

  pe_op_e op_q;
  logic [8:0] cycles_left_q;
  logic mac_acc_clear_q;
  logic reduce_acc_raw_q;
  logic acc_context_q;

  logic signed [DATA_W-1:0] din_q [LANES];
  logic signed [DATA_W-1:0] tw_q  [LANES];
  logic signed [DATA_W-1:0] aux_q [LANES];
  logic signed [DATA_W-1:0] reg_q [LANES];
  logic signed [ACC_W-1:0]  acc_q [2][LANES];

  function automatic logic [8:0] operation_cycles(input pe_op_e op);
    case (op)
      OP_NOP, OP_PASS: operation_cycles = 9'd1;
      OP_MAC:          operation_cycles = 9'd12;
      OP_CMUL:         operation_cycles = 9'd17;
      OP_ADD:          operation_cycles = 9'd3;
      OP_CVEC:         operation_cycles = 9'd36;
      OP_CROT:         operation_cycles = 9'd12;
      OP_RU_PACK:      operation_cycles = 9'd2;
      default:         operation_cycles = 9'd1;
    endcase
  endfunction

  function automatic logic signed [DATA_W-1:0] sat_q15_f(
    input logic signed [63:0] value
  );
    if (value > Q_MAX_C)
      sat_q15_f = DATA_W'sd32767;
    else if (value < Q_MIN_C)
      sat_q15_f = $signed({1'b1, {(DATA_W-1){1'b0}}});
    else
      sat_q15_f = value[DATA_W-1:0];
  endfunction

  function automatic logic signed [ACC_W-1:0] sat_acc_f(
    input logic signed [63:0] value
  );
    if (value > ACC_MAX_C)
      sat_acc_f = ACC_MAX_C[ACC_W-1:0];
    else if (value < ACC_MIN_C)
      sat_acc_f = ACC_MIN_C[ACC_W-1:0];
    else
      sat_acc_f = value[ACC_W-1:0];
  endfunction

  function automatic logic signed [DATA_W-1:0] mul_q15_f(
    input logic signed [DATA_W-1:0] lhs,
    input logic signed [DATA_W-1:0] rhs
  );
    logic signed [31:0] product;
    logic signed [63:0] rounded;
    begin
      product = lhs * rhs;
      rounded = ($signed(product) + Q_ROUND_C) >>> 15;
      mul_q15_f = sat_q15_f(rounded);
    end
  endfunction

  function automatic logic signed [DATA_W-1:0] add_sat_f(
    input logic signed [DATA_W-1:0] lhs,
    input logic signed [DATA_W-1:0] rhs
  );
    add_sat_f = sat_q15_f($signed(lhs) + $signed(rhs));
  endfunction

  function automatic logic signed [DATA_W-1:0] sub_sat_f(
    input logic signed [DATA_W-1:0] lhs,
    input logic signed [DATA_W-1:0] rhs
  );
    sub_sat_f = sat_q15_f($signed(lhs) - $signed(rhs));
  endfunction

  function automatic logic signed [DATA_W-1:0] round_div2_sat_f(
    input logic signed [31:0] value
  );
    logic signed [31:0] rounded;
    begin
      if (value >= 0)
        rounded = (value + 32'sd1) >>> 1;
      else
        rounded = -(((-value) + 32'sd1) >>> 1);
      round_div2_sat_f = sat_q15_f(rounded);
    end
  endfunction

  function automatic logic signed [DATA_W-1:0] round_acc_to_q15_f(
    input logic signed [ACC_W-1:0] value
  );
    logic signed [63:0] extended;
    begin
      extended = {{(64-ACC_W){value[ACC_W-1]}}, value};
      round_acc_to_q15_f = sat_q15_f((extended + Q_ROUND_C) >>> 15);
    end
  endfunction

  assign illegal_fire_while_busy = fire && busy;

  genvar pack_lane;
  generate
    for (pack_lane = 0; pack_lane < LANES; pack_lane++) begin : g_pack_output
      assign reg_out_flat[pack_lane*DATA_W +: DATA_W] = reg_q[pack_lane];
    end
  endgenerate

  integer lane;
  always_ff @(posedge clk or negedge rst_n) begin : p_pe
    logic signed [63:0] raw64;
    logic signed [ACC_W-1:0] next_acc;
    logic signed [DATA_W-1:0] mr, mi;
    logic signed [DATA_W-1:0] p0, p1, p2, p3;
    logic signed [31:0] y0r_raw, y0i_raw, y1r_raw, y1i_raw;
    logic signed [63:0] total_raw;

    if (!rst_n) begin
      busy <= 1'b0;
      done <= 1'b0;
      op_q <= OP_NOP;
      cycles_left_q <= '0;
      mac_acc_clear_q <= 1'b0;
      reduce_acc_raw_q <= 1'b0;
      acc_context_q <= 1'b0;
      for (lane = 0; lane < LANES; lane++) begin
        din_q[lane] <= '0;
        tw_q[lane] <= '0;
        aux_q[lane] <= '0;
        reg_q[lane] <= '0;
        acc_q[0][lane] <= '0;
        acc_q[1][lane] <= '0;
      end
    end else begin
      done <= 1'b0;

      if (fire && !busy) begin
        busy <= 1'b1;
        op_q <= fire_op;
        cycles_left_q <= operation_cycles(fire_op) + {1'b0, fire_extra_latency};
        mac_acc_clear_q <= fire_mac_acc_clear;
        reduce_acc_raw_q <= fire_reduce_acc_raw;
        acc_context_q <= fire_acc_context;
        for (lane = 0; lane < LANES; lane++) begin
          din_q[lane] <= fire_din[lane];
          tw_q[lane] <= fire_tw[lane];
          aux_q[lane] <= fire_aux[lane];
        end
      end else if (busy) begin
        if (cycles_left_q > 9'd1) begin
          cycles_left_q <= cycles_left_q - 9'd1;
        end else begin
          busy <= 1'b0;
          done <= 1'b1;
          cycles_left_q <= '0;

          case (op_q)
            OP_NOP, OP_PASS, OP_CVEC, OP_RU_PACK: begin
              for (lane = 0; lane < LANES; lane++)
                reg_q[lane] <= din_q[lane];
            end

            OP_MAC: begin
              for (lane = 0; lane < LANES; lane++) begin
                raw64 = mac_acc_clear_q ? 64'sd0
                                        : {{(64-ACC_W){acc_q[acc_context_q][lane][ACC_W-1]}},
                                           acc_q[acc_context_q][lane]};
                raw64 = raw64 + $signed(din_q[lane]) * $signed(tw_q[lane]);
                next_acc = sat_acc_f(raw64);
                acc_q[acc_context_q][lane] <= next_acc;
                reg_q[lane] <= round_acc_to_q15_f(next_acc);
              end
            end

            OP_CMUL: begin
              mr = sub_sat_f(mul_q15_f(aux_q[0], tw_q[0]),
                             mul_q15_f(aux_q[1], tw_q[1]));
              mi = add_sat_f(mul_q15_f(aux_q[0], tw_q[1]),
                             mul_q15_f(aux_q[1], tw_q[0]));
              y0r_raw = $signed(din_q[0]) + $signed(mr);
              y0i_raw = $signed(din_q[1]) + $signed(mi);
              y1r_raw = $signed(din_q[0]) - $signed(mr);
              y1i_raw = $signed(din_q[1]) - $signed(mi);
              reg_q[0] <= round_div2_sat_f(y0r_raw);
              reg_q[1] <= round_div2_sat_f(y0i_raw);
              reg_q[2] <= round_div2_sat_f(y1r_raw);
              reg_q[3] <= round_div2_sat_f(y1i_raw);
              for (lane = 4; lane < LANES; lane++)
                reg_q[lane] <= '0;
            end

            OP_ADD: begin
              for (lane = 0; lane < LANES; lane++)
                reg_q[lane] <= '0;
              if (reduce_acc_raw_q) begin
                total_raw = 64'sd0;
                for (lane = 0; lane < LANES; lane++)
                  total_raw = total_raw +
                    {{(64-ACC_W){acc_q[acc_context_q][lane][ACC_W-1]}},
                     acc_q[acc_context_q][lane]};
                next_acc = sat_acc_f(total_raw);
                reg_q[0] <= round_acc_to_q15_f(next_acc);
              end else begin
                p0 = '0;
                for (lane = 0; lane < LANES; lane++)
                  p0 = add_sat_f(p0, din_q[lane]);
                reg_q[0] <= p0;
              end
            end

            OP_CROT: begin
              for (lane = 0; lane < LANES; lane = lane + 2) begin
                if ((tw_q[0] == DATA_W'sd32767) && (tw_q[1] == DATA_W'sd0)) begin
                  reg_q[lane]   <= din_q[lane];
                  reg_q[lane+1] <= din_q[lane+1];
                end else begin
                  p0 = mul_q15_f(tw_q[0], din_q[lane]);
                  p1 = mul_q15_f(tw_q[1], din_q[lane+1]);
                  p2 = mul_q15_f(tw_q[0], din_q[lane+1]);
                  p3 = mul_q15_f(tw_q[1], din_q[lane]);
                  reg_q[lane]   <= sat_q15_f($signed(p0) + $signed(p1));
                  reg_q[lane+1] <= sat_q15_f($signed(p2) - $signed(p3));
                end
              end
            end

            default: begin
              for (lane = 0; lane < LANES; lane++)
                reg_q[lane] <= din_q[lane];
            end
          endcase
        end
      end
    end
  end

endmodule : pe
