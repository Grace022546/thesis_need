`timescale 1ns/1ps
import cgra_rtl_pkg::*;

module qr_pivot_preload #(
  parameter int P_VECTOR_W = VECTOR_W,
  parameter int P_ADDR_W = LOCAL_ADDR_W
) (
  input  logic clk_i,
  input  logic rst_ni,

  input  logic                 start_valid_i,
  output logic                 start_ready_o,
  input  logic [QR_ROT_W-1:0]  rotation_id_i,
  input  logic [QR_ROW_W-1:0]  pivot_row_i,

  // Shared SRAM Port-A request.  The arbiter may accept a conflict-free QR
  // read while DMA is active on another bank.
  output logic                 mem_req_valid_o,
  input  logic                 mem_req_ready_i,
  output logic                 mem_req_write_o,
  output logic [P_ADDR_W-1:0]  mem_req_addr_o,
  input  logic                 mem_rsp_valid_i,
  input  logic [P_VECTOR_W-1:0] mem_rsp_data_i,

  output logic                 preload_busy_o,
  output logic                 preload_valid_o,
  output logic [QR_ROT_W-1:0]  preload_rotation_id_o,

  // Target [R | Q^T] landing buffer.  These four vectors are captured only
  // from accepted SRAM/WBQ commit events in the integration wrapper.
  input  logic [3:0]           target_valid_i,
  input  logic [P_VECTOR_W-1:0] target_r_vec0_i,
  input  logic [P_VECTOR_W-1:0] target_r_vec1_i,
  input  logic [P_VECTOR_W-1:0] target_qt_vec0_i,
  input  logic [P_VECTOR_W-1:0] target_qt_vec1_i,

  // QR CORDIC consumes the pivot/target R scalars at the elimination column.
  input  logic                 cordic_pair_req_i,
  input  logic [QR_ROT_W-1:0]  cordic_rotation_id_i,
  input  logic [QR_ROW_W-1:0]  cordic_column_i,
  output logic                 cordic_pair_valid_o,
  output logic signed [LANE_W-1:0] cordic_pivot_o,
  output logic signed [LANE_W-1:0] cordic_target_o,

  // One registered fixed-permutation stage.  Each PE receives four
  // {pivot,target} scalar pairs packed into eight lanes.
  input  logic                 interleave_valid_i,
  output logic                 interleave_ready_o,
  input  logic                 interleave_entity_qt_i,
  output logic                 pe_pairs_valid_o,
  input  logic                 pe_pairs_ready_i,
  output logic [N_PE*P_VECTOR_W-1:0] pe_pairs_o
);

  typedef enum logic [1:0] {PL_IDLE, PL_REQ, PL_WAIT_RSP, PL_DONE} pl_state_e;
  pl_state_e state_q;
  logic [2:0] op_idx_q;
  logic [QR_ROT_W-1:0] rotation_id_q;
  logic [QR_ROW_W-1:0] pivot_row_q;
  logic [P_VECTOR_W-1:0] cache_q [4]; // R0,R1,QT0,QT1
  logic [P_ADDR_W-1:0] op_addr;
  logic [QR_ROW_W+2:0] row_offset_vec;

  logic [N_PE*P_VECTOR_W-1:0] interleave_next;
  logic [P_VECTOR_W-1:0] pivot_sel0, pivot_sel1;
  logic [P_VECTOR_W-1:0] target_sel0, target_sel1;
  logic [2*P_VECTOR_W-1:0] pivot_row_flat, target_row_flat;
  logic target_entity_valid;
  logic cordic_vec_idx;
  logic [2:0] cordic_lane_idx;
  logic [P_VECTOR_W-1:0] cordic_pivot_vec;
  logic [P_VECTOR_W-1:0] cordic_target_vec;
  integer pe, pair_idx, col;

  always_comb begin
    // Latest mapping assigns every logical QR16 row a unique local slot:
    // local_base(row, kind) = kind_base + row * 8 vectors.  Rows may migrate
    // between clusters, so deriving the address from owner-local row/8 would
    // alias rows 0..7 and 8..15 and is not legal for the current compiler.
    row_offset_vec = {pivot_row_q, 3'b000};
    case (op_idx_q)
      3'd0: op_addr = P_ADDR_W'((QR_R_BASE_VEC + row_offset_vec + 0) * VECTOR_BYTES);
      3'd1: op_addr = P_ADDR_W'((QR_R_BASE_VEC + row_offset_vec + 1) * VECTOR_BYTES);
      3'd2: op_addr = P_ADDR_W'((QR_QT_BASE_VEC + row_offset_vec + 0) * VECTOR_BYTES);
      default: op_addr = P_ADDR_W'((QR_QT_BASE_VEC + row_offset_vec + 1) * VECTOR_BYTES);
    endcase

    start_ready_o = (state_q == PL_IDLE) || (state_q == PL_DONE);
    mem_req_valid_o = (state_q == PL_REQ);
    mem_req_write_o = 1'b0;
    mem_req_addr_o = op_addr;
    preload_busy_o = (state_q == PL_REQ) || (state_q == PL_WAIT_RSP);
    preload_valid_o = (state_q == PL_DONE);
    preload_rotation_id_o = rotation_id_q;

    target_entity_valid = interleave_entity_qt_i ?
                          (&target_valid_i[3:2]) : (&target_valid_i[1:0]);
    interleave_ready_o = preload_valid_o && target_entity_valid &&
                         !pe_pairs_valid_o;
    pivot_sel0 = interleave_entity_qt_i ? cache_q[2] : cache_q[0];
    pivot_sel1 = interleave_entity_qt_i ? cache_q[3] : cache_q[1];
    target_sel0 = interleave_entity_qt_i ? target_qt_vec0_i : target_r_vec0_i;
    target_sel1 = interleave_entity_qt_i ? target_qt_vec1_i : target_r_vec1_i;
    pivot_row_flat = {pivot_sel1, pivot_sel0};
    target_row_flat = {target_sel1, target_sel0};

    cordic_vec_idx = cordic_column_i[3];
    cordic_lane_idx = cordic_column_i[2:0];
    cordic_pair_valid_o = cordic_pair_req_i && preload_valid_o &&
                          (rotation_id_q == cordic_rotation_id_i) &&
                          target_valid_i[cordic_vec_idx];
    cordic_pivot_vec = cordic_vec_idx ? cache_q[1] : cache_q[0];
    cordic_target_vec = cordic_vec_idx ? target_r_vec1_i : target_r_vec0_i;
    cordic_pivot_o = $signed(cordic_pivot_vec
                             [cordic_lane_idx*LANE_W +: LANE_W]);
    cordic_target_o = $signed(cordic_target_vec
                              [cordic_lane_idx*LANE_W +: LANE_W]);
    interleave_next = '0;
    for (pe = 0; pe < N_PE; pe++) begin
      for (pair_idx = 0; pair_idx < 4; pair_idx++) begin
        col = pe * 4 + pair_idx;
        interleave_next[pe*P_VECTOR_W + (2*pair_idx)*LANE_W +: LANE_W] =
            pivot_row_flat[col*LANE_W +: LANE_W];
        interleave_next[pe*P_VECTOR_W + (2*pair_idx+1)*LANE_W +: LANE_W] =
            target_row_flat[col*LANE_W +: LANE_W];
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q <= PL_IDLE;
      op_idx_q <= '0;
      rotation_id_q <= '0;
      pivot_row_q <= '0;
      for (pe = 0; pe < 4; pe++) cache_q[pe] <= '0;
      pe_pairs_valid_o <= 1'b0;
      pe_pairs_o <= '0;
    end else begin
      if (pe_pairs_valid_o && pe_pairs_ready_i) begin
        pe_pairs_valid_o <= 1'b0;
      end
      if (interleave_valid_i && interleave_ready_o) begin
        // Exactly one registered interleave stage.
        pe_pairs_o <= interleave_next;
        pe_pairs_valid_o <= 1'b1;
      end

      case (state_q)
        PL_IDLE, PL_DONE: begin
          if (start_valid_i && start_ready_o) begin
            rotation_id_q <= rotation_id_i;
            pivot_row_q <= pivot_row_i;
            op_idx_q <= 3'd0;
            state_q <= PL_REQ;
          end
        end
        PL_REQ: begin
          if (mem_req_ready_i) begin
            state_q <= PL_WAIT_RSP;
          end else begin
          end
        end
        PL_WAIT_RSP: begin
          if (mem_rsp_valid_i) begin
            cache_q[op_idx_q] <= mem_rsp_data_i;
            if (op_idx_q == 3'd3) begin
              state_q <= PL_DONE;
            end else begin
              op_idx_q <= op_idx_q + 3'd1;
              state_q <= PL_REQ;
            end
          end
        end
        default: state_q <= PL_IDLE;
      endcase
    end
  end

endmodule
