`timescale 1ns/1ps
import cgra_rtl_pkg::*;

// Area-optimized cluster-local registered all-to-all interconnect.
//
// The architectural payload remains 256 bits, but each lane carries signed
// Q1.15 data in a 32-bit container.  Source skid and destination FIFO storage
// therefore retain only P_VALUE_W significant bits/lane and sign-extend on the
// output.  FIFO depth defaults to one; simultaneous pop/push is supported, so
// depth=1 does not introduce a throughput bubble.
module pe_local_interconnect #(
  parameter int P_N_PE = N_PE,
  parameter int P_VECTOR_W = VECTOR_W,
  parameter int P_FIFO_DEPTH = 1,
  parameter int P_VALUE_W = LOCAL_XBAR_VALUE_W
) (
  input  logic clk_i,
  input  logic rst_ni,

  // Sources 0..3 are PE results; source 4 is the local CORDIC broadcast.
  input  logic [P_N_PE:0]                        src_valid_i,
  output logic [P_N_PE:0]                        src_ready_o,
  input  logic [(P_N_PE+1)*P_VECTOR_W-1:0]       src_data_i,
  input  logic [(P_N_PE+1)*PARAM_ID_W-1:0]       src_pid_i,
  input  logic [(P_N_PE+1)*P_N_PE-1:0]           src_dst_mask_i,

  // dst_valid_o is PID-qualified: a consumer sees valid only when the FIFO
  // head belongs to the currently issued parameter/context ID.
  output logic [P_N_PE-1:0]                      dst_valid_o,
  input  logic [P_N_PE-1:0]                      dst_pop_i,
  input  logic [P_N_PE*PARAM_ID_W-1:0]           dst_expected_pid_i,
  output logic [P_N_PE*P_VECTOR_W-1:0]           dst_data_o,
  output logic                                    empty_o
);

  localparam int P_SOURCES = P_N_PE + 1;
  localparam int P_COMPACT_W = LANES * P_VALUE_W;
  localparam int FIFO_PTR_W = (P_FIFO_DEPTH <= 1) ? 1 : $clog2(P_FIFO_DEPTH);
  localparam int FIFO_CNT_W = $clog2(P_FIFO_DEPTH + 1);
  localparam int SOURCE_W = (P_SOURCES <= 2) ? 1 : $clog2(P_SOURCES);

  logic [P_COMPACT_W-1:0] skid_data_q [P_SOURCES];
  logic [PARAM_ID_W-1:0] skid_pid_q [P_SOURCES];
  logic [P_N_PE-1:0] skid_mask_q [P_SOURCES];
  logic [P_SOURCES-1:0] skid_valid_q;

  logic [P_COMPACT_W-1:0] fifo_data_q [P_N_PE][P_FIFO_DEPTH];
  logic [PARAM_ID_W-1:0] fifo_pid_q [P_N_PE][P_FIFO_DEPTH];
  logic [FIFO_PTR_W-1:0] rd_ptr_q [P_N_PE];
  logic [FIFO_PTR_W-1:0] wr_ptr_q [P_N_PE];
  logic [FIFO_CNT_W-1:0] count_q [P_N_PE];

  logic [P_SOURCES-1:0] source_accept;
  logic [P_SOURCES-1:0][P_N_PE-1:0] delivered_mask;
  logic [P_N_PE-1:0] push_valid;
  logic [SOURCE_W-1:0] push_source [P_N_PE];
  logic [P_N_PE-1:0] pop_fire;
  logic [P_N_PE-1:0] has_capacity;
  logic [P_N_PE-1:0] dst_present;
  logic [P_N_PE-1:0] head_pid_match;

  integer s, d;
  logic found;
  logic [PARAM_ID_W-1:0] expected_pid;

  function automatic logic [P_COMPACT_W-1:0] compact_vector(
      input logic [P_VECTOR_W-1:0] vector_i
  );
    logic [P_COMPACT_W-1:0] packed;
    integer l;
    begin
      packed = '0;
      for (l = 0; l < LANES; l = l + 1)
        packed[l*P_VALUE_W +: P_VALUE_W] =
            vector_i[l*LANE_W +: P_VALUE_W];
      compact_vector = packed;
    end
  endfunction

  function automatic logic [P_VECTOR_W-1:0] expand_vector(
      input logic [P_COMPACT_W-1:0] packed_i
  );
    logic [P_VECTOR_W-1:0] vector;
    logic signed [P_VALUE_W-1:0] value;
    integer l;
    begin
      vector = '0;
      for (l = 0; l < LANES; l = l + 1) begin
        value = packed_i[l*P_VALUE_W +: P_VALUE_W];
        vector[l*LANE_W +: LANE_W] = $signed(value);
      end
      expand_vector = vector;
    end
  endfunction

  always_comb begin
    for (s = 0; s < P_SOURCES; s = s + 1) begin
      src_ready_o[s] = !skid_valid_q[s];
      source_accept[s] = src_valid_i[s] && src_ready_o[s];
      delivered_mask[s] = '0;
    end

    // Observe current FIFO heads and determine same-cycle pops first.  A pop
    // frees capacity for a replacement push in the same cycle.
    for (d = 0; d < P_N_PE; d = d + 1) begin
      dst_present[d] = (count_q[d] != 0);
      dst_data_o[d*P_VECTOR_W +: P_VECTOR_W] =
          expand_vector(fifo_data_q[d][rd_ptr_q[d]]);
      expected_pid = dst_expected_pid_i[d*PARAM_ID_W +: PARAM_ID_W];
      head_pid_match[d] = dst_present[d] &&
                          (fifo_pid_q[d][rd_ptr_q[d]] == expected_pid);
      dst_valid_o[d] = head_pid_match[d];
      pop_fire[d] = dst_pop_i[d] && dst_valid_o[d];
      has_capacity[d] = (count_q[d] < P_FIFO_DEPTH) || pop_fire[d];
    end

    push_valid = '0;
    for (d = 0; d < P_N_PE; d = d + 1) begin
      found = 1'b0;
      push_source[d] = '0;
      // Deterministic arbitration: local CORDIC first, then PE0..PE3.
      if (skid_valid_q[P_N_PE] && skid_mask_q[P_N_PE][d] &&
          has_capacity[d]) begin
        found = 1'b1;
        push_source[d] = SOURCE_W'(P_N_PE);
      end
      for (s = 0; s < P_N_PE; s = s + 1) begin
        if (!found && skid_valid_q[s] && skid_mask_q[s][d] &&
            has_capacity[d]) begin
          found = 1'b1;
          push_source[d] = SOURCE_W'(s);
        end
      end
      push_valid[d] = found;
      if (found)
        delivered_mask[push_source[d]][d] = 1'b1;
    end

    empty_o = (skid_valid_q == '0);
    for (d = 0; d < P_N_PE; d = d + 1)
      empty_o &= (count_q[d] == 0);
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      // Payload arrays intentionally do not reset.  skid_valid_q and count_q
      // are the architectural validity state and prevent stale observation.
      skid_valid_q <= '0;
      for (d = 0; d < P_N_PE; d = d + 1) begin
        rd_ptr_q[d] <= '0;
        wr_ptr_q[d] <= '0;
        count_q[d] <= '0;
      end
    end else begin
      // Capture into one registered source skid slot.
      for (s = 0; s < P_SOURCES; s = s + 1) begin
        if (source_accept[s]) begin
          skid_valid_q[s] <= 1'b1;
          skid_data_q[s] <= compact_vector(
              src_data_i[s*P_VECTOR_W +: P_VECTOR_W]);
          skid_pid_q[s] <= src_pid_i[s*PARAM_ID_W +: PARAM_ID_W];
          skid_mask_q[s] <= src_dst_mask_i[s*P_N_PE +: P_N_PE];
        end
      end

      // A source remains in its skid register until every requested
      // destination has accepted the packet.
      for (s = 0; s < P_SOURCES; s = s + 1) begin
        if (skid_valid_q[s]) begin
          skid_mask_q[s] <= skid_mask_q[s] & ~delivered_mask[s];
          if ((skid_mask_q[s] & ~delivered_mask[s]) == '0)
            skid_valid_q[s] <= 1'b0;
        end
      end

      for (d = 0; d < P_N_PE; d = d + 1) begin
        case ({push_valid[d], pop_fire[d]})
          2'b10: begin
            fifo_data_q[d][wr_ptr_q[d]] <= skid_data_q[push_source[d]];
            fifo_pid_q[d][wr_ptr_q[d]] <= skid_pid_q[push_source[d]];
            wr_ptr_q[d] <= (wr_ptr_q[d] == P_FIFO_DEPTH-1) ?
                           '0 : wr_ptr_q[d] + 1'b1;
            count_q[d] <= count_q[d] + 1'b1;
          end
          2'b01: begin
            rd_ptr_q[d] <= (rd_ptr_q[d] == P_FIFO_DEPTH-1) ?
                           '0 : rd_ptr_q[d] + 1'b1;
            count_q[d] <= count_q[d] - 1'b1;
          end
          2'b11: begin
            fifo_data_q[d][wr_ptr_q[d]] <= skid_data_q[push_source[d]];
            fifo_pid_q[d][wr_ptr_q[d]] <= skid_pid_q[push_source[d]];
            wr_ptr_q[d] <= (wr_ptr_q[d] == P_FIFO_DEPTH-1) ?
                           '0 : wr_ptr_q[d] + 1'b1;
            rd_ptr_q[d] <= (rd_ptr_q[d] == P_FIFO_DEPTH-1) ?
                           '0 : rd_ptr_q[d] + 1'b1;
          end
          default: begin end
        endcase
      end
    end
  end
endmodule : pe_local_interconnect
