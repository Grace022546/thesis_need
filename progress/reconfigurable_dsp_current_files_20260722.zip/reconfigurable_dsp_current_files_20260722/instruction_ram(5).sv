// =============================================================================
// instruction_ram.sv
// Per-cluster autonomous instruction RAM using the compiled TSMC 16FFC SRAM.
//
// Physical macro:
//   TS1N16FFCLLULVTA2048X64M4SWBSHO
//   2048 words x 64 bits, single port, synchronous read
//
// Integration rules:
//   1. For Design Compiler, do NOT analyze the SRAM functional .v model.
//      The macro is resolved from INSTR_SRAM_DB through link_library.
//   2. For RTL simulation, compile the SRAM functional .v model together with
//      this wrapper.
//   3. The physical macro is single-port. Programming writes have priority over
//      instruction fetches if wr_en and rd_en are asserted in the same cycle.
// =============================================================================

import cgra_rtl_pkg::*;

module instruction_ram (
  input  logic                              clk_i,
  input  logic                              rst_ni,

  input  logic                              wr_en,
  input  logic [PC_W-1:0]                   wr_addr,
  input  logic [63:0]                       wr_data,

  input  logic                              rd_en,
  input  logic [PC_W-1:0]                   rd_addr,
  output logic [63:0]                       rd_data,
  output logic                              rd_valid
);

  localparam int unsigned SRAM_DEPTH = 2048;
  localparam int unsigned SRAM_WIDTH = 64;
  localparam int unsigned SRAM_AW    = 11;

`ifndef SYNTHESIS
  initial begin
    if (IMEM_DEPTH != SRAM_DEPTH) begin
      $fatal(1,
        "instruction_ram: IMEM_DEPTH must be %0d, got %0d",
        SRAM_DEPTH, IMEM_DEPTH);
    end

    if (PC_W != SRAM_AW) begin
      $fatal(1,
        "instruction_ram: PC_W must be %0d, got %0d",
        SRAM_AW, PC_W);
    end
  end
`endif

  logic                   sram_access;
  logic                   sram_write;
  logic [SRAM_AW-1:0]     sram_addr;
  logic [SRAM_WIDTH-1:0]  sram_q;
  logic                   pudelay_unused;

  assign sram_write  = wr_en;
  assign sram_access = sram_write || rd_en;
  assign sram_addr   = sram_write ? wr_addr : rd_addr;

  TS1N16FFCLLULVTA2048X64M4SWBSHO u_instruction_sram (
    .SLP      (1'b0),
    .DSLP     (1'b0),
    .SD       (1'b0),
    .PUDELAY  (pudelay_unused),

    .CLK      (clk_i),
    .CEB      (~sram_access),
    .WEB      (~sram_write),
    .A        (sram_addr),
    .D        (wr_data),
    .BWEB     ({SRAM_WIDTH{1'b0}}),
    .Q        (sram_q),

    .BIST     (1'b0),
    .CEBM     (1'b1),
    .WEBM     (1'b1),
    .AM       ({SRAM_AW{1'b0}}),
    .DM       ({SRAM_WIDTH{1'b0}}),
    .BWEBM    ({SRAM_WIDTH{1'b1}}),

    .RTSEL    (2'b00),
    .WTSEL    (2'b00)
  );

  assign rd_data = sram_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rd_valid <= 1'b0;
    end else begin
      rd_valid <= rd_en && !sram_write;
    end
  end

`ifndef SYNTHESIS
  always_ff @(posedge clk_i) begin
    if (rst_ni && wr_en && rd_en) begin
      $warning(
        "instruction_ram: simultaneous wr_en and rd_en; write has priority");
    end
  end
`endif

endmodule : instruction_ram
