#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""16-CORDIC / cluster-local PE all-to-all CGRA workload model (Givens, RTL-grounded latency).

Architecture:
  * 16 clusters in a 4x4 grid; 4 PEs/cluster with a cluster-local all-to-all crossbar.
  * 1 CORDIC/RU per cluster -> 16 total local CORDIC units.
  * Cross-cluster data movement uses the SMU-mediated memory highway / DMA path
    (folded-ring request + unidirectional column-BUS response).  No cross-cluster
    direct PE links.
  * QR is Givens-rotation based (the measured local-CORDIC wavefront baseline).
    Householder evaluation has been removed from this package.

Cross-cluster latency uses REAL numbers extracted from the classmate's
RTL-validated functional model (cgra_model_fin_v17_clean.cpp + sv_smu_v3_clean.sv):

  LAT-1D PE-to-PE replacement benchmark (single vector):
      producer store visible latency        ~3 cycles
      DMA + consumer load visible latency    13-14 cycles
      full SMU-mediated replacement latency  16 cycles (cross-column),
                                             17 cycles (same-column)
      legacy direct-PE reference            1-2 cycles (not used by final ISA)

  MAP-1A DMA streaming sweep (cross-cluster, vectors per DMA burst):
      len=1 -> 15cy, len=2 -> 16cy, len=4 -> 18cy, len=8 -> 22cy, len=16 -> 32cy
      least-squares fit:  cycles ~= 13.6 + 1.13 * len_vec
      => DMA setup ~14 cycles, streaming ~1.13 cycles/vector once pipelined.

KEY CORRECTION vs the earlier model:
  The old penalty charged "transfers x 14" -- i.e. it billed the one-time SETUP
  latency to EVERY vector.  The RTL shows per-vector streaming is only ~1.13
  cycles; 16 is the round-trip LATENCY of an isolated transfer, not a per-beat
  cost.  So cross-cluster cost is bounded by:
      streaming (throughput-bound) : setup + 1.13 * transfers   [transfers batched]
      isolated  (latency-bound)    : 16 * transfers             [every transfer alone]
  The truth lies between, depending on burst structure; both bounds are reported,
  Newer cgra_v3_givens_fixedpoint.py backend rows already include route-dependent
  DMA completion, beat-visible DMA commits, RU/WBQ latency, and layout assertions
  in headline cycles.  The wrapper therefore reports DMA reference estimates as
  telemetry only and does not add them again when the backend marks DMA latency
  as included.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


WORKSPACE = Path(__file__).resolve().parent
BACKEND_MODEL = WORKSPACE / "cgra_v3_givens_fixedpoint.py"
LOCAL_CORDIC_BASELINE_CSV = WORKSPACE / "baseline_cordic_utilization_all_workloads.csv"
DEFAULT_OUT_PREFIX = WORKSPACE / "cgra_16cordic_cluster_highway_results"

CROSS_CLUSTER_ROUTE_KEYS = ("ROW_HW", "COL_HW", "ROW_COL_HW")
LOCAL_ROUTE_KEY = "LOCAL_ONLY"


@dataclass(frozen=True)
class Architecture:
    name: str = "cgra_16cordic_4pe_cluster_memory_highway"
    n_clusters: int = 16
    grid_rows: int = 4
    grid_cols: int = 4
    pe_per_cluster: int = 4
    cordic_per_cluster: int = 1
    twiddle_service_cordic: int = 1
    twiddle_service_owner_cluster: int = 15
    twiddle_service_reuses_owner_local_cordic: bool = True
    twiddle_service_sram_kib: int = 4
    vector_lanes: int = 8
    lane_bits: int = 32
    local_sram_banks: int = 4
    local_sram_bank_kib: int = 2
    local_pe_interconnect: str = "4_pe_all_to_all_crossbar"
    cross_cluster_interconnect: str = "smu_memory_highway_folded_ring_plus_column_bus"
    pe_net_final_isa_enabled: bool = False
    legacy_pe_net_dse_only: bool = True
    cordic_scope: str = "local_cluster_ru"
    qr_algorithm: str = "givens_rotation"

    @property
    def total_pes(self) -> int:
        return self.n_clusters * self.pe_per_cluster

    @property
    def total_cordic(self) -> int:
        return self.n_clusters * self.cordic_per_cluster

    @property
    def total_cordic_including_services(self) -> int:
        # Cluster15's local CORDIC is mode-multiplexed as the FFT Twiddle
        # Service Unit. It returns to ordinary local-CORDIC mode for QR, so the
        # service path does not create a 17th physical unit.
        return self.total_cordic

    @property
    def vector_bits(self) -> int:
        return self.vector_lanes * self.lane_bits

    @property
    def local_all_to_all_directed_edges_per_cluster(self) -> int:
        return self.pe_per_cluster * (self.pe_per_cluster - 1)

    @property
    def nominal_peak_mac_ops_per_cycle(self) -> int:
        """Loose 1-MAC-per-lane-per-cycle reference ceiling = PEs x lanes.

        Backend Op.MAC actually takes multiple cycles, so sustained MAC rate is
        well below this; used only to flag throughputs exceeding the datapath.
        """
        return self.total_pes * self.vector_lanes

    def mapped_mac_peak_ops_per_cycle(self, mapped_clusters: int, mac_ii_cycles: int = 13) -> float:
        """Sustained scalar MAC/cycle for the current non-pipelined MAC model."""
        return (int(mapped_clusters) * self.pe_per_cluster * self.vector_lanes) / max(1, int(mac_ii_cycles))

    def to_dict(self) -> Dict[str, Any]:
        out = asdict(self)
        out.update(
            total_pes=self.total_pes,
            total_cordic=self.total_cordic,
            total_cordic_including_services=self.total_cordic_including_services,
            vector_bits=self.vector_bits,
            local_all_to_all_directed_edges_per_cluster=self.local_all_to_all_directed_edges_per_cluster,
            nominal_peak_mac_ops_per_cycle=self.nominal_peak_mac_ops_per_cycle,
        )
        return out


@dataclass(frozen=True)
class WorkloadSpec:
    fft_points: tuple[int, ...] = (8, 16, 32, 64, 128, 256, 512, 1024)
    mm_sizes: tuple[int, ...] = (8, 16, 32, 64)
    fir_taps: tuple[int, ...] = (8, 16, 32, 64, 128, 256)
    qr_sizes: tuple[int, ...] = (16,)


@dataclass(frozen=True)
class SmuDmaLatencyModel:
    """Cross-cluster latency, constants measured from the RTL functional model.

    Source: cgra_model_fin_v17_clean.cpp LAT-1D / MAP-1A benchmarks
            (SMU v1.4 RevB, folded-ring request + column-BUS response).
    """

    direct_pe_to_pe_latency_cycles: int = 2          # RTL: direct PE adjacent 1-2 cycles
    single_transfer_roundtrip_cycles: int = 16       # RTL LAT-1D cross-column full replacement
    dma_setup_cycles: int = 14                        # RTL MAP-1A cross-cluster intercept (~13.6)
    dma_per_beat_cycles: float = 1.13                 # RTL MAP-1A cross-cluster slope
    provenance: str = "cgra_model_fin_v17 LAT-1D / MAP-1A (folded-ring + column-BUS)"

    def streaming_command_cycles(self, len_vec: int) -> int:
        """RTL-derived latency for one DMA command carrying len_vec vectors."""
        if len_vec <= 0:
            return 0
        return int(round(self.dma_setup_cycles + self.dma_per_beat_cycles * int(len_vec)))

    def streaming_cycles_for_commands(self, lengths: Iterable[int]) -> int:
        """Throughput-bound latency summed over the actual emitted DMA commands."""
        return int(sum(self.streaming_command_cycles(int(length)) for length in lengths))

    def isolated_cycles_for_commands(self, lengths: Iterable[int]) -> int:
        """Latency-bound: every transfer a separate, non-overlapped round trip."""
        return int(sum(self.single_transfer_roundtrip_cycles * int(length) for length in lengths))

    def streaming_cycles_for_issue_groups(self, events: Iterable[Dict[str, Any]]) -> int:
        """Latency estimate with DMA commands issued in the same backend cycle overlapped."""
        groups: Dict[int, List[int]] = {}
        for ev in events:
            if str(ev.get("route", "")) not in CROSS_CLUSTER_ROUTE_KEYS:
                continue
            length = int(ev.get("len_vec", 0))
            if length <= 0:
                continue
            cyc = int(ev.get("issue_cycle", -1))
            groups.setdefault(cyc, []).append(self.streaming_command_cycles(length))
        if not groups or any(c < 0 for c in groups):
            return 0
        return int(sum(max(vals) for vals in groups.values()))

    def isolated_cycles_for_issue_groups(self, events: Iterable[Dict[str, Any]]) -> int:
        groups: Dict[int, List[int]] = {}
        for ev in events:
            if str(ev.get("route", "")) not in CROSS_CLUSTER_ROUTE_KEYS:
                continue
            length = int(ev.get("len_vec", 0))
            if length <= 0:
                continue
            cyc = int(ev.get("issue_cycle", -1))
            groups.setdefault(cyc, []).append(self.single_transfer_roundtrip_cycles * length)
        if not groups or any(c < 0 for c in groups):
            return 0
        return int(sum(max(vals) for vals in groups.values()))

    def to_dict(self) -> Dict[str, Any]:
        out = asdict(self)
        out["dma_stream_formula"] = f"{self.dma_setup_cycles} + {self.dma_per_beat_cycles:g} * len_vec"
        out["note"] = (
            "streaming = throughput-bound per emitted DMA command; isolated = latency-bound "
            "(each transfer alone). With cgra_v3_givens_fixedpoint.py, backend headline "
            "cycles already include route-dependent DMA completion and beat-visible commits, "
            "so wrapper DMA estimates are reference telemetry only."
        )
        return out


def load_module(path: Path, module_name: str) -> Any:
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load module from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def _coerce_value(value: str) -> Any:
    value = value.strip()
    if value == "":
        return ""
    try:
        if any(ch in value for ch in (".", "e", "E")):
            return float(value)
        return int(value)
    except ValueError:
        return value


def load_local_cordic_qr_baseline(path: Path) -> Dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Missing local-CORDIC baseline CSV: {path}")
    with path.open("r", newline="", encoding="utf-8") as fobj:
        rows = list(csv.DictReader(fobj))
    for row in rows:
        if row.get("workload") == "QR 16x16 wavefront":
            out = {key: _coerce_value(value) for key, value in row.items()}
            out["name"] = out.pop("workload")
            out["evidence"] = "measured_16_local_cordic_givens_wavefront_baseline"
            out["architecture_binding"] = "Givens QR; 1 local CORDIC/cluster; cross-cluster movement via SMU highway"
            out["cross_cluster_pe_network_used"] = False
            # Givens baseline CSV carries no per-route traffic (row/col util = 0),
            # so the cross-cluster transfer count is unavailable.  Surfaced, not faked.
            out["traffic_by_route"] = None
            return out
    raise RuntimeError(f"QR 16x16 wavefront row not found in {path}")


def cross_cluster_transfers_from_row(row: Dict[str, Any]) -> Optional[int]:
    tbr = row.get("traffic_by_route")
    if not isinstance(tbr, dict):
        return None
    return int(sum(int(tbr.get(k, 0)) for k in CROSS_CLUSTER_ROUTE_KEYS))


def cross_cluster_dma_lengths_from_row(row: Dict[str, Any]) -> Optional[List[int]]:
    events = row.get("traffic_events")
    if isinstance(events, list):
        lengths = [
            int(ev.get("len_vec", 0))
            for ev in events
            if isinstance(ev, dict)
            and str(ev.get("route", "")) in CROSS_CLUSTER_ROUTE_KEYS
            and int(ev.get("len_vec", 0)) > 0
        ]
        return lengths
    transfers = cross_cluster_transfers_from_row(row)
    if transfers is None:
        return None
    # Backward-compatible fallback for older backend rows without per-command
    # telemetry.  New backend rows should use traffic_events above.
    return [int(transfers)] if transfers > 0 else []


def cross_cluster_dma_issue_cycles_from_row(row: Dict[str, Any]) -> Optional[int]:
    events = row.get("traffic_events")
    if not isinstance(events, list):
        return None
    cycles = {
        int(ev.get("issue_cycle", -1))
        for ev in events
        if isinstance(ev, dict)
        and str(ev.get("route", "")) in CROSS_CLUSTER_ROUTE_KEYS
        and int(ev.get("len_vec", 0)) > 0
        and int(ev.get("issue_cycle", -1)) >= 0
    }
    return len(cycles)


def run_workloads(
    *,
    seed: int = 42,
    backend_model_path: Path = BACKEND_MODEL,
    baseline_csv_path: Path = LOCAL_CORDIC_BASELINE_CSV,
    spec: WorkloadSpec = WorkloadSpec(),
) -> List[Dict[str, Any]]:
    backend = load_module(backend_model_path, "cgra_v3_full_workload_backend")
    backend_file = str(Path(getattr(backend, "__file__", backend_model_path)).resolve())
    backend.np.random.seed(seed)

    results: List[Dict[str, Any]] = []
    for n_point in spec.fft_points:
        row = backend.run_fft(int(n_point))
        promote_math_evidence(row)
        row["backend_model_path"] = backend_file
        row["backend_model_name"] = Path(backend_file).name
        row["evidence"] = "executed_cgra_v3_givens_fixedpoint_backend"
        row["cross_cluster_pe_network_used"] = False
        results.append(row)
    for n in spec.mm_sizes:
        row = backend.run_mm(int(n))
        promote_math_evidence(row)
        row["backend_model_path"] = backend_file
        row["backend_model_name"] = Path(backend_file).name
        row["evidence"] = "executed_cgra_v3_givens_fixedpoint_backend"
        row["cross_cluster_pe_network_used"] = False
        results.append(row)
    for taps in spec.fir_taps:
        row = backend.run_fir(int(taps))
        promote_math_evidence(row)
        row["backend_model_path"] = backend_file
        row["backend_model_name"] = Path(backend_file).name
        row["evidence"] = "executed_cgra_v3_givens_fixedpoint_backend"
        row["cross_cluster_pe_network_used"] = False
        results.append(row)
    for n in spec.qr_sizes:
        if int(n) != 16:
            raise ValueError("Givens local-CORDIC QR runner is available for QR16 only")
        row = backend.run_qr(int(n), seed=seed)
        promote_math_evidence(row)
        row["backend_model_path"] = backend_file
        row["backend_model_name"] = Path(backend_file).name
        row["evidence"] = "executed_cgra_v3_givens_fixedpoint_qr16_backend"
        row["cross_cluster_pe_network_used"] = False
        results.append(row)
    return results


def promote_math_evidence(row: Dict[str, Any]) -> None:
    math_info = row.get("math")
    if not isinstance(math_info, dict):
        return
    for key in (
        "twiddle_datapath",
        "fft_param_load_events",
        "fft_twiddle_dma_events",
        "fft_twiddle_cordic_invocations",
        "fft_twiddle_cordic_iterations",
        "fft_twiddle_gen_cycles",
        "fft_twiddle_service_unit",
        "fft_twiddle_service_cordic_count",
        "fft_twiddle_service_sram_bytes",
        "fft_twiddle_service_sram_vectors",
        "fft_cluster_hidden_twiddle_cordic_lanes",
        "fft_param_load_vector_writes_full_8_lanes",
        "python_runtime_cos_sin_to_pe",
    ):
        if key in math_info:
            row[key] = math_info[key]


def annotate_cross_cluster_latency(
    results: List[Dict[str, Any]],
    dma: SmuDmaLatencyModel,
    arch: Architecture,
) -> List[Dict[str, Any]]:
    annotated: List[Dict[str, Any]] = []
    for row in results:
        out = dict(row)
        base = int(out.get("cycles", 0))
        out["base_cycles"] = base

        transfers = cross_cluster_transfers_from_row(out)
        dma_lengths = cross_cluster_dma_lengths_from_row(out)
        dma_commands = len(dma_lengths) if dma_lengths is not None else None
        dma_issue_cycles = cross_cluster_dma_issue_cycles_from_row(out)
        traffic_events = out.get("traffic_events") if isinstance(out.get("traffic_events"), list) else []
        out["cross_cluster_transfers"] = transfers
        out["cross_cluster_dma_commands"] = dma_commands
        out["cross_cluster_traffic_available"] = transfers is not None
        backend_dma_included = bool(out.get("dma_latency_included_in_cycles", False))

        if transfers is not None and dma_lengths is not None:
            stream_serialized = dma.streaming_cycles_for_commands(dma_lengths)
            iso_serialized = dma.isolated_cycles_for_commands(dma_lengths)
            stream_parallel = dma.streaming_cycles_for_issue_groups(traffic_events)
            iso_parallel = dma.isolated_cycles_for_issue_groups(traffic_events)
            stream_gross = stream_parallel or stream_serialized
            iso_gross = iso_parallel or iso_serialized
            if backend_dma_included:
                issue_tokens_already_counted = None
                stream_added = 0
                iso_added = 0
                overlap_model = "backend_includes_dma_completion_and_beat_visible_commits"
            else:
                issue_tokens_already_counted = int(dma_issue_cycles if stream_parallel else (dma_commands or 0))
                stream_added = max(0, stream_gross - issue_tokens_already_counted)
                iso_added = max(0, iso_gross - issue_tokens_already_counted)
                overlap_model = "issue_cycle_parallel_max_per_group" if stream_parallel else "serialized_fallback"
            out["dma_gross_cycles_streaming"] = stream_gross
            out["dma_gross_cycles_isolated"] = iso_gross
            out["dma_gross_cycles_streaming_serialized"] = stream_serialized
            out["dma_gross_cycles_isolated_serialized"] = iso_serialized
            out["dma_latency_overlap_model"] = overlap_model
            out["dma_issue_tokens_already_in_base"] = issue_tokens_already_counted
            out["backend_dma_latency_included_in_base"] = backend_dma_included
            out["cross_cluster_dma_issue_cycles"] = dma_issue_cycles
            out["dma_added_cycles_streaming"] = stream_added
            out["dma_added_cycles_isolated"] = iso_added
            out["adjusted_cycles_streaming"] = base + stream_added
            out["adjusted_cycles_isolated"] = base + iso_added
        else:
            out["cross_cluster_dma_commands"] = None
            out["cross_cluster_dma_issue_cycles"] = None
            out["dma_gross_cycles_streaming"] = None
            out["dma_gross_cycles_isolated"] = None
            out["dma_issue_tokens_already_in_base"] = None
            out["backend_dma_latency_included_in_base"] = backend_dma_included
            out["dma_added_cycles_streaming"] = None
            out["dma_added_cycles_isolated"] = None
            out["adjusted_cycles_streaming"] = None
            out["adjusted_cycles_isolated"] = None
            out["cross_cluster_note"] = (
                "No per-command traffic_events are available; rerun through the live "
                "backend to obtain DMA command lengths. RTL reference: each command "
                "stream is ~14 + 1.13*len_vec cycles."
            )

        # throughput-vs-peak surfacing
        tp = out.get("throughput", "")
        is_mm = str(out.get("name", "")).startswith("MM ")
        mac_ii = int(out.get("mac_initiation_interval_cycles", 13))
        peak = arch.mapped_mac_peak_ops_per_cycle(int(out.get("n_mapped", 0)), mac_ii) if is_mm else arch.nominal_peak_mac_ops_per_cycle
        out["nominal_peak_mac_ops_per_cycle"] = peak
        out["effective_peak_mac_ops_per_cycle"] = peak
        if isinstance(tp, (int, float)) and tp != "":
            out["throughput_vs_nominal_peak"] = float(tp) / peak if peak else None
            out["throughput_exceeds_datapath_peak"] = bool(float(tp) > peak)
        else:
            out["throughput_vs_nominal_peak"] = None
            out["throughput_exceeds_datapath_peak"] = False

        annotated.append(out)
    return annotated


def summarize_results(
    arch: Architecture,
    results: List[Dict[str, Any]],
    dma: SmuDmaLatencyModel,
) -> Dict[str, Any]:
    qr = next((r for r in results if str(r.get("name", "")).startswith("QR 16x16")), None)
    if qr is None:
        raise RuntimeError("QR16 result missing")
    if float(qr.get("mapped_cordic_util", 0.0)) <= 0.0:
        raise RuntimeError("QR16 result did not exercise local CORDIC units")
    used_direct_pe_net = [str(r.get("name", "")) for r in results if bool(r.get("cross_cluster_pe_network_used", False))]
    if used_direct_pe_net:
        raise RuntimeError(f"Workload(s) claim cross-cluster DIRECT PE network usage: {used_direct_pe_net}")

    peak_exceeders = [str(r.get("name", "")) for r in results if r.get("throughput_exceeds_datapath_peak")]
    no_traffic = [str(r.get("name", "")) for r in results if not r.get("cross_cluster_traffic_available", False)]
    backend_names = sorted({str(r.get("backend_model_name", "")) for r in results if r.get("backend_model_name")})
    backend_dma_included_all = all(bool(r.get("dma_latency_included_in_cycles", False)) for r in results)
    backend_pe_net_disabled_all = all(r.get("final_isa_pe_net_enabled") is False for r in results)
    backend_legacy_pe_net_excluded_all = all(bool(r.get("legacy_pe_net_dse_excluded_from_final_model", False)) for r in results)

    return {
        "architecture": arch.to_dict(),
        "smu_dma_latency_model": dma.to_dict(),
        "workload_count": len(results),
        "backend_model_names": backend_names,
        "backend_dma_latency_included_in_base": backend_dma_included_all,
        "total_base_cycles_sum": int(sum(int(r.get("base_cycles", r.get("cycles", 0))) for r in results)),
        "qr16_cycles": int(qr["cycles"]),
        "qr16_cross_cluster_traffic_available": bool(qr.get("cross_cluster_traffic_available", False)),
        "qr16_cordic_util": float(qr["mapped_cordic_util"]),
        "qr16_pe_util": float(qr["mapped_pe_util"]),
        "max_total_pe_util": max(float(r.get("total_pe_util", 0.0)) for r in results),
        "max_twiddle_service_util": max(float(r.get("twiddle_service_util", 0.0)) for r in results),
        "max_mapped_mem_events_per_cycle": max(float(r.get("mapped_mem_events_per_cycle", 0.0)) for r in results),
        "workloads_missing_cross_cluster_traffic": no_traffic,
        "workloads_throughput_exceeds_peak": peak_exceeders,
        "modeling_caveats": [
            "Headline cycles = backend cycles from cgra_v3_givens_fixedpoint.py when using the default backend. "
            "That backend includes route-dependent DMA completion, beat-visible DMA commits, RU/WBQ latency, "
            "fixed-width CORDIC, and layout assertions in the measured cycles.",
            "FFT twiddles are generated by cluster15's mode-multiplexed local CORDIC into a reserved 4KiB "
            "physical SRAM region, then transferred over the 256-bit memory highway to destination landing buffers "
            "before PARAM_LOAD_VECTOR; this is one of the 16 physical CORDICs, not a 17th unit.",
            "Cross-cluster data movement in the final model uses the SMU/DMA memory highway only; "
            "legacy PE_NET FIFO sizing is historical DSE and is excluded from final workload results.",
            "SMU/DMA latency constants are RTL-measured (LAT-1D / MAP-1A): isolated cross-cluster "
            "transfer ~16cy, DMA stream ~14 + 1.13*len_vec.",
            "Per workload, streaming and isolated DMA gross estimates are retained only as reference telemetry "
            "when backend_dma_latency_included_in_base is true; adjusted cycles equal base cycles to avoid "
            "double-counting DMA latency.",
            "QR16 is generated by the live Givens QR16 wavefront ISA runner, so "
            "traffic_by_route is in-band backend telemetry rather than a baseline CSV field.",
            "QR16 groups independent Givens rotations by i+j wavefront. Each wave has one compute phase and "
            "one writeback phase; temporal CORDIC/CROT overlap inside a cluster is not claimed unless the "
            "backend row explicitly reports it.",
            "Legacy row_contention/col_contention counters describe the deprecated packet-broadcast path and may remain zero. "
            "The final DMA path uses dma_noc_contention_cycles and per-resource reservation counters, which are included in cycles.",
            "MM uses output-stationary dot-product mapping: one PE owns one C[i,j], "
            "8 lanes cover K chunks, A is broadcast through the cluster operand buffer, "
            "B is read from each PE's own SRAM bank, and raw accumulators are reduced once.",
        ],
        "contract_checks": {
            "cluster_local_cordic_is_16": arch.total_cordic == 16,
            "twiddle_service_cordic_is_1": arch.twiddle_service_cordic == 1,
            "twiddle_service_owner_is_cluster15": arch.twiddle_service_owner_cluster == 15,
            "twiddle_service_reuses_owner_local_cordic": arch.twiddle_service_reuses_owner_local_cordic is True,
            "total_cordic_including_services_is_16": arch.total_cordic_including_services == 16,
            "pe_per_cluster_is_4": arch.pe_per_cluster == 4,
            "local_interconnect_is_4pe_all_to_all_crossbar": arch.local_pe_interconnect == "4_pe_all_to_all_crossbar",
            "pe_net_disabled_in_final_isa": arch.pe_net_final_isa_enabled is False,
            "legacy_pe_net_dse_only": arch.legacy_pe_net_dse_only is True,
            "backend_reports_pe_net_disabled_for_all_workloads": backend_pe_net_disabled_all,
            "backend_reports_legacy_pe_net_excluded_for_all_workloads": backend_legacy_pe_net_excluded_all,
            "cross_cluster_interconnect_is_smu_highway": "smu_memory_highway" in arch.cross_cluster_interconnect,
            "qr_is_givens": arch.qr_algorithm == "givens_rotation",
            "qr16_uses_local_cordic": float(qr.get("mapped_cordic_util", 0.0)) > 0.0,
            "no_cross_cluster_direct_pe_network_in_results": len(used_direct_pe_net) == 0,
            "dma_latency_constants_are_rtl_measured": True,
            "isolated_xfer_latency_is_16_cycles": dma.single_transfer_roundtrip_cycles == 16,
            "qr16_traffic_telemetry_present": bool(qr.get("cross_cluster_traffic_available", False)),
            "default_backend_is_givens_fixedpoint": backend_names == ["cgra_v3_givens_fixedpoint.py"],
            "backend_dma_latency_included_in_base": backend_dma_included_all,
        },
    }


def _fmt(v: Any) -> Any:
    return "" if v is None else v


def _flat_workload_row(row: Dict[str, Any]) -> Dict[str, Any]:
    math_info = row.get("math", {}) if isinstance(row.get("math"), dict) else {}
    tbr = row.get("traffic_by_route") if isinstance(row.get("traffic_by_route"), dict) else {}
    return {
        "workload": row.get("name", ""),
        "base_cycles": row.get("base_cycles", row.get("cycles", "")),
        "cross_cluster_transfers": _fmt(row.get("cross_cluster_transfers")),
        "cross_cluster_dma_commands": _fmt(row.get("cross_cluster_dma_commands")),
        "cross_cluster_dma_issue_cycles": _fmt(row.get("cross_cluster_dma_issue_cycles")),
        "dma_added_streaming": _fmt(row.get("dma_added_cycles_streaming")),
        "dma_added_isolated": _fmt(row.get("dma_added_cycles_isolated")),
        "dma_gross_streaming_serialized": _fmt(row.get("dma_gross_cycles_streaming_serialized")),
        "dma_gross_isolated_serialized": _fmt(row.get("dma_gross_cycles_isolated_serialized")),
        "dma_latency_overlap_model": row.get("dma_latency_overlap_model", ""),
        "backend_dma_latency_included": row.get("backend_dma_latency_included_in_base", row.get("dma_latency_included_in_cycles", "")),
        "adj_streaming": _fmt(row.get("adjusted_cycles_streaming")),
        "adj_isolated": _fmt(row.get("adjusted_cycles_isolated")),
        "cross_cluster_traffic_available": row.get("cross_cluster_traffic_available", False),
        "route_local_only": tbr.get(LOCAL_ROUTE_KEY, ""),
        "route_row_hw": tbr.get("ROW_HW", ""),
        "route_col_hw": tbr.get("COL_HW", ""),
        "route_row_col_hw": tbr.get("ROW_COL_HW", ""),
        "row_contention": row.get("row_contention", ""),
        "col_contention": row.get("col_contention", ""),
        "param_contention": row.get("param_contention", ""),
        "n_mapped": row.get("n_mapped", ""),
        "scheduled_macs": math_info.get("scheduled_lane_macs", ""),
        "full_matrix_macs": math_info.get("full_matrix_scalar_macs", ""),
        "schedule_coverage": math_info.get("schedule_coverage", ""),
        "scheduled_outputs": math_info.get("scheduled_outputs", ""),
        "expected_outputs": math_info.get("expected_outputs", ""),
        "output_coverage": math_info.get("output_coverage", ""),
        "datapath_nonzero_outputs": math_info.get("datapath_nonzero_outputs", ""),
        "reference_nonzero_outputs": math_info.get("reference_nonzero_outputs", ""),
        "datapath_mismatched_outputs": math_info.get("datapath_mismatched_outputs", ""),
        "datapath_max_abs_q15_diff": math_info.get("datapath_max_abs_q15_diff", ""),
        "output_work_waves": row.get("output_work_waves", ""),
        "k_groups": row.get("k_groups", ""),
        "mac_rounds": row.get("mac_rounds", ""),
        "cluster_mac_issues": row.get("cluster_mac_issues", ""),
        "unique_output_slots": row.get("unique_output_slots", ""),
        "unique_a_source_addresses": row.get("unique_a_source_addresses", ""),
        "expected_a_chunks": row.get("expected_a_chunks", ""),
        "unique_bt_source_addresses": row.get("unique_bt_source_addresses", ""),
        "expected_bt_chunks": row.get("expected_bt_chunks", ""),
        "preloaded_a_source_addresses": row.get("preloaded_a_source_addresses", ""),
        "preloaded_bt_source_addresses": row.get("preloaded_bt_source_addresses", ""),
        "effective_peak_mac_ops_per_cycle": _fmt(row.get("effective_peak_mac_ops_per_cycle")),
        "throughput": row.get("throughput", ""),
        "throughput_unit": row.get("throughput_unit", ""),
        "throughput_vs_nominal_peak": _fmt(row.get("throughput_vs_nominal_peak")),
        "throughput_exceeds_datapath_peak": row.get("throughput_exceeds_datapath_peak", False),
        "mapped_pe_util": row.get("mapped_pe_util", ""),
        "total_pe_util": row.get("total_pe_util", ""),
        "mapped_cordic_util": row.get("mapped_cordic_util", ""),
        "twiddle_service_util": row.get("twiddle_service_util", ""),
        "fft_twiddle_service_unit": row.get("fft_twiddle_service_unit", ""),
        "fft_twiddle_dma_events": row.get("fft_twiddle_dma_events", ""),
        "fft_cluster_hidden_twiddle_cordic_lanes": row.get("fft_cluster_hidden_twiddle_cordic_lanes", ""),
        "fft_param_load_vector_writes_full_8_lanes": row.get("fft_param_load_vector_writes_full_8_lanes", ""),
        "twiddle_service_fill_cycles": row.get("twiddle_service_fill_cycles", ""),
        "twiddle_datapath": row.get("twiddle_datapath", ""),
        "cluster_local_pe_interconnect": row.get("cluster_local_pe_interconnect", ""),
        "final_isa_pe_net_enabled": row.get("final_isa_pe_net_enabled", ""),
        "legacy_pe_net_dse_excluded_from_final_model": row.get("legacy_pe_net_dse_excluded_from_final_model", ""),
        "total_cordic_including_services": row.get("total_cordic_including_services", ""),
        "twiddle_service_cordic_counted_as_extra_physical_cordic": row.get("twiddle_service_cordic_counted_as_extra_physical_cordic", ""),
        "qr_wavefront_grouping": row.get("qr_wavefront_grouping", ""),
        "qr_wave_count": row.get("qr_wave_count", ""),
        "qr_max_rotations_per_wave": row.get("qr_max_rotations_per_wave", ""),
        "global_phase_count": row.get("global_phase_count", ""),
        "mapped_mem_events_per_cycle": row.get("mapped_mem_events_per_cycle", ""),
        "snr_db": math_info.get("snr_db", ""),
        "backend_model_name": row.get("backend_model_name", ""),
        "evidence": row.get("evidence", ""),
    }


def write_csv(path: Path, rows: Iterable[Dict[str, Any]]) -> None:
    rows = list(rows)
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as fobj:
        writer = csv.DictWriter(fobj, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def write_markdown(path: Path, summary: Dict[str, Any], rows: List[Dict[str, Any]]) -> None:
    arch = summary["architecture"]
    dma = summary["smu_dma_latency_model"]
    lines = [
        "# CGRA 16-CORDIC Cluster Highway Results (Givens, RTL-grounded latency)",
        "",
        "## Architecture",
        "",
        f"- Clusters: {arch['n_clusters']} ({arch['grid_rows']}x{arch['grid_cols']})",
        f"- PEs: {arch['total_pes']} total, {arch['pe_per_cluster']} per cluster",
        f"- CORDIC budget including services: {arch['total_cordic_including_services']} total",
        f"- Cluster-local CORDIC/RU view: {arch['total_cordic']} total, {arch['cordic_per_cluster']} per cluster",
        f"- Twiddle Service Unit: cluster{arch['twiddle_service_owner_cluster']} local CORDIC service mode, {arch['twiddle_service_sram_kib']} KiB reserved SRAM; no 17th unit",
        f"- QR algorithm: {arch['qr_algorithm']}",
        f"- Local PE interconnect: {arch['local_pe_interconnect']}",
        f"- Cross-cluster interconnect: {arch['cross_cluster_interconnect']}",
        f"- Vector payload: {arch['vector_lanes']} lanes x {arch['lane_bits']}-bit = {arch['vector_bits']}-bit",
        f"- Nominal MAC peak (1/lane/cyc, loose): {arch['nominal_peak_mac_ops_per_cycle']} ops/cycle",
        f"- Backend model(s): {summary.get('backend_model_names', [])}",
        f"- Backend DMA latency included in base cycles: {summary.get('backend_dma_latency_included_in_base', False)}",
        "",
        "## SMU/DMA latency model (RTL-measured)",
        "",
        f"- Source: {dma['provenance']}",
        f"- Isolated cross-cluster transfer: {dma['single_transfer_roundtrip_cycles']} cycles",
        f"- DMA stream: {dma['dma_stream_formula']} cycles (setup {dma['dma_setup_cycles']}, per-beat {dma['dma_per_beat_cycles']:g})",
        f"- Note: {dma['note']}",
        "",
        "## Modeling caveats",
        "",
    ]
    for c in summary["modeling_caveats"]:
        lines.append(f"- {c}")
    lines += [
        "",
        "## Summary",
        "",
        f"- Workloads: {summary['workload_count']}",
        f"- QR16 base cycles: {summary['qr16_cycles']} (Givens; cross-cluster traffic telemetry available: {summary['qr16_cross_cluster_traffic_available']})",
        f"- QR16 CORDIC util: {summary['qr16_cordic_util']:.3%}",
        f"- QR16 PE util: {summary['qr16_pe_util']:.3%}",
        f"- Max total PE util: {summary['max_total_pe_util']:.3%}",
        f"- Max Twiddle Service util: {summary['max_twiddle_service_util']:.3%}",
        f"- Workloads missing cross-cluster traffic: {summary['workloads_missing_cross_cluster_traffic']}",
        f"- Workloads throughput > nominal peak: {summary['workloads_throughput_exceeds_peak']}",
        "",
        "## Workloads",
        "",
        "| Workload | Backend | Base | X-tx | DMA cmd | DMA incl | DMA+ (stream) | DMA+ (iso) | Adj stream | Adj iso | Cl | Coverage | Throughput | >peak | PE util | CORDIC | TSU |",
        "| --- | --- | ---: | ---: | ---: | :---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :---: | ---: | ---: | ---: |",
    ]
    for row in rows:
        tp = f"{float(row['throughput']):.6g}" if row["throughput"] != "" else ""
        peutil = f"{float(row['mapped_pe_util']):.3%}" if row["mapped_pe_util"] != "" else ""
        cordic = f"{float(row['mapped_cordic_util']):.3%}" if row["mapped_cordic_util"] != "" else ""
        tsu = f"{float(row['twiddle_service_util']):.3%}" if row["twiddle_service_util"] != "" else ""
        coverage = f"{float(row['schedule_coverage']):.3%}" if row["schedule_coverage"] != "" else ""
        over = "YES" if row.get("throughput_exceeds_datapath_peak") else ""
        lines.append(
            "| " + " | ".join([
                str(row["workload"]), str(row["backend_model_name"]),
                str(row["base_cycles"]), str(row["cross_cluster_transfers"]),
                str(row["cross_cluster_dma_commands"]),
                str(row["backend_dma_latency_included"]),
                str(row["dma_added_streaming"]), str(row["dma_added_isolated"]),
                str(row["adj_streaming"]), str(row["adj_isolated"]),
                str(row["n_mapped"]), coverage, tp, over, peutil, cordic, tsu,
            ]) + " |"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_outputs(out_prefix: Path, summary: Dict[str, Any], results: List[Dict[str, Any]]) -> Dict[str, str]:
    out_prefix = out_prefix.resolve()
    flat_rows = [_flat_workload_row(r) for r in results]
    json_path = out_prefix.with_suffix(".json")
    csv_path = out_prefix.with_suffix(".csv")
    md_path = out_prefix.with_suffix(".md")
    payload = {"summary": summary, "workloads": results}
    json_path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8"
    )
    write_csv(csv_path, flat_rows)
    write_markdown(md_path, summary, flat_rows)
    return {"json": str(json_path), "csv": str(csv_path), "markdown": str(md_path)}


def print_console_summary(summary: Dict[str, Any], results: List[Dict[str, Any]], outputs: Dict[str, str]) -> None:
    arch = summary["architecture"]
    dma = summary["smu_dma_latency_model"]
    print("=" * 116)
    print("CGRA 16-CORDIC / 4PE-CLUSTER / SMU-HIGHWAY MODEL (Givens, RTL-grounded latency)")
    print("=" * 116)
    print(f"Clusters             : {arch['n_clusters']} ({arch['grid_rows']}x{arch['grid_cols']})")
    print(f"PEs / CORDIC budget : {arch['total_pes']} PE / {arch['total_cordic_including_services']} total CORDIC incl. services")
    print(f"Cluster-local view   : {arch['total_cordic']} reconfigurable local CORDIC/RU units ({arch['pe_per_cluster']} PE, 1 CORDIC per cluster)")
    print(f"Twiddle Service Unit : cluster{arch['twiddle_service_owner_cluster']} CORDIC service mode, {arch['twiddle_service_sram_kib']} KiB reserved SRAM; no 17th unit")
    print(f"QR algorithm         : {arch['qr_algorithm']}")
    print(f"Local PE crossbar    : {arch['local_pe_interconnect']}")
    print(f"Cross-cluster path   : {arch['cross_cluster_interconnect']}")
    print(f"Backend model        : {summary.get('backend_model_names', [])}")
    print(f"DMA in base cycles   : {summary.get('backend_dma_latency_included_in_base', False)}")
    print(f"SMU/DMA latency (RTL): isolated xfer {dma['single_transfer_roundtrip_cycles']}cy | "
          f"stream {dma['dma_stream_formula']}")
    print(f"Workloads            : {len(results)}")
    print(f"QR16 base cycles     : {summary['qr16_cycles']} (Givens; traffic telemetry available: {summary['qr16_cross_cluster_traffic_available']})")
    print(f"QR16 CORDIC util     : {summary['qr16_cordic_util']:.3%}")
    if summary["workloads_throughput_exceeds_peak"]:
        print(f"!! throughput > peak : {summary['workloads_throughput_exceeds_peak']}")
    if summary["workloads_missing_cross_cluster_traffic"]:
        print(f"!! missing x-cl traffc: {summary['workloads_missing_cross_cluster_traffic']}")
    print("-" * 116)
    print(f"{'Workload':<22}{'Base':>7}{'Xtx':>6}{'Dcmd':>6}{'DMA+str':>9}{'DMA+iso':>9}{'AdjStr':>8}{'AdjIso':>8}{'Cl':>4}{'TP':>10}{'>pk':>5}{'PEutil':>9}{'CORDIC':>9}{'TSU':>9}")
    for row in [_flat_workload_row(r) for r in results]:
        tp = "" if row["throughput"] == "" else f"{float(row['throughput']):.4g}"
        def g(k): return "" if row[k] == "" else str(row[k])
        over = "YES" if row.get("throughput_exceeds_datapath_peak") else ""
        print(
            f"{str(row['workload']):<22}{int(row['base_cycles']):>7}{g('cross_cluster_transfers'):>6}"
            f"{g('cross_cluster_dma_commands'):>6}"
            f"{g('dma_added_streaming'):>9}{g('dma_added_isolated'):>9}{g('adj_streaming'):>8}{g('adj_isolated'):>8}"
            f"{int(row['n_mapped']):>4}{tp:>10}{over:>5}"
            f"{float(row['mapped_pe_util']):>8.1%}{float(row['mapped_cordic_util']):>9.1%}"
            f"{float(row['twiddle_service_util'] or 0.0):>9.1%}"
        )
    print("-" * 116)
    print("Caveats:")
    for c in summary["modeling_caveats"]:
        print(f"  - {c}")
    print("-" * 116)
    print(f"JSON                 : {outputs['json']}")
    print(f"CSV                  : {outputs['csv']}")
    print(f"Markdown             : {outputs['markdown']}")
    print("=" * 116)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out-prefix", type=Path, default=DEFAULT_OUT_PREFIX)
    parser.add_argument("--backend-model", type=Path, default=BACKEND_MODEL)
    parser.add_argument("--baseline-csv", type=Path, default=LOCAL_CORDIC_BASELINE_CSV)
    parser.add_argument("--dma-setup-cycles", type=int, default=14, help="RTL-measured DMA setup (MAP-1A intercept)")
    parser.add_argument("--dma-per-beat-cycles", type=float, default=1.13, help="RTL-measured DMA per-vector streaming cost (MAP-1A slope)")
    parser.add_argument("--isolated-xfer-cycles", type=int, default=16, help="RTL-measured isolated cross-cluster transfer latency (LAT-1D)")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    arch = Architecture()
    dma = SmuDmaLatencyModel(
        single_transfer_roundtrip_cycles=args.isolated_xfer_cycles,
        dma_setup_cycles=args.dma_setup_cycles,
        dma_per_beat_cycles=args.dma_per_beat_cycles,
    )
    results = run_workloads(seed=args.seed, backend_model_path=args.backend_model, baseline_csv_path=args.baseline_csv)
    results = annotate_cross_cluster_latency(results, dma, arch)
    summary = summarize_results(arch, results, dma)
    outputs = write_outputs(args.out_prefix, summary, results)
    print_console_summary(summary, results, outputs)


if __name__ == "__main__":
    main()
