`timescale 1ns/1ps
// =============================================================================
// Registered iterative CORDIC used by the V4 architecture.
//
// mode_twiddle_i = 0: QR/Givens two-pass operation
//   18 cycles vectoring + 18 cycles rotation.
// mode_twiddle_i = 1: FFT twiddle rotation-only operation
//   z = -2*pi*j/2^m_log2, 18 cycles rotation.
//
// One micro-rotation is performed per clock. Only functional state is synthesized.
// =============================================================================
module cordic_unit (
  input  logic               clk,
  input  logic               rst_n,

  input  logic               start,
  input  logic               mode_twiddle_i,
  input  logic signed [15:0] a_in,
  input  logic signed [15:0] b_in,
  input  logic [15:0]        twiddle_j_i,
  input  logic [3:0]         twiddle_m_log2_i,
  input  logic [7:0]         extra_latency,

  output logic               busy,
  output logic               done,
  output logic signed [15:0] r_out,
  output logic signed [15:0] c_out,
  output logic signed [15:0] s_out
);

  localparam int N_ITER = 18;
  localparam int Q_BITS = 15;

  localparam logic signed [31:0] Q_MAX_C       = 32'sd32767;
  localparam logic signed [31:0] Q_MIN_C       = -32'sd32768;
  localparam logic signed [31:0] Q_ROUND_C     = 32'sd16384;
  localparam logic signed [31:0] XY_MAX_C      = 32'sd8388607;
  localparam logic signed [31:0] XY_MIN_C      = -32'sd8388608;
  localparam logic signed [31:0] INV_K_Q_C     = 32'sd19898;
  localparam logic signed [31:0] INV_SQRT2_Q_C = 32'sd23170;
  localparam logic signed [31:0] SQRT2_Q_C     = 32'sd46341;
  localparam logic signed [31:0] ANG_HALF_PI_C = 32'sd1647099;
  localparam logic signed [31:0] ANG_PI_C      = 32'sd3294199;
  localparam logic signed [31:0] ANG_TWO_PI_C  = 32'sd6588397;

  typedef enum logic [2:0] {
    ST_IDLE,
    ST_WAIT,
    ST_VECTOR,
    ST_ROTATE
  } state_t;

  state_t state_q;
  logic [7:0] wait_left_q;
  logic [4:0] iter_q;
  logic mode_twiddle_q;
  logic flip_q;

  logic signed [31:0] x_q, y_q, z_q;
  logic signed [5:0]  norm_shift_q;
  logic               output_sign_q;
  logic               bypass_q;

  function automatic logic signed [31:0] atan_fp(input logic [4:0] idx);
    case (idx)
      5'd0:  atan_fp = 32'sd823550;
      5'd1:  atan_fp = 32'sd486170;
      5'd2:  atan_fp = 32'sd256879;
      5'd3:  atan_fp = 32'sd130396;
      5'd4:  atan_fp = 32'sd65451;
      5'd5:  atan_fp = 32'sd32757;
      5'd6:  atan_fp = 32'sd16383;
      5'd7:  atan_fp = 32'sd8192;
      5'd8:  atan_fp = 32'sd4096;
      5'd9:  atan_fp = 32'sd2048;
      5'd10: atan_fp = 32'sd1024;
      5'd11: atan_fp = 32'sd512;
      5'd12: atan_fp = 32'sd256;
      5'd13: atan_fp = 32'sd128;
      5'd14: atan_fp = 32'sd64;
      5'd15: atan_fp = 32'sd32;
      5'd16: atan_fp = 32'sd16;
      5'd17: atan_fp = 32'sd8;
      default: atan_fp = 32'sd0;
    endcase
  endfunction

  function automatic logic signed [31:0] sat_q15_f(
    input logic signed [63:0] value
  );
    if (value > $signed(Q_MAX_C))
      sat_q15_f = Q_MAX_C;
    else if (value < $signed(Q_MIN_C))
      sat_q15_f = Q_MIN_C;
    else
      sat_q15_f = value[31:0];
  endfunction

  function automatic logic signed [31:0] sat_xy_f(
    input logic signed [63:0] value
  );
    if (value > $signed(XY_MAX_C))
      sat_xy_f = XY_MAX_C;
    else if (value < $signed(XY_MIN_C))
      sat_xy_f = XY_MIN_C;
    else
      sat_xy_f = value[31:0];
  endfunction

  function automatic logic signed [31:0] round_shift_right_signed_f(
    input logic signed [31:0] value,
    input logic [5:0] shift
  );
    logic signed [32:0] magnitude;
    logic signed [32:0] rounded;
    begin
      if (shift == 0) begin
        round_shift_right_signed_f = value;
      end else begin
        magnitude = (value < 0) ? -$signed({value[31], value})
                                :  $signed({1'b0, value});
        rounded = (magnitude + (33'sd1 <<< (shift - 1'b1))) >>> shift;
        round_shift_right_signed_f = (value < 0) ? -rounded[31:0]
                                                 :  rounded[31:0];
      end
    end
  endfunction

  function automatic logic [4:0] leading_one_pos_16(input logic [15:0] magnitude);
    integer bit_idx;
    logic found;
    begin
      leading_one_pos_16 = 5'd0;
      found = 1'b0;
      for (bit_idx = 15; bit_idx >= 0; bit_idx = bit_idx - 1) begin
        if (!found && magnitude[bit_idx]) begin
          leading_one_pos_16 = bit_idx[4:0];
          found = 1'b1;
        end
      end
    end
  endfunction

  // QR start preprocessing.
  logic signed [31:0] start_a_ext, start_b_ext;
  logic [15:0] start_abs_a, start_abs_b, start_max_abs;
  logic [4:0] start_top_bit;
  logic [5:0] start_norm_shift;
  logic signed [31:0] start_a_norm, start_b_norm;
  logic signed [63:0] start_a_product, start_b_product;
  logic signed [31:0] start_a_scaled, start_b_scaled;
  logic start_flip;
  logic start_axis_bypass;
  logic signed [15:0] start_bypass_r, start_bypass_c, start_bypass_s;

  always_comb begin
    start_a_ext = {{16{a_in[15]}}, a_in};
    start_b_ext = {{16{b_in[15]}}, b_in};
    start_abs_a = a_in[15] ? (~a_in + 16'd1) : a_in;
    start_abs_b = b_in[15] ? (~b_in + 16'd1) : b_in;
    start_max_abs = (start_abs_a > start_abs_b) ? start_abs_a : start_abs_b;
    start_top_bit = leading_one_pos_16(start_max_abs);
    start_norm_shift = (start_top_bit < 5'd14) ? (6'd14 - start_top_bit) : 6'd0;
    start_a_norm = start_a_ext <<< start_norm_shift;
    start_b_norm = start_b_ext <<< start_norm_shift;
    start_a_product = $signed(start_a_norm) * $signed(INV_SQRT2_Q_C);
    start_b_product = $signed(start_b_norm) * $signed(INV_SQRT2_Q_C);
    start_a_scaled = sat_q15_f((start_a_product + Q_ROUND_C) >>> Q_BITS);
    start_b_scaled = sat_q15_f((start_b_product + Q_ROUND_C) >>> Q_BITS);
    start_flip = (start_a_scaled < 0);

    start_axis_bypass = 1'b0;
    start_bypass_r = 16'sd0;
    start_bypass_c = 16'sd0;
    start_bypass_s = 16'sd0;
    if ((a_in == 16'sd0) && (b_in == 16'sd0)) begin
      start_axis_bypass = 1'b1;
      start_bypass_r = 16'sd0;
      start_bypass_c = 16'sd32767;
      start_bypass_s = 16'sd0;
    end else if (b_in == 16'sd0) begin
      start_axis_bypass = 1'b1;
      start_bypass_r = (start_abs_a > 16'd32767) ? 16'sd32767 : $signed(start_abs_a);
      start_bypass_c = (a_in > 0) ? 16'sd32767 : 16'sh8000;
      start_bypass_s = 16'sd0;
    end else if (a_in == 16'sd0) begin
      start_axis_bypass = 1'b1;
      start_bypass_r = (start_abs_b > 16'd32767) ? 16'sd32767 : $signed(start_abs_b);
      start_bypass_c = 16'sd0;
      start_bypass_s = (b_in > 0) ? 16'sd32767 : 16'sh8000;
    end
  end

  // FFT angle preprocessing.  m is always a power of two, so division is an
  // arithmetic shift.  The result is reduced/folded to the CORDIC convergence
  // interval exactly as in the Python fixed-point reference.
  logic signed [63:0] twiddle_angle_wide;
  logic signed [31:0] twiddle_angle_reduced;
  logic twiddle_output_sign;
  always_comb begin
    twiddle_angle_wide = -($signed({1'b0, twiddle_j_i}) * $signed(ANG_TWO_PI_C));
    twiddle_angle_reduced = twiddle_angle_wide >>> twiddle_m_log2_i;
    if (twiddle_angle_reduced > ANG_PI_C)
      twiddle_angle_reduced = twiddle_angle_reduced - ANG_TWO_PI_C;
    else if (twiddle_angle_reduced < -ANG_PI_C)
      twiddle_angle_reduced = twiddle_angle_reduced + ANG_TWO_PI_C;

    twiddle_output_sign = 1'b0;
    if (twiddle_angle_reduced > ANG_HALF_PI_C) begin
      twiddle_angle_reduced = twiddle_angle_reduced - ANG_PI_C;
      twiddle_output_sign = 1'b1;
    end else if (twiddle_angle_reduced < -ANG_HALF_PI_C) begin
      twiddle_angle_reduced = twiddle_angle_reduced + ANG_PI_C;
      twiddle_output_sign = 1'b1;
    end
  end

  logic signed [31:0] vector_x_next, vector_y_next, vector_z_next;
  logic signed [63:0] vector_x_wide, vector_y_wide;
  always_comb begin
    if (y_q >= 0) begin
      vector_x_wide = $signed(x_q) + $signed(y_q >>> iter_q);
      vector_y_wide = $signed(y_q) - $signed(x_q >>> iter_q);
      vector_z_next = z_q + atan_fp(iter_q);
    end else begin
      vector_x_wide = $signed(x_q) - $signed(y_q >>> iter_q);
      vector_y_wide = $signed(y_q) + $signed(x_q >>> iter_q);
      vector_z_next = z_q - atan_fp(iter_q);
    end
    vector_x_next = sat_xy_f(vector_x_wide);
    vector_y_next = sat_xy_f(vector_y_wide);
  end

  logic signed [31:0] rotate_x_next, rotate_y_next, rotate_z_next;
  logic signed [63:0] rotate_x_wide, rotate_y_wide;
  always_comb begin
    if (z_q >= 0) begin
      rotate_x_wide = $signed(x_q) - $signed(y_q >>> iter_q);
      rotate_y_wide = $signed(y_q) + $signed(x_q >>> iter_q);
      rotate_z_next = z_q - atan_fp(iter_q);
    end else begin
      rotate_x_wide = $signed(x_q) + $signed(y_q >>> iter_q);
      rotate_y_wide = $signed(y_q) - $signed(x_q >>> iter_q);
      rotate_z_next = z_q + atan_fp(iter_q);
    end
    rotate_x_next = sat_xy_f(rotate_x_wide);
    rotate_y_next = sat_xy_f(rotate_y_wide);
  end

  logic signed [63:0] radius_mul_k_wide;
  logic signed [63:0] radius_mul_sqrt2_wide;
  logic signed [31:0] radius_scaled_comb;
  logic signed [31:0] radius_norm_comb;
  logic signed [31:0] radius_shifted_comb;
  logic signed [31:0] radius_sat_comb;
  logic signed [31:0] rotate_c_fold_sat_comb, rotate_s_fold_sat_comb;
  logic signed [31:0] rotate_c_final_sat_comb, rotate_s_final_sat_comb;
  always_comb begin
    radius_mul_k_wide = $signed(vector_x_next) * $signed(INV_K_Q_C);
    radius_scaled_comb = (radius_mul_k_wide + Q_ROUND_C) >>> Q_BITS;
    radius_mul_sqrt2_wide = $signed(radius_scaled_comb) * $signed(SQRT2_Q_C);
    radius_norm_comb = (radius_mul_sqrt2_wide + Q_ROUND_C) >>> Q_BITS;
    radius_shifted_comb = round_shift_right_signed_f(radius_norm_comb, norm_shift_q);
    radius_sat_comb = sat_q15_f(radius_shifted_comb);
    // Match the Python bit definition exactly: the angle-fold sign is applied
    // and saturated inside cordic_rot_q15(), then the QR input-quadrant flip
    // is applied and saturated a second time.
    rotate_c_fold_sat_comb = sat_q15_f(output_sign_q ? -$signed(rotate_x_next)
                                                           :  $signed(rotate_x_next));
    rotate_s_fold_sat_comb = sat_q15_f(output_sign_q ? -$signed(rotate_y_next)
                                                           :  $signed(rotate_y_next));
    rotate_c_final_sat_comb = sat_q15_f(flip_q ? -$signed(rotate_c_fold_sat_comb)
                                                      :  $signed(rotate_c_fold_sat_comb));
    rotate_s_final_sat_comb = sat_q15_f(flip_q ? -$signed(rotate_s_fold_sat_comb)
                                                      :  $signed(rotate_s_fold_sat_comb));
  end

  assign busy = (state_q != ST_IDLE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state_q <= ST_IDLE;
      wait_left_q <= '0;
      iter_q <= '0;
      mode_twiddle_q <= 1'b0;
      flip_q <= 1'b0;
      x_q <= '0;
      y_q <= '0;
      z_q <= '0;
      norm_shift_q <= '0;
      output_sign_q <= 1'b0;
      bypass_q <= 1'b0;
      done <= 1'b0;
      r_out <= '0;
      c_out <= '0;
      s_out <= '0;
    end else begin
      done <= 1'b0;
      case (state_q)
        ST_IDLE: begin
          if (start) begin
            wait_left_q <= extra_latency;
            iter_q <= 5'd0;
            mode_twiddle_q <= mode_twiddle_i;
            flip_q <= mode_twiddle_i ? 1'b0 : start_flip;
            if (mode_twiddle_i) begin
              x_q <= INV_K_Q_C;
              y_q <= 32'sd0;
              z_q <= twiddle_angle_reduced;
              norm_shift_q <= '0;
              output_sign_q <= twiddle_output_sign;
              bypass_q <= 1'b0;
              r_out <= 16'sd0;
            end else begin
              norm_shift_q <= start_norm_shift;
              bypass_q <= start_axis_bypass;
              if (start_axis_bypass) begin
                r_out <= start_bypass_r;
                c_out <= start_bypass_c;
                s_out <= start_bypass_s;
                x_q <= '0;
                y_q <= '0;
                z_q <= '0;
                output_sign_q <= 1'b0;
              end else begin
                x_q <= start_flip ? -start_a_scaled : start_a_scaled;
                y_q <= start_flip ? -start_b_scaled : start_b_scaled;
                z_q <= 32'sd0;
                output_sign_q <= 1'b0;
              end
            end
            state_q <= (extra_latency != 0) ? ST_WAIT :
                       (mode_twiddle_i ? ST_ROTATE : ST_VECTOR);
          end
        end

        ST_WAIT: begin
          if (wait_left_q <= 8'd1) begin
            wait_left_q <= 8'd0;
            iter_q <= 5'd0;
            state_q <= mode_twiddle_q ? ST_ROTATE : ST_VECTOR;
          end else begin
            wait_left_q <= wait_left_q - 8'd1;
          end
        end

        ST_VECTOR: begin
          if (!bypass_q) begin
            x_q <= vector_x_next;
            y_q <= vector_y_next;
            z_q <= vector_z_next;
          end
          if (iter_q == N_ITER-1) begin
            if (!bypass_q) begin
              r_out <= (radius_shifted_comb < 0) ? 16'sd0 : radius_sat_comb[15:0];
              if (vector_z_next > ANG_HALF_PI_C) begin
                z_q <= vector_z_next - ANG_PI_C;
                output_sign_q <= 1'b1;
              end else if (vector_z_next < -ANG_HALF_PI_C) begin
                z_q <= vector_z_next + ANG_PI_C;
                output_sign_q <= 1'b1;
              end else begin
                z_q <= vector_z_next;
                output_sign_q <= 1'b0;
              end
              x_q <= INV_K_Q_C;
              y_q <= 32'sd0;
            end
            iter_q <= 5'd0;
            state_q <= ST_ROTATE;
          end else begin
            iter_q <= iter_q + 5'd1;
          end
        end

        ST_ROTATE: begin
          if (!bypass_q) begin
            x_q <= rotate_x_next;
            y_q <= rotate_y_next;
            z_q <= rotate_z_next;
          end
          if (iter_q == N_ITER-1) begin
            if (!bypass_q) begin
              c_out <= rotate_c_final_sat_comb[15:0];
              s_out <= rotate_s_final_sat_comb[15:0];
            end
            iter_q <= 5'd0;
            state_q <= ST_IDLE;
            done <= 1'b1;
          end else begin
            iter_q <= iter_q + 5'd1;
          end
        end

        default: state_q <= ST_IDLE;
      endcase
    end
  end
endmodule : cordic_unit
