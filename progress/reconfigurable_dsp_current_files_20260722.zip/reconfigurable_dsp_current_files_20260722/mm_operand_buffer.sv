`timescale 1ns/1ps

// =============================================================================
// mm_operand_buffer.sv
//
// Model-aligned MM operand landing and B-stationary prefetch block.
//
// Supported autonomous mappings:
//   1. Legacy four-K-group ping-pong tiles:
//        A bank0/1 = vec 192/196, four vectors each
//        B bank0/1 = vec 200/216, sixteen vectors each
//   2. V4.1 B-stationary row-pair mapping:
//        A context0/1 = vec 192/200, eight vectors each
//        B remains in local SRAM and four PE-owned vectors are read in parallel.
//
// For a non-DMA MM_MAC context carrying MICRO_FLAG_MM_B_RESIDENT, Context RAM
// stores the 11-bit resident-B base vector in:
//   {context[CTX_RSVD_AGU_LSB +: 3], context[CTX_DMA_LEN_LSB +: 8]}.
// The current K group is immediate[17:10], so PE p reads:
//   (base_vec + k_group*4 + p) * 32 bytes.
// =============================================================================

module mm_operand_buffer #(
  parameter int N_PE         = cgra_rtl_pkg::N_PE,
  parameter int VECTOR_W     = cgra_rtl_pkg::VECTOR_W,
  parameter int LOCAL_ADDR_W = cgra_rtl_pkg::LOCAL_ADDR_W,
  parameter int EXEC_IMM_W   = cgra_rtl_pkg::EXEC_IMM_W,
  parameter int CTX_W        = cgra_rtl_pkg::CTX_W
) (
  input  logic clk_i,
  input  logic rst_ni,

  // Architectural SRAM-visible writes from the SMU WBQ drain.
  input  logic [cgra_rtl_pkg::LOCAL_BANKS-1:0] commit_valid_i,
  input  logic [cgra_rtl_pkg::LOCAL_BANKS-1:0][LOCAL_ADDR_W-1:0] commit_addr_i,
  input  logic [cgra_rtl_pkg::LOCAL_BANKS-1:0][VECTOR_W-1:0] commit_data_i,

  // Accepted direct DMA command.  MM operand valid bits are invalidated at
  // command admission, then set only by architectural WBQ->SRAM commits.
  input  logic                  dma_cmd_fire_i,
  input  logic [4:0]            dma_kind_i,
  input  logic [3:0]            dma_flags_i,
  input  logic [LOCAL_ADDR_W-1:0] dma_dst_local_i,

  // Current in-order MM_MAC instruction.  It remains stable until issue_fire_i.
  input  logic                  mm_mac_valid_i,
  input  logic [EXEC_IMM_W-1:0] immediate_i,
  input  logic [CTX_W-1:0]      context_i,
  input  logic                  issue_fire_i,

  output logic                  operands_ready_o,
  output logic [VECTOR_W-1:0]   a_vector_o,
  output logic [N_PE*VECTOR_W-1:0] b_vectors_o,

  // Four local SRAM Port-B vector reads for B-stationary mode.
  output logic [N_PE-1:0]       b_req_valid_o,
  input  logic [N_PE-1:0]       b_req_ready_i,
  output logic [N_PE-1:0][LOCAL_ADDR_W-1:0] b_req_addr_o,
  output logic [N_PE-1:0][3:0]  b_req_tag_o,

  input  logic [N_PE-1:0]       b_rsp_valid_i,
  input  logic [N_PE-1:0]       b_rsp_err_i,
  input  logic [N_PE-1:0]       b_rsp_kind_i,
  input  logic [N_PE-1:0][VECTOR_W-1:0] b_rsp_data_i,
  input  logic [N_PE-1:0][3:0]  b_rsp_tag_i
);
  import cgra_rtl_pkg::*;

  localparam logic [3:0] MM_B_RSP_TAG = 4'hE;

  logic [VECTOR_W-1:0] tile_a_q [0:1][0:MM_K_TILE_GROUPS-1];
  logic                tile_a_valid_q [0:1][0:MM_K_TILE_GROUPS-1];
  logic [VECTOR_W-1:0] tile_b_q [0:1][0:MM_K_TILE_GROUPS-1][0:N_PE-1];
  logic                tile_b_valid_q [0:1][0:MM_K_TILE_GROUPS-1][0:N_PE-1];

  logic [VECTOR_W-1:0] rowpair_a_q [0:1][0:MM_ROWPAIR_K_CAPACITY-1];
  logic                rowpair_a_valid_q [0:1][0:MM_ROWPAIR_K_CAPACITY-1];

  logic                resident_active_q;
  logic [N_PE-1:0]     resident_req_sent_q;
  logic [N_PE-1:0]     resident_b_valid_q;
  logic [N_PE-1:0][VECTOR_W-1:0] resident_b_q;
  logic [10:0]         resident_base_vec_q;
  logic [2:0]          resident_k_group_q;

  logic [3:0] flags;
  logic [7:0] k_group_full;
  logic [2:0] rowpair_slot;
  logic [1:0] tile_slot;
  logic       tile_bank;
  logic       resident_mode;
  logic [10:0] context_b_base_vec;

  assign flags = immediate_i[28:25];
  assign k_group_full = immediate_i[17:10];
  assign rowpair_slot = k_group_full[2:0];
  assign tile_slot = k_group_full[1:0];
  assign tile_bank = flags[2]; // MICRO_FLAG_MM_BUFFER1
  assign resident_mode = mm_mac_valid_i && ((flags & MICRO_FLAG_MM_B_RESIDENT) != 0);
  assign context_b_base_vec = {
    context_i[CTX_RSVD_AGU_LSB +: 3],
    context_i[CTX_DMA_LEN_LSB +: 8]
  };

  always_comb begin
    b_req_valid_o = '0;
    b_req_addr_o = '0;
    b_req_tag_o = '0;
    for (int p = 0; p < N_PE; p++) begin
      b_req_valid_o[p] = resident_active_q && !resident_req_sent_q[p];
      b_req_addr_o[p] = LOCAL_ADDR_W'(
        (resident_base_vec_q + resident_k_group_q*N_PE + p) * (VECTOR_W/8)
      );
      b_req_tag_o[p] = MM_B_RSP_TAG;
    end
  end

  always_comb begin
    operands_ready_o = 1'b0;
    a_vector_o = '0;
    b_vectors_o = '0;

    if (mm_mac_valid_i && ((flags & MICRO_FLAG_MM_PINGPONG) != 0)) begin
      if (resident_mode) begin
        a_vector_o = rowpair_a_q[immediate_i[29]][rowpair_slot];
        for (int p = 0; p < N_PE; p++)
          b_vectors_o[p*VECTOR_W +: VECTOR_W] = resident_b_q[p];
        operands_ready_o = resident_active_q &&
                           rowpair_a_valid_q[immediate_i[29]][rowpair_slot] &&
                           (&resident_b_valid_q);
      end else begin
        a_vector_o = tile_a_q[tile_bank][tile_slot];
        for (int p = 0; p < N_PE; p++)
          b_vectors_o[p*VECTOR_W +: VECTOR_W] = tile_b_q[tile_bank][tile_slot][p];
        operands_ready_o = tile_a_valid_q[tile_bank][tile_slot];
        for (int p = 0; p < N_PE; p++)
          operands_ready_o &= tile_b_valid_q[tile_bank][tile_slot][p];
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin : p_state
    integer bank, slot, pe_idx;
    logic [LOCAL_ADDR_W-1:0] addr;
    logic [10:0] vec_idx;
    logic [10:0] off;
    if (!rst_ni) begin
      resident_active_q <= 1'b0;
      resident_req_sent_q <= '0;
      resident_b_valid_q <= '0;
      resident_b_q <= '0;
      resident_base_vec_q <= '0;
      resident_k_group_q <= '0;
      for (bank = 0; bank < 2; bank++) begin
        for (slot = 0; slot < MM_K_TILE_GROUPS; slot++) begin
          tile_a_q[bank][slot] <= '0;
          tile_a_valid_q[bank][slot] <= 1'b0;
          for (pe_idx = 0; pe_idx < N_PE; pe_idx++) begin
            tile_b_q[bank][slot][pe_idx] <= '0;
            tile_b_valid_q[bank][slot][pe_idx] <= 1'b0;
          end
        end
        for (slot = 0; slot < MM_ROWPAIR_K_CAPACITY; slot++) begin
          rowpair_a_q[bank][slot] <= '0;
          rowpair_a_valid_q[bank][slot] <= 1'b0;
        end
      end
    end else begin

      // Mirror DMA/WBQ commits into the small operand landing buffers.
      for (bank = 0; bank < LOCAL_BANKS; bank++) begin
        if (commit_valid_i[bank]) begin
          addr = commit_addr_i[bank];
          vec_idx = addr >> 5;

          if ((vec_idx >= MM_TILE_A_BASE0_VEC) &&
              (vec_idx < MM_TILE_A_BASE0_VEC + MM_K_TILE_GROUPS)) begin
            off = vec_idx - MM_TILE_A_BASE0_VEC;
            tile_a_q[0][off[1:0]] <= commit_data_i[bank];
            tile_a_valid_q[0][off[1:0]] <= 1'b1;
          end
          if ((vec_idx >= MM_TILE_A_BASE1_VEC) &&
              (vec_idx < MM_TILE_A_BASE1_VEC + MM_K_TILE_GROUPS)) begin
            off = vec_idx - MM_TILE_A_BASE1_VEC;
            tile_a_q[1][off[1:0]] <= commit_data_i[bank];
            tile_a_valid_q[1][off[1:0]] <= 1'b1;
          end
          if ((vec_idx >= MM_TILE_B_BASE0_VEC) &&
              (vec_idx < MM_TILE_B_BASE0_VEC + MM_K_TILE_GROUPS*N_PE)) begin
            off = vec_idx - MM_TILE_B_BASE0_VEC;
            tile_b_q[0][off[5:2]][off[1:0]] <= commit_data_i[bank];
            tile_b_valid_q[0][off[5:2]][off[1:0]] <= 1'b1;
          end
          if ((vec_idx >= MM_TILE_B_BASE1_VEC) &&
              (vec_idx < MM_TILE_B_BASE1_VEC + MM_K_TILE_GROUPS*N_PE)) begin
            off = vec_idx - MM_TILE_B_BASE1_VEC;
            tile_b_q[1][off[5:2]][off[1:0]] <= commit_data_i[bank];
            tile_b_valid_q[1][off[5:2]][off[1:0]] <= 1'b1;
          end

          if ((vec_idx >= MM_ROWPAIR_A_BASE0_VEC) &&
              (vec_idx < MM_ROWPAIR_A_BASE0_VEC + MM_ROWPAIR_K_CAPACITY)) begin
            off = vec_idx - MM_ROWPAIR_A_BASE0_VEC;
            rowpair_a_q[0][off[2:0]] <= commit_data_i[bank];
            rowpair_a_valid_q[0][off[2:0]] <= 1'b1;
          end
          if ((vec_idx >= MM_ROWPAIR_A_BASE1_VEC) &&
              (vec_idx < MM_ROWPAIR_A_BASE1_VEC + MM_ROWPAIR_K_CAPACITY)) begin
            off = vec_idx - MM_ROWPAIR_A_BASE1_VEC;
            rowpair_a_q[1][off[2:0]] <= commit_data_i[bank];
            rowpair_a_valid_q[1][off[2:0]] <= 1'b1;
          end
        end
      end

      // Invalidate the landing buffer only after applying same-cycle commit
      // events.  A newly accepted DMA command starts a new logical version;
      // therefore invalidation must win over any residual commit belonging to
      // the previous command.
      if (dma_cmd_fire_i && (dma_kind_i == M_MM_A_LOAD) &&
          ((dma_dst_local_i >> 5) inside {MM_TILE_A_BASE0_VEC, MM_TILE_A_BASE1_VEC,
                                         MM_ROWPAIR_A_BASE0_VEC, MM_ROWPAIR_A_BASE1_VEC})) begin
        if ((dma_flags_i & MICRO_FLAG_MM_B_RESIDENT) != 0) begin
          if ((dma_flags_i & MICRO_FLAG_MM_BUFFER1) != 0) begin
            for (slot = 0; slot < MM_ROWPAIR_K_CAPACITY; slot++)
              rowpair_a_valid_q[1][slot] <= 1'b0;
          end else begin
            for (slot = 0; slot < MM_ROWPAIR_K_CAPACITY; slot++)
              rowpair_a_valid_q[0][slot] <= 1'b0;
          end
        end else begin
          if ((dma_flags_i & MICRO_FLAG_MM_BUFFER1) != 0) begin
            for (slot = 0; slot < MM_K_TILE_GROUPS; slot++)
              tile_a_valid_q[1][slot] <= 1'b0;
          end else begin
            for (slot = 0; slot < MM_K_TILE_GROUPS; slot++)
              tile_a_valid_q[0][slot] <= 1'b0;
          end
        end
      end
      if (dma_cmd_fire_i && (dma_kind_i == M_MM_B_LOAD) &&
          ((dma_dst_local_i >> 5) inside {MM_TILE_B_BASE0_VEC, MM_TILE_B_BASE1_VEC})) begin
        if ((dma_flags_i & MICRO_FLAG_MM_BUFFER1) != 0) begin
          for (slot = 0; slot < MM_K_TILE_GROUPS; slot++)
            for (pe_idx = 0; pe_idx < N_PE; pe_idx++)
              tile_b_valid_q[1][slot][pe_idx] <= 1'b0;
        end else begin
          for (slot = 0; slot < MM_K_TILE_GROUPS; slot++)
            for (pe_idx = 0; pe_idx < N_PE; pe_idx++)
              tile_b_valid_q[0][slot][pe_idx] <= 1'b0;
        end
      end

      // Start one four-bank B prefetch for the held MM_MAC instruction.
      if (resident_mode && !resident_active_q) begin
        resident_active_q <= 1'b1;
        resident_req_sent_q <= '0;
        resident_b_valid_q <= '0;
        resident_base_vec_q <= context_b_base_vec;
        resident_k_group_q <= rowpair_slot;
      end

      for (int p = 0; p < N_PE; p++) begin
        if (b_req_valid_o[p] && b_req_ready_i[p])
          resident_req_sent_q[p] <= 1'b1;
        if (b_rsp_valid_i[p] && !b_rsp_err_i[p] && !b_rsp_kind_i[p] &&
            (b_rsp_tag_i[p] == MM_B_RSP_TAG)) begin
          resident_b_q[p] <= b_rsp_data_i[p];
          resident_b_valid_q[p] <= 1'b1;
        end
      end

      if (issue_fire_i) begin
        resident_active_q <= 1'b0;
        resident_req_sent_q <= '0;
        resident_b_valid_q <= '0;
      end
    end
  end

endmodule : mm_operand_buffer
