`timescale 1ns/1ps
import cgra_rtl_pkg::*;

module cgra_top (
  input  logic clk_i,
  input  logic rst_ni,

  input  logic [N_CLUSTERS-1:0] mapped_cluster_mask_i,
  input  logic [N_CLUSTERS-1:0] start_i,
  input  logic [N_CLUSTERS*(PC_W+1)-1:0] program_words_i,

  // One host programming lane, cluster selected explicitly.
  input  logic                  prog_imem_wr_en_i,
  input  logic                  prog_ctx_wr_en_i,
  input  logic [CLUSTER_ID_W-1:0] prog_cluster_i,
  input  logic [PC_W-1:0]       prog_imem_addr_i,
  input  logic [63:0]           prog_imem_data_i,
  input  logic [CTX_ADDR_W-1:0] prog_ctx_addr_i,
  input  logic [CTX_W-1:0]      prog_ctx_data_i,

  output logic [N_CLUSTERS-1:0] cluster_done_o,
  output logic [N_CLUSTERS-1:0] cluster_active_o,
  output logic                  all_done_o,
  output logic [N_CLUSTERS-1:0] cluster_fault_o,
  output logic [N_CLUSTERS*8-1:0] cluster_fault_code_o,

  // Per-cluster SMU/DMA interfaces.
  output logic [N_CLUSTERS-1:0] dma_req_valid_o,
  input  logic [N_CLUSTERS-1:0] dma_req_ready_i,
  output logic [N_CLUSTERS*CLUSTER_ID_W-1:0] dma_src_cluster_o,
  output logic [N_CLUSTERS*CLUSTER_ID_W-1:0] dma_dst_cluster_o,
  output logic [N_CLUSTERS*LOCAL_ADDR_W-1:0] dma_src_local_o,
  output logic [N_CLUSTERS*LOCAL_ADDR_W-1:0] dma_dst_local_o,
  output logic [N_CLUSTERS*8-1:0] dma_len_vec_o,
  output logic [N_CLUSTERS*2-1:0] dma_requester_pe_o,
  output logic [N_CLUSTERS*3-1:0] dma_tag_o,
  input  logic [N_CLUSTERS-1:0] dma_idle_i,

  // Per-cluster local SRAM Port-A preload clients.
  output logic [N_CLUSTERS-1:0] qr_mem_req_valid_o,
  input  logic [N_CLUSTERS-1:0] qr_mem_req_ready_i,
  output logic [N_CLUSTERS-1:0] qr_mem_req_write_o,
  output logic [N_CLUSTERS*LOCAL_ADDR_W-1:0] qr_mem_req_addr_o,
  input  logic [N_CLUSTERS-1:0] qr_mem_rsp_valid_i,
  input  logic [N_CLUSTERS*VECTOR_W-1:0] qr_mem_rsp_data_i,

  // PE/RU shell interfaces.
  output logic [N_CLUSTERS-1:0] pe_issue_valid_o,
  input  logic [N_CLUSTERS-1:0] pe_issue_ready_i,
  output logic [N_CLUSTERS*36-1:0] pe_slots_o,
  output logic [N_CLUSTERS*PARAM_ID_W-1:0] pe_param_id_o,
  output logic [N_CLUSTERS*3-1:0] pe_legacy_ctx_id_o,
  output logic [N_CLUSTERS*EXEC_IMM_W-1:0] pe_immediate_o,
  output logic [N_CLUSTERS*CTX_W-1:0] pe_context_o,
  output logic [N_CLUSTERS-1:0] pe_param_valid_o,
  output logic [N_CLUSTERS*VECTOR_W-1:0] pe_param_vector_o,
  output logic [N_CLUSTERS*PARAM_TAG_W-1:0] pe_param_tag_o,
  output logic [N_CLUSTERS-1:0] fir_agu_active_o,
  output logic [N_CLUSTERS*8-1:0] fir_k_group_o,
  output logic [N_CLUSTERS*8-1:0] fir_k_group_limit_o,
  output logic [N_CLUSTERS*N_PE*LANES-1:0] fir_x_valid_o,
  output logic [N_CLUSTERS*N_PE*LANES*FIR_INDEX_W-1:0] fir_x_index_o,
  output logic [N_CLUSTERS*LANES-1:0] fir_h_valid_o,
  output logic [N_CLUSTERS*LANES*FIR_TAPS_W-1:0] fir_h_index_o,
  output logic [N_CLUSTERS*N_PE*FIR_SAMPLES_W-1:0] fir_sample_index_o,
  input  logic [N_CLUSTERS*N_PE-1:0] pe_busy_i,
  input  logic [N_CLUSTERS-1:0] ru_busy_i,

  input  logic [N_CLUSTERS*QR_TARGET_INPUT_VECS-1:0] qr_target_valid_i,
  input  logic [N_CLUSTERS*QR_TARGET_INPUT_VECS*VECTOR_W-1:0] qr_target_vectors_i,
  output logic [N_CLUSTERS-1:0] qr_target_reset_o,
  output logic [N_CLUSTERS-1:0] qr_pe_pairs_valid_o,
  input  logic [N_CLUSTERS-1:0] qr_pe_pairs_ready_i,
  output logic [N_CLUSTERS*N_PE*VECTOR_W-1:0] qr_pe_pairs_o,
  output logic [N_CLUSTERS-1:0] cordic_qr_pair_valid_o,
  output logic signed [N_CLUSTERS*LANE_W-1:0] cordic_qr_pivot_o,
  output logic signed [N_CLUSTERS*LANE_W-1:0] cordic_qr_target_o,

  // Local CORDIC shells.
  output logic [N_CLUSTERS-1:0] cordic_req_valid_o,
  input  logic [N_CLUSTERS-1:0] cordic_req_ready_i,
  output logic [N_CLUSTERS-1:0] cordic_mode_twiddle_o,
  output logic [N_CLUSTERS*16-1:0] cordic_twiddle_j_o,
  output logic [N_CLUSTERS*4-1:0] cordic_twiddle_m_log2_o,
  output logic [N_CLUSTERS*PARAM_ID_W-1:0] cordic_param_id_o,
  output logic [N_CLUSTERS*EXEC_IMM_W-1:0] cordic_immediate_o,
  output logic [N_CLUSTERS*CTX_W-1:0] cordic_context_o,
  input  logic [N_CLUSTERS-1:0] cordic_rsp_valid_i,
  input  logic [N_CLUSTERS*VECTOR_W-1:0] cordic_rsp_vector_i,
  input  logic signed [N_CLUSTERS*LANE_W-1:0] cordic_rsp_cos_i,
  input  logic signed [N_CLUSTERS*LANE_W-1:0] cordic_rsp_sin_i,
  input  logic [N_CLUSTERS-1:0] cordic_idle_i,

  // External ParamRF write producers.
  input  logic [N_CLUSTERS-1:0] ext_param_wr_valid_i,
  output logic [N_CLUSTERS-1:0] ext_param_wr_ready_o,
  input  logic [N_CLUSTERS*3-1:0] ext_param_wr_op_i,
  input  logic [N_CLUSTERS*PARAM_ID_W-1:0] ext_param_wr_pid_i,
  input  logic [N_CLUSTERS*VECTOR_W-1:0] ext_param_wr_data_i,
  input  logic [N_CLUSTERS*LANE_W-1:0] ext_param_wr_pair_c_i,
  input  logic [N_CLUSTERS*LANE_W-1:0] ext_param_wr_pair_s_i,
  input  logic [N_CLUSTERS*PARAM_TAG_W-1:0] ext_param_wr_tag_i,

  // Cluster-local all-to-all forwarding ports.
  input  logic [N_CLUSTERS*N_PE-1:0] pe_result_valid_i,
  output logic [N_CLUSTERS*N_PE-1:0] pe_result_ready_o,
  input  logic [N_CLUSTERS*N_PE*VECTOR_W-1:0] pe_result_data_i,
  input  logic [N_CLUSTERS*N_PE*PARAM_ID_W-1:0] pe_result_pid_i,
  input  logic [N_CLUSTERS-1:0] cordic_broadcast_valid_i,
  output logic [N_CLUSTERS-1:0] cordic_broadcast_ready_o,
  input  logic [N_CLUSTERS*VECTOR_W-1:0] cordic_broadcast_data_i,
  input  logic [N_CLUSTERS*PARAM_ID_W-1:0] cordic_broadcast_pid_i,
  output logic [N_CLUSTERS*N_PE-1:0] xbar_dst_valid_o,
  input  logic [N_CLUSTERS*N_PE-1:0] xbar_dst_pop_i,
  output logic [N_CLUSTERS*N_PE*VECTOR_W-1:0] xbar_dst_data_o
);

  logic [N_CLUSTERS-1:0] barrier_req;
  logic [N_CLUSTERS*16-1:0] barrier_token;
  logic [N_CLUSTERS-1:0] barrier_release;
  logic barrier_all;
  logic barrier_token_match;
  logic [15:0] reference_token;
  logic barrier_fired_q;
  integer c;

  always_comb begin
    reference_token = '0;
    for (c = 0; c < N_CLUSTERS; c++) begin
      if (mapped_cluster_mask_i[c] && barrier_req[c]) reference_token = barrier_token[c*16 +: 16];
    end
    barrier_all = 1'b1;
    barrier_token_match = 1'b1;
    for (c = 0; c < N_CLUSTERS; c++) begin
      if (mapped_cluster_mask_i[c]) begin
        barrier_all &= barrier_req[c];
        if (barrier_req[c])
          barrier_token_match &= (barrier_token[c*16 +: 16] == reference_token);
      end
    end
    barrier_release = '0;
    if (barrier_all && barrier_token_match && !barrier_fired_q)
      barrier_release = mapped_cluster_mask_i;

    all_done_o = &(cluster_done_o | ~mapped_cluster_mask_i);
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      barrier_fired_q <= 1'b0;
    end else begin
      if (!(barrier_all && barrier_token_match)) barrier_fired_q <= 1'b0;
      else if (barrier_all && barrier_token_match && !barrier_fired_q) barrier_fired_q <= 1'b1;
    end
  end

  genvar g;
  generate
    for (g = 0; g < N_CLUSTERS; g++) begin : gen_cluster
      cluster_top #(
        .CLUSTER_ID(g)
      ) u_cluster (
        .clk_i(clk_i), .rst_ni(rst_ni),
        .imem_wr_en_i(prog_imem_wr_en_i && (prog_cluster_i == g)),
        .imem_wr_addr_i(prog_imem_addr_i), .imem_wr_data_i(prog_imem_data_i),
        .ctx_wr_en_i(prog_ctx_wr_en_i && (prog_cluster_i == g)),
        .ctx_wr_addr_i(prog_ctx_addr_i), .ctx_wr_data_i(prog_ctx_data_i),
        .start_i(start_i[g]), .program_words_i(program_words_i[g*(PC_W+1) +: (PC_W+1)]),
        .done_o(cluster_done_o[g]), .active_o(cluster_active_o[g]),
        .fault_o(cluster_fault_o[g]), .fault_code_o(cluster_fault_code_o[g*8 +: 8]),
        .barrier_req_o(barrier_req[g]), .barrier_token_o(barrier_token[g*16 +: 16]),
        .barrier_release_i(barrier_release[g]),
        .dma_req_valid_o(dma_req_valid_o[g]), .dma_req_ready_i(dma_req_ready_i[g]),
        .dma_src_cluster_o(dma_src_cluster_o[g*CLUSTER_ID_W +: CLUSTER_ID_W]),
        .dma_dst_cluster_o(dma_dst_cluster_o[g*CLUSTER_ID_W +: CLUSTER_ID_W]),
        .dma_src_local_o(dma_src_local_o[g*LOCAL_ADDR_W +: LOCAL_ADDR_W]),
        .dma_dst_local_o(dma_dst_local_o[g*LOCAL_ADDR_W +: LOCAL_ADDR_W]),
        .dma_len_vec_o(dma_len_vec_o[g*8 +: 8]),
        .dma_requester_pe_o(dma_requester_pe_o[g*2 +: 2]),
        .dma_tag_o(dma_tag_o[g*3 +: 3]), .dma_idle_i(dma_idle_i[g]),
        .qr_mem_req_valid_o(qr_mem_req_valid_o[g]), .qr_mem_req_ready_i(qr_mem_req_ready_i[g]),
        .qr_mem_req_write_o(qr_mem_req_write_o[g]),
        .qr_mem_req_addr_o(qr_mem_req_addr_o[g*LOCAL_ADDR_W +: LOCAL_ADDR_W]),
        .qr_mem_rsp_valid_i(qr_mem_rsp_valid_i[g]),
        .qr_mem_rsp_data_i(qr_mem_rsp_data_i[g*VECTOR_W +: VECTOR_W]),
        .pe_issue_valid_o(pe_issue_valid_o[g]), .pe_issue_ready_i(pe_issue_ready_i[g]),
        .pe_slots_o(pe_slots_o[g*36 +: 36]),
        .pe_param_id_o(pe_param_id_o[g*PARAM_ID_W +: PARAM_ID_W]),
        .pe_legacy_ctx_id_o(pe_legacy_ctx_id_o[g*3 +: 3]),
        .pe_immediate_o(pe_immediate_o[g*EXEC_IMM_W +: EXEC_IMM_W]),
        .pe_context_o(pe_context_o[g*CTX_W +: CTX_W]),
        .pe_param_valid_o(pe_param_valid_o[g]),
        .pe_param_vector_o(pe_param_vector_o[g*VECTOR_W +: VECTOR_W]),
        .pe_param_tag_o(pe_param_tag_o[g*PARAM_TAG_W +: PARAM_TAG_W]),
        .fir_agu_active_o(fir_agu_active_o[g]),
        .fir_k_group_o(fir_k_group_o[g*8 +: 8]),
        .fir_k_group_limit_o(fir_k_group_limit_o[g*8 +: 8]),
        .fir_x_valid_o(fir_x_valid_o[g*N_PE*LANES +: N_PE*LANES]),
        .fir_x_index_o(fir_x_index_o[g*N_PE*LANES*FIR_INDEX_W +: N_PE*LANES*FIR_INDEX_W]),
        .fir_h_valid_o(fir_h_valid_o[g*LANES +: LANES]),
        .fir_h_index_o(fir_h_index_o[g*LANES*FIR_TAPS_W +: LANES*FIR_TAPS_W]),
        .fir_sample_index_o(fir_sample_index_o[g*N_PE*FIR_SAMPLES_W +: N_PE*FIR_SAMPLES_W]),
        .pe_busy_i(pe_busy_i[g*N_PE +: N_PE]), .ru_busy_i(ru_busy_i[g]),
        .qr_target_valid_i(qr_target_valid_i[g*QR_TARGET_INPUT_VECS +: QR_TARGET_INPUT_VECS]),
        .qr_target_vectors_i(qr_target_vectors_i[g*QR_TARGET_INPUT_VECS*VECTOR_W +: QR_TARGET_INPUT_VECS*VECTOR_W]),
        .qr_target_reset_o(qr_target_reset_o[g]),
        .qr_pe_pairs_valid_o(qr_pe_pairs_valid_o[g]), .qr_pe_pairs_ready_i(qr_pe_pairs_ready_i[g]),
        .qr_pe_pairs_o(qr_pe_pairs_o[g*N_PE*VECTOR_W +: N_PE*VECTOR_W]),
        .cordic_qr_pair_valid_o(cordic_qr_pair_valid_o[g]),
        .cordic_qr_pivot_o(cordic_qr_pivot_o[g*LANE_W +: LANE_W]),
        .cordic_qr_target_o(cordic_qr_target_o[g*LANE_W +: LANE_W]),
        .cordic_req_valid_o(cordic_req_valid_o[g]), .cordic_req_ready_i(cordic_req_ready_i[g]),
        .cordic_mode_twiddle_o(cordic_mode_twiddle_o[g]),
        .cordic_twiddle_j_o(cordic_twiddle_j_o[g*16 +: 16]),
        .cordic_twiddle_m_log2_o(cordic_twiddle_m_log2_o[g*4 +: 4]),
        .cordic_param_id_o(cordic_param_id_o[g*PARAM_ID_W +: PARAM_ID_W]),
        .cordic_immediate_o(cordic_immediate_o[g*EXEC_IMM_W +: EXEC_IMM_W]),
        .cordic_context_o(cordic_context_o[g*CTX_W +: CTX_W]),
        .cordic_rsp_valid_i(cordic_rsp_valid_i[g]),
        .cordic_rsp_vector_i(cordic_rsp_vector_i[g*VECTOR_W +: VECTOR_W]),
        .cordic_rsp_cos_i(cordic_rsp_cos_i[g*LANE_W +: LANE_W]),
        .cordic_rsp_sin_i(cordic_rsp_sin_i[g*LANE_W +: LANE_W]),
        .cordic_idle_i(cordic_idle_i[g]),
        .ext_param_wr_valid_i(ext_param_wr_valid_i[g]), .ext_param_wr_ready_o(ext_param_wr_ready_o[g]),
        .ext_param_wr_op_i(param_write_op_e'(ext_param_wr_op_i[g*3 +: 3])),
        .ext_param_wr_pid_i(ext_param_wr_pid_i[g*PARAM_ID_W +: PARAM_ID_W]),
        .ext_param_wr_data_i(ext_param_wr_data_i[g*VECTOR_W +: VECTOR_W]),
        .ext_param_wr_pair_c_i(ext_param_wr_pair_c_i[g*LANE_W +: LANE_W]),
        .ext_param_wr_pair_s_i(ext_param_wr_pair_s_i[g*LANE_W +: LANE_W]),
        .ext_param_wr_tag_i(ext_param_wr_tag_i[g*PARAM_TAG_W +: PARAM_TAG_W]),
        .pe_result_valid_i(pe_result_valid_i[g*N_PE +: N_PE]),
        .pe_result_ready_o(pe_result_ready_o[g*N_PE +: N_PE]),
        .pe_result_data_i(pe_result_data_i[g*N_PE*VECTOR_W +: N_PE*VECTOR_W]),
        .pe_result_pid_i(pe_result_pid_i[g*N_PE*PARAM_ID_W +: N_PE*PARAM_ID_W]),
        .cordic_broadcast_valid_i(cordic_broadcast_valid_i[g]),
        .cordic_broadcast_ready_o(cordic_broadcast_ready_o[g]),
        .cordic_broadcast_data_i(cordic_broadcast_data_i[g*VECTOR_W +: VECTOR_W]),
        .cordic_broadcast_pid_i(cordic_broadcast_pid_i[g*PARAM_ID_W +: PARAM_ID_W]),
        .xbar_dst_valid_o(xbar_dst_valid_o[g*N_PE +: N_PE]),
        .xbar_dst_pop_i(xbar_dst_pop_i[g*N_PE +: N_PE]),
        .xbar_dst_data_o(xbar_dst_data_o[g*N_PE*VECTOR_W +: N_PE*VECTOR_W])
      );
    end
  endgenerate

endmodule
