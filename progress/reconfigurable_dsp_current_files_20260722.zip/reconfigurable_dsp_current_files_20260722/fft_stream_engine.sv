`timescale 1ns/1ps
import cgra_rtl_pkg::*;

// =============================================================================
// V4.1 block-distributed FFT stream engine, cluster-local resource controller.
//
// This block implements the hardware resources introduced by the latest model:
//   * two task/input-buffer sets;
//   * ParamRF A/B ownership paired with those sets;
//   * one shared 3-cycle/two-CMUL TEU;
//   * one in-flight four-PE CMUL bundle;
//   * two-entry result FIFO decoupling PE completion from RU/WBQ drain;
//   * one stage-close/drain indication for the single visibility barrier.
//
// DMA/NoC and the existing four PEs remain external architectural resources.
// Input-fill is the destination-visible event from local/DMA SRAM landing.
// Result-drain is consumed by the existing RU/WBQ path.  This separation keeps
// the engine cycle-accurate without duplicating the SMU or PE arithmetic.
// =============================================================================
module fft_stream_engine #(
  parameter int P_VECTOR_W = VECTOR_W,
  parameter int P_STAGE_W = 4,
  parameter int P_BATCH_W = 10,
  parameter int P_FIFO_DEPTH = FFT_STREAM_RESULT_FIFO_DEPTH
) (
  input  logic clk_i,
  input  logic rst_ni,

  // Compiler-generated affine FFT task descriptor.
  input  logic                      task_valid_i,
  output logic                      task_ready_o,
  output logic                      task_slot_o,
  input  logic signed [15:0]        task_seed_re_i,
  input  logic signed [15:0]        task_seed_im_i,
  input  logic signed [15:0]        task_step_re_i,
  input  logic signed [15:0]        task_step_im_i,
  // Destination-local addresses for the two packed output vectors.  The
  // compiler derives them from the dynamic block-owner map for this stage.
  input  logic [LOCAL_ADDR_W-1:0]   task_dst0_addr_i,
  input  logic [LOCAL_ADDR_W-1:0]   task_dst1_addr_i,

  // Two source vectors become valid independently as local/DMA landing commits.
  input  logic                      input_fill_valid_i,
  output logic                      input_fill_ready_o,
  input  logic                      input_fill_slot_i,
  input  logic                      input_fill_vector_i,
  input  logic [P_VECTOR_W-1:0]     input_fill_data_i,

  // Request to the existing four-PE CMUL bundle.  One request represents four
  // radix-2 butterflies and carries four twiddle pairs in architectural lanes.
  output logic                      pe_req_valid_o,
  input  logic                      pe_req_ready_i,
  output logic                      pe_req_slot_o,
  output logic [P_VECTOR_W-1:0]     pe_req_input0_o,
  output logic [P_VECTOR_W-1:0]     pe_req_input1_o,
  output logic [P_VECTOR_W-1:0]     pe_req_twiddles_o,

  // Completion from the PE/RU pack front end: two packed output vectors.
  input  logic                      pe_rsp_valid_i,
  output logic                      pe_rsp_ready_o,
  input  logic                      pe_rsp_slot_i,
  input  logic [P_VECTOR_W-1:0]     pe_rsp_result0_i,
  input  logic [P_VECTOR_W-1:0]     pe_rsp_result1_i,

  // Two-entry result FIFO to the existing RU/WBQ/SRAM visibility path.
  output logic                      result_valid_o,
  input  logic                      result_ready_i,
  output logic [P_VECTOR_W-1:0]     result_vec0_o,
  output logic [P_VECTOR_W-1:0]     result_vec1_o,
  output logic [LOCAL_ADDR_W-1:0]   result_dst0_addr_o,
  output logic [LOCAL_ADDR_W-1:0]   result_dst1_addr_o,

  // Assert after the compiler has submitted the final task in one stage.
  input  logic                      stage_close_i,
  output logic                      stage_done_o,
  output logic                      busy_o
);
  localparam int SLOT_COUNT = FFT_STREAM_INPUT_BUFFER_SETS;
  localparam int FIFO_PTR_W = (P_FIFO_DEPTH <= 1) ? 1 : $clog2(P_FIFO_DEPTH);
  localparam int FIFO_CNT_W = $clog2(P_FIFO_DEPTH + 1);

  logic [SLOT_COUNT-1:0] slot_valid_q;
  logic [SLOT_COUNT-1:0] twiddle_pending_q;
  logic [SLOT_COUNT-1:0] twiddle_valid_q;
  logic [SLOT_COUNT-1:0][1:0] input_valid_q;
  logic signed [SLOT_COUNT-1:0][15:0] seed_re_q, seed_im_q;
  logic signed [SLOT_COUNT-1:0][15:0] step_re_q, step_im_q;
  logic [SLOT_COUNT-1:0][LOCAL_ADDR_W-1:0] dst0_addr_q, dst1_addr_q;
  logic [SLOT_COUNT-1:0][1:0][P_VECTOR_W-1:0] input_q;
  logic [SLOT_COUNT-1:0][127:0] twiddle_pairs_q;

  logic task_free_found;
  logic task_free_slot;
  logic pe_candidate_found;
  logic pe_candidate_slot;

  logic teu_start_valid, teu_start_ready;
  logic teu_select_found, teu_select_slot;
  logic teu_active_q, teu_active_slot_q;
  logic teu_out_valid, teu_out_ready, teu_busy;
  logic [127:0] teu_twiddles;

  logic pe_inflight_q, pe_inflight_slot_q;

  logic [P_FIFO_DEPTH-1:0][P_VECTOR_W-1:0] fifo_vec0_q, fifo_vec1_q;
  logic [P_FIFO_DEPTH-1:0][LOCAL_ADDR_W-1:0] fifo_dst0_addr_q, fifo_dst1_addr_q;
  logic [FIFO_PTR_W-1:0] fifo_rd_ptr_q, fifo_wr_ptr_q;
  logic [FIFO_CNT_W-1:0] fifo_count_q;
  logic fifo_push, fifo_pop;
  logic stage_close_q;

  // Allocation and issue selection use deterministic slot 0 before slot 1.
  always_comb begin
    task_free_found = 1'b0;
    task_free_slot = 1'b0;
    pe_candidate_found = 1'b0;
    pe_candidate_slot = 1'b0;
    teu_select_found = 1'b0;
    teu_select_slot = 1'b0;
    for (int s = 0; s < SLOT_COUNT; s++) begin
      if (!task_free_found && !slot_valid_q[s]) begin
        task_free_found = 1'b1;
        task_free_slot = s[0];
      end
      if (!pe_candidate_found && slot_valid_q[s] && twiddle_valid_q[s] &&
          (&input_valid_q[s])) begin
        pe_candidate_found = 1'b1;
        pe_candidate_slot = s[0];
      end
      if (!teu_select_found && slot_valid_q[s] && twiddle_pending_q[s]) begin
        teu_select_found = 1'b1;
        teu_select_slot = s[0];
      end
    end
  end

  assign task_ready_o = task_free_found && !stage_close_q;
  assign task_slot_o = task_free_slot;
  assign input_fill_ready_o = slot_valid_q[input_fill_slot_i] &&
                              !input_valid_q[input_fill_slot_i][input_fill_vector_i];

  assign teu_start_valid = teu_select_found && !teu_active_q;
  assign teu_out_ready = 1'b1;

  fft_twiddle_expansion_unit u_teu (
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .start_valid_i(teu_start_valid),
    .start_ready_o(teu_start_ready),
    .seed_re_i(seed_re_q[teu_select_slot]),
    .seed_im_i(seed_im_q[teu_select_slot]),
    .step_re_i(step_re_q[teu_select_slot]),
    .step_im_i(step_im_q[teu_select_slot]),
    .out_valid_o(teu_out_valid),
    .out_ready_i(teu_out_ready),
    .twiddles_o(teu_twiddles),
    .busy_o(teu_busy)
  );

  assign pe_req_valid_o = pe_candidate_found && !pe_inflight_q;
  assign pe_req_slot_o = pe_candidate_slot;
  assign pe_req_input0_o = input_q[pe_candidate_slot][0];
  assign pe_req_input1_o = input_q[pe_candidate_slot][1];

  // Expand compact Q1.15 pairs into signed 32-bit architectural containers.
  always_comb begin
    pe_req_twiddles_o = '0;
    for (int lane = 0; lane < 8; lane++) begin
      pe_req_twiddles_o[lane*32 +: 32] =
        {{16{twiddle_pairs_q[pe_candidate_slot][lane*16+15]}},
          twiddle_pairs_q[pe_candidate_slot][lane*16 +: 16]};
    end
  end

  assign result_valid_o = (fifo_count_q != 0);
  assign result_vec0_o = fifo_vec0_q[fifo_rd_ptr_q];
  assign result_vec1_o = fifo_vec1_q[fifo_rd_ptr_q];
  assign result_dst0_addr_o = fifo_dst0_addr_q[fifo_rd_ptr_q];
  assign result_dst1_addr_o = fifo_dst1_addr_q[fifo_rd_ptr_q];
  assign fifo_pop = result_valid_o && result_ready_i;

  // Permit a PE result to replace a simultaneously drained full FIFO entry.
  assign pe_rsp_ready_o = pe_inflight_q &&
                          (pe_rsp_slot_i == pe_inflight_slot_q) &&
                          ((fifo_count_q < P_FIFO_DEPTH) || fifo_pop);
  assign fifo_push = pe_rsp_valid_i && pe_rsp_ready_o;

  assign busy_o = (|slot_valid_q) || teu_active_q || teu_busy || pe_inflight_q ||
                  (fifo_count_q != 0) || stage_close_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      slot_valid_q <= '0;
      twiddle_pending_q <= '0;
      twiddle_valid_q <= '0;
      input_valid_q <= '0;
      seed_re_q <= '0;
      seed_im_q <= '0;
      step_re_q <= '0;
      step_im_q <= '0;
      dst0_addr_q <= '0;
      dst1_addr_q <= '0;
      input_q <= '0;
      twiddle_pairs_q <= '0;
      teu_active_q <= 1'b0;
      teu_active_slot_q <= 1'b0;
      pe_inflight_q <= 1'b0;
      pe_inflight_slot_q <= 1'b0;
      fifo_vec0_q <= '0;
      fifo_vec1_q <= '0;
      fifo_dst0_addr_q <= '0;
      fifo_dst1_addr_q <= '0;
      fifo_rd_ptr_q <= '0;
      fifo_wr_ptr_q <= '0;
      fifo_count_q <= '0;
      stage_close_q <= 1'b0;
      stage_done_o <= 1'b0;
    end else begin
      stage_done_o <= 1'b0;

      if (task_valid_i && task_ready_o) begin
        slot_valid_q[task_free_slot] <= 1'b1;
        twiddle_pending_q[task_free_slot] <= 1'b1;
        twiddle_valid_q[task_free_slot] <= 1'b0;
        input_valid_q[task_free_slot] <= 2'b00;
        seed_re_q[task_free_slot] <= task_seed_re_i;
        seed_im_q[task_free_slot] <= task_seed_im_i;
        step_re_q[task_free_slot] <= task_step_re_i;
        step_im_q[task_free_slot] <= task_step_im_i;
        dst0_addr_q[task_free_slot] <= task_dst0_addr_i;
        dst1_addr_q[task_free_slot] <= task_dst1_addr_i;
      end

      if (input_fill_valid_i && input_fill_ready_o) begin
        input_q[input_fill_slot_i][input_fill_vector_i] <= input_fill_data_i;
        input_valid_q[input_fill_slot_i][input_fill_vector_i] <= 1'b1;
      end

      if (teu_start_valid && teu_start_ready) begin
        teu_active_q <= 1'b1;
        teu_active_slot_q <= teu_select_slot;
        twiddle_pending_q[teu_select_slot] <= 1'b0;
      end
      if (teu_out_valid) begin
        twiddle_pairs_q[teu_active_slot_q] <= teu_twiddles;
        twiddle_valid_q[teu_active_slot_q] <= 1'b1;
        teu_active_q <= 1'b0;
      end

      if (pe_req_valid_o && pe_req_ready_i) begin
        pe_inflight_q <= 1'b1;
        pe_inflight_slot_q <= pe_candidate_slot;
        input_valid_q[pe_candidate_slot] <= 2'b00;
        twiddle_valid_q[pe_candidate_slot] <= 1'b0;
      end

      if (fifo_push) begin
        // A mismatching response slot is not retired; the producer must preserve
        // the architectural request tag until acceptance.
        if (pe_rsp_slot_i == pe_inflight_slot_q) begin
          fifo_vec0_q[fifo_wr_ptr_q] <= pe_rsp_result0_i;
          fifo_vec1_q[fifo_wr_ptr_q] <= pe_rsp_result1_i;
          fifo_dst0_addr_q[fifo_wr_ptr_q] <= dst0_addr_q[pe_inflight_slot_q];
          fifo_dst1_addr_q[fifo_wr_ptr_q] <= dst1_addr_q[pe_inflight_slot_q];
          slot_valid_q[pe_inflight_slot_q] <= 1'b0;
          pe_inflight_q <= 1'b0;
          if (fifo_wr_ptr_q == P_FIFO_DEPTH-1)
            fifo_wr_ptr_q <= '0;
          else
            fifo_wr_ptr_q <= fifo_wr_ptr_q + FIFO_PTR_W'(1);
        end
      end

      if (fifo_pop) begin
        if (fifo_rd_ptr_q == P_FIFO_DEPTH-1)
          fifo_rd_ptr_q <= '0;
        else
          fifo_rd_ptr_q <= fifo_rd_ptr_q + FIFO_PTR_W'(1);
      end

      unique case ({fifo_push && (pe_rsp_slot_i == pe_inflight_slot_q), fifo_pop})
        2'b10: fifo_count_q <= fifo_count_q + FIFO_CNT_W'(1);
        2'b01: fifo_count_q <= fifo_count_q - FIFO_CNT_W'(1);
        default: begin end
      endcase

      if (stage_close_i)
        stage_close_q <= 1'b1;
      if (stage_close_q && !(|slot_valid_q) && !teu_active_q && !teu_busy &&
          !pe_inflight_q && (fifo_count_q == 0)) begin
        stage_done_o <= 1'b1;
        stage_close_q <= 1'b0;
      end
    end
  end
endmodule
