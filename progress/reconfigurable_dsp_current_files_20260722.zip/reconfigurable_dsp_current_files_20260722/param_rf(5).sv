`timescale 1ns/1ps
import cgra_rtl_pkg::*;

// Area-optimized Shared ParamRF.
//
// Architectural interface remains 16 x 256-bit.  The workload datapath stores
// signed Q1.15 values in 32-bit lane containers, so only the significant
// P_VALUE_W bits are physically registered per lane and reads sign-extend back
// to the architectural lane width.  This preserves PID, Valid and QR tag
// behavior while halving the dominant data-array register count.
module param_rf #(
  parameter int P_ENTRIES = PARAM_ENTRIES,
  parameter int P_VECTOR_W = VECTOR_W,
  parameter int P_TAG_W = PARAM_TAG_W,
  parameter int P_VALUE_W = PARAM_VALUE_W
) (
  input  logic clk_i,
  input  logic rst_ni,

  input  logic [PARAM_ID_W-1:0] rd_pid_i,
  input  logic                  rd_expected_tag_valid_i,
  input  logic [P_TAG_W-1:0]    rd_expected_tag_i,
  output logic                  rd_ready_o,
  output logic [P_VECTOR_W-1:0] rd_data_o,
  output logic [P_TAG_W-1:0]    rd_tag_o,
  output logic                  rd_valid_o,

  input  logic                  wr_valid_i,
  output logic                  wr_ready_o,
  input  param_write_op_e       wr_op_i,
  input  logic [PARAM_ID_W-1:0] wr_pid_i,
  input  logic [P_VECTOR_W-1:0] wr_data_i,
  input  logic [LANE_W-1:0]     wr_pair_c_i,
  input  logic [LANE_W-1:0]     wr_pair_s_i,
  input  logic [1:0]            wr_pair_slot_i,
  input  logic [P_TAG_W-1:0]    wr_tag_i,
  input  logic                  invalidate_clear_tag_i
);

  localparam int P_COMPACT_W = LANES * P_VALUE_W;

  logic [P_COMPACT_W-1:0] data_q [P_ENTRIES];
  logic [P_ENTRIES-1:0] valid_q;
  logic [P_ENTRIES-1:0] reserved_q;
  logic [P_TAG_W-1:0] tag_q [P_ENTRIES];
  logic [P_COMPACT_W-1:0] replicated_pair_compact;
  integer lane;

  function automatic logic [P_COMPACT_W-1:0] compact_vector(
      input logic [P_VECTOR_W-1:0] vector_i
  );
    logic [P_COMPACT_W-1:0] packed;
    integer l;
    begin
      packed = '0;
      for (l = 0; l < LANES; l = l + 1)
        packed[l*P_VALUE_W +: P_VALUE_W] =
            vector_i[l*LANE_W +: P_VALUE_W];
      compact_vector = packed;
    end
  endfunction

  function automatic logic [P_VECTOR_W-1:0] expand_vector(
      input logic [P_COMPACT_W-1:0] packed_i
  );
    logic [P_VECTOR_W-1:0] vector;
    logic signed [P_VALUE_W-1:0] value;
    integer l;
    begin
      vector = '0;
      for (l = 0; l < LANES; l = l + 1) begin
        value = packed_i[l*P_VALUE_W +: P_VALUE_W];
        vector[l*LANE_W +: LANE_W] = $signed(value);
      end
      expand_vector = vector;
    end
  endfunction

  always_comb begin
    replicated_pair_compact = '0;
    for (lane = 0; lane < LANES; lane = lane + 2) begin
      replicated_pair_compact[lane*P_VALUE_W +: P_VALUE_W] =
          wr_pair_c_i[P_VALUE_W-1:0];
      replicated_pair_compact[(lane+1)*P_VALUE_W +: P_VALUE_W] =
          wr_pair_s_i[P_VALUE_W-1:0];
    end

    rd_data_o = expand_vector(data_q[rd_pid_i]);
    rd_tag_o = tag_q[rd_pid_i];
    rd_valid_o = valid_q[rd_pid_i];
    rd_ready_o = valid_q[rd_pid_i] &&
                 (!rd_expected_tag_valid_i ||
                  (tag_q[rd_pid_i] == rd_expected_tag_i));

    wr_ready_o = 1'b1;
    if (wr_valid_i && (wr_op_i == PRF_WRITE_TAGGED_PAIR))
      wr_ready_o = reserved_q[wr_pid_i] &&
                   (tag_q[wr_pid_i] == wr_tag_i);
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      // data_q/tag_q intentionally do not reset.  valid_q/reserved_q gate every
      // architectural read and tagged write, avoiding thousands of resettable
      // data flops and their reset distribution without exposing stale data.
      valid_q <= '0;
      reserved_q <= '0;
    end else if (wr_valid_i && wr_ready_o) begin
      case (wr_op_i)
        PRF_WRITE_VECTOR: begin
          data_q[wr_pid_i] <= compact_vector(wr_data_i);
          valid_q[wr_pid_i] <= 1'b1;
          reserved_q[wr_pid_i] <= 1'b0;
          tag_q[wr_pid_i] <= '0;
        end
        PRF_RESERVE_TAG: begin
          valid_q[wr_pid_i] <= 1'b0;
          reserved_q[wr_pid_i] <= 1'b1;
          tag_q[wr_pid_i] <= wr_tag_i;
        end
        PRF_WRITE_TAGGED_PAIR: begin
          data_q[wr_pid_i] <= replicated_pair_compact;
          valid_q[wr_pid_i] <= 1'b1;
          reserved_q[wr_pid_i] <= 1'b0;
          tag_q[wr_pid_i] <= wr_tag_i;
        end
        PRF_WRITE_PAIR_SLOT: begin
          data_q[wr_pid_i][(2*wr_pair_slot_i)*P_VALUE_W +: P_VALUE_W]
              <= wr_pair_c_i[P_VALUE_W-1:0];
          data_q[wr_pid_i][(2*wr_pair_slot_i+1)*P_VALUE_W +: P_VALUE_W]
              <= wr_pair_s_i[P_VALUE_W-1:0];
          valid_q[wr_pid_i] <= 1'b1;
          reserved_q[wr_pid_i] <= 1'b0;
          tag_q[wr_pid_i] <= '0;
        end
        PRF_INVALIDATE: begin
          valid_q[wr_pid_i] <= 1'b0;
          if (invalidate_clear_tag_i) begin
            reserved_q[wr_pid_i] <= 1'b0;
            tag_q[wr_pid_i] <= '0;
          end
        end
        default: begin end
      endcase
    end
  end
endmodule : param_rf
