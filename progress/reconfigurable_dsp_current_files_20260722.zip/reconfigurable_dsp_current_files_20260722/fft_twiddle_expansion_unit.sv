`timescale 1ns/1ps

// =============================================================================
// V4.1 Twiddle Expansion Unit (TEU)
//
// Expands one CORDIC seed W0 and one recurrence step S into four Q1.15
// twiddles: W0, W1=W0*S, W2=W0*S^2, W3=W1*S^2.
//
// The datapath contains exactly two reusable complex multipliers:
//   cycle 1: CMUL0=W0*S,   CMUL1=S*S
//   cycle 2: CMUL0=W0*S^2, CMUL1=W1*S^2
//   cycle 3: registered result becomes valid
// This is the 3-cycle/two-complex-multiplier resource modeled by the V4.1
// block-distributed FFT streaming scheduler.
// =============================================================================
module fft_q15_complex_mul (
  input  logic signed [15:0] a_re_i,
  input  logic signed [15:0] a_im_i,
  input  logic signed [15:0] b_re_i,
  input  logic signed [15:0] b_im_i,
  output logic signed [15:0] y_re_o,
  output logic signed [15:0] y_im_o
);
  localparam logic signed [63:0] Q_MAX_C   = 64'sd32767;
  localparam logic signed [63:0] Q_MIN_C   = -64'sd32768;
  localparam logic signed [63:0] Q_ROUND_C = 64'sd16384;

  logic signed [31:0] ac, bd, ad, bc;
  logic signed [63:0] re_round, im_round;

  function automatic logic signed [15:0] sat_q15(input logic signed [63:0] value);
    if (value > Q_MAX_C)
      sat_q15 = 16'sd32767;
    else if (value < Q_MIN_C)
      sat_q15 = 16'sh8000;
    else
      sat_q15 = value[15:0];
  endfunction

  always_comb begin
    ac = a_re_i * b_re_i;
    bd = a_im_i * b_im_i;
    ad = a_re_i * b_im_i;
    bc = a_im_i * b_re_i;
    re_round = ($signed(ac) - $signed(bd) + Q_ROUND_C) >>> 15;
    im_round = ($signed(ad) + $signed(bc) + Q_ROUND_C) >>> 15;
    y_re_o = sat_q15(re_round);
    y_im_o = sat_q15(im_round);
  end
endmodule

module fft_twiddle_expansion_unit (
  input  logic clk_i,
  input  logic rst_ni,

  input  logic start_valid_i,
  output logic start_ready_o,
  input  logic signed [15:0] seed_re_i,
  input  logic signed [15:0] seed_im_i,
  input  logic signed [15:0] step_re_i,
  input  logic signed [15:0] step_im_i,

  output logic out_valid_o,
  input  logic out_ready_i,
  // Pair k occupies [k*32 +: 32] = {imag[15:0], real[15:0]}.
  output logic [127:0] twiddles_o,
  output logic busy_o
);
  typedef enum logic [1:0] {TEU_IDLE, TEU_CYCLE1, TEU_CYCLE2, TEU_OUTPUT} teu_state_e;
  teu_state_e state_q;

  logic signed [15:0] seed_re_q, seed_im_q;
  logic signed [15:0] step_re_q, step_im_q;
  logic signed [15:0] w1_re_q, w1_im_q;
  logic signed [15:0] step2_re_q, step2_im_q;
  logic signed [15:0] w2_re_q, w2_im_q;
  logic signed [15:0] w3_re_q, w3_im_q;

  logic signed [15:0] cmul0_a_re, cmul0_a_im, cmul0_b_re, cmul0_b_im;
  logic signed [15:0] cmul1_a_re, cmul1_a_im, cmul1_b_re, cmul1_b_im;
  logic signed [15:0] cmul0_y_re, cmul0_y_im;
  logic signed [15:0] cmul1_y_re, cmul1_y_im;

  always_comb begin
    cmul0_a_re = seed_re_q;
    cmul0_a_im = seed_im_q;
    cmul0_b_re = step_re_q;
    cmul0_b_im = step_im_q;
    cmul1_a_re = step_re_q;
    cmul1_a_im = step_im_q;
    cmul1_b_re = step_re_q;
    cmul1_b_im = step_im_q;

    if (state_q == TEU_CYCLE2) begin
      cmul0_a_re = seed_re_q;
      cmul0_a_im = seed_im_q;
      cmul0_b_re = step2_re_q;
      cmul0_b_im = step2_im_q;
      cmul1_a_re = w1_re_q;
      cmul1_a_im = w1_im_q;
      cmul1_b_re = step2_re_q;
      cmul1_b_im = step2_im_q;
    end
  end

  fft_q15_complex_mul u_cmul0 (
    .a_re_i(cmul0_a_re), .a_im_i(cmul0_a_im),
    .b_re_i(cmul0_b_re), .b_im_i(cmul0_b_im),
    .y_re_o(cmul0_y_re), .y_im_o(cmul0_y_im)
  );

  fft_q15_complex_mul u_cmul1 (
    .a_re_i(cmul1_a_re), .a_im_i(cmul1_a_im),
    .b_re_i(cmul1_b_re), .b_im_i(cmul1_b_im),
    .y_re_o(cmul1_y_re), .y_im_o(cmul1_y_im)
  );

  assign start_ready_o = (state_q == TEU_IDLE);
  assign out_valid_o = (state_q == TEU_OUTPUT);
  assign busy_o = (state_q != TEU_IDLE);

  always_comb begin
    twiddles_o = '0;
    twiddles_o[0*32 +: 16] = seed_re_q;
    twiddles_o[0*32+16 +: 16] = seed_im_q;
    twiddles_o[1*32 +: 16] = w1_re_q;
    twiddles_o[1*32+16 +: 16] = w1_im_q;
    twiddles_o[2*32 +: 16] = w2_re_q;
    twiddles_o[2*32+16 +: 16] = w2_im_q;
    twiddles_o[3*32 +: 16] = w3_re_q;
    twiddles_o[3*32+16 +: 16] = w3_im_q;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q <= TEU_IDLE;
      seed_re_q <= '0;
      seed_im_q <= '0;
      step_re_q <= '0;
      step_im_q <= '0;
      w1_re_q <= '0;
      w1_im_q <= '0;
      step2_re_q <= '0;
      step2_im_q <= '0;
      w2_re_q <= '0;
      w2_im_q <= '0;
      w3_re_q <= '0;
      w3_im_q <= '0;
    end else begin
      case (state_q)
        TEU_IDLE: begin
          if (start_valid_i) begin
            seed_re_q <= seed_re_i;
            seed_im_q <= seed_im_i;
            step_re_q <= step_re_i;
            step_im_q <= step_im_i;
            state_q <= TEU_CYCLE1;
          end
        end
        TEU_CYCLE1: begin
          w1_re_q <= cmul0_y_re;
          w1_im_q <= cmul0_y_im;
          step2_re_q <= cmul1_y_re;
          step2_im_q <= cmul1_y_im;
          state_q <= TEU_CYCLE2;
        end
        TEU_CYCLE2: begin
          w2_re_q <= cmul0_y_re;
          w2_im_q <= cmul0_y_im;
          w3_re_q <= cmul1_y_re;
          w3_im_q <= cmul1_y_im;
          state_q <= TEU_OUTPUT;
        end
        TEU_OUTPUT: begin
          if (out_ready_i)
            state_q <= TEU_IDLE;
        end
        default: state_q <= TEU_IDLE;
      endcase
    end
  end
endmodule
