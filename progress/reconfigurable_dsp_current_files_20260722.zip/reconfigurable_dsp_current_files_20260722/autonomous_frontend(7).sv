`timescale 1ns/1ps
import cgra_rtl_pkg::*;

module autonomous_frontend #(
  parameter int P_PC_W = PC_W,
  parameter int P_IMEM_DEPTH = IMEM_DEPTH,
  parameter int P_CTX_DEPTH = CTX_DEPTH,
  parameter int P_Q_DEPTH = FRONTEND_Q_DEPTH
) (
  input  logic clk_i,
  input  logic rst_ni,

  // External synchronous RAM interfaces. The RAM wrappers/macros are
  // instantiated outside this frontend. rd_valid_i must align with rd_data_i.
  output logic                  imem_rd_en_o,
  output logic [P_PC_W-1:0]     imem_rd_addr_o,
  input  logic [63:0]           imem_rd_data_i,
  input  logic                  imem_rd_valid_i,
  output logic                  ctx_rd_en_o,
  output logic [CTX_ADDR_W-1:0] ctx_rd_addr_o,
  input  logic [CTX_W-1:0]      ctx_rd_data_i,
  input  logic                  ctx_rd_valid_i,

  input  logic                  start_i,
  input  logic [P_PC_W:0]       program_words_i,
  output logic                  active_o,
  output logic                  done_o,
  output logic                  fault_o,
  output logic [7:0]            fault_code_o,

  // Program-order issue interface.  Context and instruction are held stable
  // while issue_ready_i is low; no refetch or reread occurs.
  output logic                  issue_valid_o,
  input  logic                  issue_ready_i,
  output logic [P_PC_W-1:0]     issue_pc_o,
  output logic [63:0]           issue_instr_o,
  output logic [CTX_W-1:0]      issue_ctx_o,

  // Synchronization/resource state used by the six wait policies.
  input  logic                  dma_idle_i,
  input  logic                  local_quiescent_i,
  input  logic                  all_units_idle_i,
  // Cluster-level decode / legality faults are latched by the frontend so a
  // malformed resident image terminates rather than holding issue forever.
  input  logic                  resource_fault_i,
  input  logic [7:0]            resource_fault_code_i,
  output logic                  barrier_req_o,
  output logic [15:0]           barrier_token_o,
  input  logic                  barrier_release_i
);

  localparam int Q_PTR_W = (P_Q_DEPTH <= 1) ? 1 : $clog2(P_Q_DEPTH);
  localparam int Q_CNT_W = $clog2(P_Q_DEPTH + 1);

  logic [63:0] q_instr_q [P_Q_DEPTH];
  logic [CTX_W-1:0] q_ctx_q [P_Q_DEPTH];
  logic [P_PC_W-1:0] q_pc_q [P_Q_DEPTH];
  logic [P_Q_DEPTH-1:0] q_ctx_valid_q, q_ctx_requested_q;
  logic [Q_PTR_W-1:0] q_head_q, q_tail_q;
  logic [Q_CNT_W-1:0] q_count_q;

  logic if_req_valid_q;
  logic [P_PC_W-1:0] if_req_pc_q;
  logic [P_PC_W-1:0] if_rsp_pc_q;
  logic ctx_req_valid_q;
  logic [CTX_ADDR_W-1:0] ctx_req_idx_q;
  logic [Q_PTR_W-1:0] ctx_req_slot_q;
  logic [Q_PTR_W-1:0] ctx_rsp_slot_q;

  logic [P_PC_W:0] fetch_pc_q;
  logic [P_PC_W-1:0] barrier_resume_pc_q;
  logic barrier_waiting_q, halt_seen_q, active_q, done_q, fault_q;
  logic [15:0] barrier_token_q;

  logic head_valid;
  logic [63:0] head_instr;
  logic [CTX_W-1:0] head_ctx;
  logic head_ctx_valid;
  isa_opcode_e head_opcode;
  sync_flag_e head_sync;
  logic head_requires_ctx;
  logic sync_ready;
  logic exec_opcode;
  logic internal_retire;
  logic exec_retire;
  logic retire_event;
  logic barrier_enter;
  logic halt_enter;
  logic cfg_enter;
  logic normal_pop;
  logic flush_redirect, flush_barrier, flush_halt;
  logic any_flush;

  logic zol_cfg_valid;
  logic zol_cfg_error;
  logic zol_retire_valid;
  logic zol_redirect_valid;
  logic [P_PC_W-1:0] zol_redirect_pc;
  logic zol_barrier_clear;
  logic [LOOP_COUNT-1:0] zol_loop_active;

  logic ctx_select_valid;
  logic [Q_PTR_W-1:0] ctx_select_slot;
  logic [CTX_ADDR_W-1:0] ctx_select_idx;
  integer n, slot_i;
  integer reserved_entries;
  logic launch_ifetch;
  logic [P_PC_W-1:0] launch_ifetch_pc;
  logic [Q_CNT_W-1:0] next_q_count;

  function automatic logic instr_requires_context(input isa_opcode_e op);
    instr_requires_context = (op == ISA_EXEC_CONTEXT) ||
                             (op == ISA_EXEC_CORDIC) ||
                             (op == ISA_EXEC_SYNC) ||
                             (op == ISA_EXEC_DMA_DIRECT);
  endfunction

  function automatic logic opcode_is_known(input isa_opcode_e op);
    opcode_is_known = (op == ISA_NOP) || (op == ISA_RESERVED_01) ||
                      (op == ISA_CFG_LOOP) || (op == ISA_EXEC_CONTEXT) ||
                      (op == ISA_EXEC_CORDIC) || (op == ISA_RESERVED_12) ||
                      (op == ISA_EXEC_SYNC) || (op == ISA_EXEC_DMA_DIRECT) ||
                      (op == ISA_HALT);
  endfunction

  function automatic logic context_has_illegal_encoding(input logic [CTX_W-1:0] ctx);
    logic [8:0] s;
    int k;
    begin
      context_has_illegal_encoding = (ctx[CTX_RSVD_AGU_LSB +: 3] != 3'b000);
      for (k = 0; k < N_PE; k++) begin
        s = ctx[k*9 +: 9];
        if ((pe_dir_e'(s[5:3]) == DIR_RESERVED) ||
            (pe_dir_e'(s[2:0]) == DIR_RESERVED) ||
            (pe_op_e'(s[8:6]) == PE_CVEC_RSVD))
          context_has_illegal_encoding = 1'b1;
      end
    end
  endfunction

  always_comb begin
    // Requests are accepted by fixed-latency synchronous RAM wrappers.
    // Suppress requests on flush/start cycles so no stale RAM response can
    // re-enter the queue after control-flow redirection or restart.
    imem_rd_en_o = if_req_valid_q && !any_flush && !start_i;
    imem_rd_addr_o = if_req_pc_q;
    ctx_rd_en_o = ctx_req_valid_q && !any_flush && !start_i;
    ctx_rd_addr_o = ctx_req_idx_q;

    head_valid = (q_count_q != 0);
    head_instr = q_instr_q[q_head_q];
    head_ctx = q_ctx_q[q_head_q];
    head_ctx_valid = q_ctx_valid_q[q_head_q];
    head_opcode = isa_opcode_e'(head_instr[63:58]);
    head_sync = (head_opcode == ISA_EXEC_DMA_DIRECT) ?
                sync_flag_e'(head_instr[6:5]) : sync_flag_e'(head_instr[40:39]);
    head_requires_ctx = instr_requires_context(head_opcode);

    issue_pc_o = q_pc_q[q_head_q];
    issue_instr_o = head_instr;
    issue_ctx_o = head_ctx;
    exec_opcode = (head_opcode == ISA_EXEC_CONTEXT) ||
                  (head_opcode == ISA_EXEC_CORDIC) ||
                  (head_opcode == ISA_EXEC_DMA_DIRECT);

    sync_ready = 1'b1;
    case (head_sync)
      SYNC_WAIT_DMA_DONE: sync_ready = dma_idle_i;
      SYNC_WAIT_LOCAL_QUIESCENT: sync_ready = local_quiescent_i;
      SYNC_GLOBAL_BARRIER: sync_ready = 1'b0;
      default: sync_ready = 1'b1;
    endcase

    issue_valid_o = active_q && !barrier_waiting_q && !halt_seen_q &&
                    head_valid && (!head_requires_ctx || head_ctx_valid) &&
                    exec_opcode;
    exec_retire = issue_valid_o && issue_ready_i;
    cfg_enter = active_q && head_valid && (head_opcode == ISA_CFG_LOOP);
    barrier_enter = active_q && !barrier_waiting_q && head_valid &&
                    (head_opcode == ISA_EXEC_SYNC) &&
                    (!head_requires_ctx || head_ctx_valid) &&
                    (head_sync == SYNC_GLOBAL_BARRIER);
    halt_enter = active_q && head_valid && (head_opcode == ISA_HALT);
    internal_retire = active_q && !barrier_waiting_q && head_valid &&
                      ((!head_requires_ctx || head_ctx_valid)) &&
                      ((head_opcode == ISA_NOP) || cfg_enter ||
                       ((head_opcode == ISA_EXEC_SYNC) &&
                        (head_sync != SYNC_GLOBAL_BARRIER) && sync_ready));
    retire_event = exec_retire || internal_retire;

    zol_cfg_valid = cfg_enter;
    zol_retire_valid = retire_event;
    zol_barrier_clear = barrier_enter;
    flush_redirect = retire_event && zol_redirect_valid;
    flush_barrier = barrier_enter;
    flush_halt = halt_enter;
    any_flush = flush_redirect || flush_barrier || flush_halt;
    normal_pop = retire_event && !flush_redirect;

    // A cluster may enter the barrier while already-issued work is still
    // draining, but it must not advertise arrival to the global barrier
    // until every local architectural side effect is visible.
    barrier_req_o = barrier_waiting_q && local_quiescent_i;
    barrier_token_o = barrier_token_q;
    active_o = active_q;
    done_o = done_q;
    fault_o = fault_q;

    // Oldest missing context, one request per cycle.  Independent Context RAM
    // and Instruction RAM requests may launch together.
    ctx_select_valid = 1'b0;
    ctx_select_slot = '0;
    ctx_select_idx = '0;
    for (n = 0; n < P_Q_DEPTH; n++) begin
      slot_i = (int'(q_head_q) + n) % P_Q_DEPTH;
      if (!ctx_select_valid && (n < q_count_q) &&
          instr_requires_context(isa_opcode_e'(q_instr_q[slot_i][63:58])) &&
          !q_ctx_valid_q[slot_i] && !q_ctx_requested_q[slot_i]) begin
        ctx_select_valid = 1'b1;
        ctx_select_slot = Q_PTR_W'(slot_i);
        ctx_select_idx = q_instr_q[slot_i][57:53];
      end
    end

    // Reserve space for both the response arriving this cycle and the request
    // currently presented to the one-cycle RAM.
    reserved_entries = int'(q_count_q) + (imem_rd_valid_i ? 1 : 0) +
                       (imem_rd_en_o ? 1 : 0) -
                       ((normal_pop && !any_flush) ? 1 : 0);
    launch_ifetch = active_q && !barrier_waiting_q && !halt_seen_q &&
                    !any_flush && (fetch_pc_q < program_words_i) &&
                    (reserved_entries < P_Q_DEPTH);
    launch_ifetch_pc = fetch_pc_q[P_PC_W-1:0];
    next_q_count = q_count_q;
    if (imem_rd_valid_i && !normal_pop) next_q_count = q_count_q + Q_CNT_W'(1);
    else if (!imem_rd_valid_i && normal_pop) next_q_count = q_count_q - Q_CNT_W'(1);
  end

  zol_controller u_zol (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .cfg_valid_i(zol_cfg_valid),
    .cfg_loop_id_i(head_instr[57:54]),
    .cfg_iterations_i(head_instr[53:38]),
    .cfg_start_pc_i(head_instr[22 +: P_PC_W]),
    .cfg_end_pc_i(head_instr[6 +: P_PC_W]),
    .cfg_flags_i(head_instr[5:0]),
    .cfg_error_o(zol_cfg_error),
    .retire_valid_i(zol_retire_valid),
    .retire_pc_i(issue_pc_o),
    .redirect_valid_o(zol_redirect_valid),
    .redirect_pc_o(zol_redirect_pc),
    .barrier_clear_i(zol_barrier_clear),
    .loop_active_o(zol_loop_active)
  );

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      q_head_q <= '0;
      q_tail_q <= '0;
      q_count_q <= '0;
      q_ctx_valid_q <= '0;
      q_ctx_requested_q <= '0;
      if_req_valid_q <= 1'b0;
      if_req_pc_q <= '0;
      if_rsp_pc_q <= '0;
      ctx_req_valid_q <= 1'b0;
      ctx_req_idx_q <= '0;
      ctx_req_slot_q <= '0;
      ctx_rsp_slot_q <= '0;
      fetch_pc_q <= '0;
      barrier_resume_pc_q <= '0;
      barrier_waiting_q <= 1'b0;
      barrier_token_q <= '0;
      halt_seen_q <= 1'b0;
      active_q <= 1'b0;
      done_q <= 1'b0;
      fault_q <= 1'b0;
      fault_code_o <= '0;
      for (n = 0; n < P_Q_DEPTH; n++) begin
        q_instr_q[n] <= '0;
        q_ctx_q[n] <= '0;
        q_pc_q[n] <= '0;
      end
    end else begin

      if (start_i) begin
        q_head_q <= '0;
        q_tail_q <= '0;
        q_count_q <= '0;
        q_ctx_valid_q <= '0;
        q_ctx_requested_q <= '0;
        ctx_req_valid_q <= 1'b0;
        barrier_waiting_q <= 1'b0;
        halt_seen_q <= 1'b0;
        done_q <= 1'b0;
        if (program_words_i > (P_PC_W+1)'(P_IMEM_DEPTH)) begin
          if_req_valid_q <= 1'b0;
          fetch_pc_q <= '0;
          active_q <= 1'b0;
          fault_q <= 1'b1;
          fault_code_o <= 8'h10;
        end else begin
          if_req_valid_q <= (program_words_i != 0);
          if_req_pc_q <= '0;
          fetch_pc_q <= (program_words_i != 0) ? (P_PC_W+1)'(1) : '0;
          active_q <= (program_words_i != 0);
          done_q <= (program_words_i == 0);
          fault_q <= 1'b0;
          fault_code_o <= '0;
        end
      end else if (active_q) begin
        if (resource_fault_i) begin
          fault_q <= 1'b1;
          fault_code_o <= resource_fault_code_i;
          active_q <= 1'b0;
        end else if (zol_cfg_error) begin
          fault_q <= 1'b1;
          fault_code_o <= 8'h01;
          active_q <= 1'b0;
        end else if (head_valid && !opcode_is_known(head_opcode)) begin
          fault_q <= 1'b1;
          fault_code_o <= 8'h02;
          active_q <= 1'b0;
        end else if (head_valid &&
                    ((head_opcode == ISA_RESERVED_01) ||
                     (head_opcode == ISA_RESERVED_12))) begin
          fault_q <= 1'b1;
          fault_code_o <= 8'h03;
          active_q <= 1'b0;
        end else if (head_valid && (head_opcode == ISA_CFG_LOOP) &&
                    ((head_instr[37:33] != 5'b0) ||
                     (head_instr[21:17] != 5'b0))) begin
          fault_q <= 1'b1;
          fault_code_o <= 8'h04;
          active_q <= 1'b0;
        end else if (head_valid && head_requires_ctx && head_ctx_valid &&
                    context_has_illegal_encoding(head_ctx)) begin
          fault_q <= 1'b1;
          fault_code_o <= 8'h05;
          active_q <= 1'b0;
        end else if (head_valid && head_requires_ctx &&
                    ((head_opcode == ISA_EXEC_CONTEXT) ||
                     (head_opcode == ISA_EXEC_CORDIC) ||
                     (head_opcode == ISA_EXEC_SYNC)) &&
                    (head_instr[52:41] != 12'b0)) begin
          // Reclaimed generic-AGU indices are reserved and must encode zero.
          fault_q <= 1'b1;
          fault_code_o <= 8'h06;
          active_q <= 1'b0;
        end else if (head_valid && (head_opcode == ISA_EXEC_DMA_DIRECT) &&
                    ((head_instr[14:7] == 8'd0) ||
                     (head_instr[42:38] != 5'd0) ||
                     (head_instr[27:23] != 5'd0))) begin
          fault_q <= 1'b1;
          fault_code_o <= 8'h07;
          active_q <= 1'b0;
        end else if (barrier_waiting_q && barrier_release_i) begin
          barrier_waiting_q <= 1'b0;
          q_head_q <= '0;
          q_tail_q <= '0;
          q_count_q <= '0;
          q_ctx_valid_q <= '0;
          q_ctx_requested_q <= '0;
          ctx_req_valid_q <= 1'b0;
          if_req_valid_q <= ({1'b0, barrier_resume_pc_q} < program_words_i);
          if_req_pc_q <= barrier_resume_pc_q;
          fetch_pc_q <= {1'b0, barrier_resume_pc_q} + (P_PC_W+1)'(1);
        end else if (halt_seen_q) begin
          if (all_units_idle_i) begin
            active_q <= 1'b0;
            done_q <= 1'b1;
          end
        end else if (any_flush) begin
          q_head_q <= '0;
          q_tail_q <= '0;
          q_count_q <= '0;
          q_ctx_valid_q <= '0;
          q_ctx_requested_q <= '0;
          ctx_req_valid_q <= 1'b0;
          if_req_valid_q <= 1'b0;
          if (flush_redirect) begin
            if_req_valid_q <= ({1'b0, zol_redirect_pc} < program_words_i);
            if_req_pc_q <= zol_redirect_pc;
            fetch_pc_q <= {1'b0, zol_redirect_pc} + (P_PC_W+1)'(1);
          end else if (flush_barrier) begin
            barrier_waiting_q <= 1'b1;
            barrier_token_q <= head_instr[15:0];
            barrier_resume_pc_q <= issue_pc_o + P_PC_W'(1);
            fetch_pc_q <= {1'b0, issue_pc_o} + (P_PC_W+1)'(1);
          end else begin
            halt_seen_q <= 1'b1;
          end
        end else begin
          // Consume previous-cycle synchronous Instruction RAM response.
          case ({imem_rd_valid_i, normal_pop})
            2'b10: q_count_q <= q_count_q + 1'b1;
            2'b01: q_count_q <= q_count_q - 1'b1;
            default: q_count_q <= q_count_q;
          endcase
          if (normal_pop) begin
            q_ctx_valid_q[q_head_q] <= 1'b0;
            q_ctx_requested_q[q_head_q] <= 1'b0;
            q_head_q <= (q_head_q == P_Q_DEPTH-1) ? '0 : q_head_q + 1'b1;
          end
          if (imem_rd_valid_i) begin
            q_instr_q[q_tail_q] <= imem_rd_data_i;
            q_pc_q[q_tail_q] <= if_rsp_pc_q;
            q_ctx_valid_q[q_tail_q] <= 1'b0;
            q_ctx_requested_q[q_tail_q] <= 1'b0;
            q_tail_q <= (q_tail_q == P_Q_DEPTH-1) ? '0 : q_tail_q + 1'b1;
          end

          // Consume previous-cycle Context RAM response.
          if (ctx_rd_valid_i) begin
            q_ctx_q[ctx_rsp_slot_q] <= ctx_rd_data_i;
            q_ctx_valid_q[ctx_rsp_slot_q] <= 1'b1;
          end

          // Capture request metadata for the response returned next cycle.
          if (if_req_valid_q) if_rsp_pc_q <= if_req_pc_q;
          if (ctx_req_valid_q) ctx_rsp_slot_q <= ctx_req_slot_q;

          ctx_req_valid_q <= ctx_select_valid;
          if (ctx_select_valid) begin
            ctx_req_idx_q <= ctx_select_idx;
            ctx_req_slot_q <= ctx_select_slot;
            q_ctx_requested_q[ctx_select_slot] <= 1'b1;
          end

          if_req_valid_q <= launch_ifetch;
          if (launch_ifetch) begin
            if_req_pc_q <= launch_ifetch_pc;
            fetch_pc_q <= fetch_pc_q + (P_PC_W+1)'(1);
          end
        end
      end
    end
  end

endmodule
