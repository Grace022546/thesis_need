// =============================================================================
// context_entry_pkg.sv
// 94-bit Context RAM payload sub-field layout + supporting enums.
//
// SOURCE OF TRUTH: cgra_v4_no_tsu_paramrf_pingpong_full(1).py, class ContextRAMEntry
// (encode()/decode()), class PESlot, and the Op/Dir/CordicSrc/CordicDst/
// MicrocodeKind/DependencyKind enums.
//
// Bit layout (LSB-first, matches ContextRAMEntry.encode() shift order exactly):
//   [35:0]   4 x 9-bit PE slots (slot i occupies bits [9*i +: 9])
//   [39:36]  param_id            (4b)
//   [40]     cordic_en           (1b)
//   [44:41]  cordic_param_id     (4b)
//   [46:45]  cordic_src          (2b)
//   [48:47]  cordic_dst          (2b)
//   [51:49]  ctx_id              (3b)
//   [56:52]  kind (MicrocodeKind)(5b)
//   [59:57]  dependency          (3b)
//   [63:60]  flags               (4b)
//   [65:64]  round_mode          (2b)
//   [66]     saturation_enable   (1b)
//   [67]     accumulate_enable   (1b)
//   [70:68]  reserved_addrgen_bits(3b) -- final RTL: must be zero
//   [74:71]  dma_src_cluster     (4b)
//   [78:75]  dma_dst_cluster     (4b)
//   [86:79]  dma_len_vec         (8b)
//   [88:87]  dma_requester_pe    (2b)
//   [92:89]  dma_tag             (4b)
//   [93]     is_dma_context      (1b)
//   total: 94 bits
// =============================================================================

package context_entry_pkg;

  // ---------------------------------------------------------------------
  // Per-PE-slot op (3b) -- Op enum
  //   9-bit slot layout: [8:6] op, [5:3] upstream, [2:0] downstream
  // ---------------------------------------------------------------------
  typedef enum logic [2:0] {
    OP_NOP     = 3'd0,
    OP_PASS    = 3'd1,
    OP_MAC     = 3'd2,
    OP_CMUL    = 3'd3,
    OP_ADD     = 3'd4,
    OP_CVEC    = 3'd5,   // reserved legacy PE opcode; CVEC is now issued via cordic_en
    OP_CROT    = 3'd6,
    OP_RU_PACK = 3'd7
  } pe_op_e;

  // Dir enum -- PE-local mux source/destination (row/col highways excluded;
  // those land in MEM first)
  typedef enum logic [2:0] {
    DIR_MEM        = 3'd0,
    DIR_PE_LOCAL   = 3'd1,
    DIR_PE_RING    = 3'd2,
    DIR_PARAM_RF   = 3'd3,
    DIR_SCALE      = 3'd4,
    DIR_RESERVED   = 3'd5,  // illegal PE mux encoding
    DIR_ACC        = 3'd6,
    DIR_OPERAND_RF = 3'd7
  } pe_dir_e;

  typedef enum logic [1:0] {
    CORDIC_SRC_PE0_MEM = 2'd0,
    CORDIC_SRC_PE0_REG = 2'd1,
    CORDIC_SRC_PE_RING = 2'd2
  } cordic_src_e;

  typedef enum logic [1:0] {
    CORDIC_DST_PARAM_RF      = 2'd0,
    CORDIC_DST_PE_RING       = 2'd1,
    CORDIC_DST_PARAM_RF_RING = 2'd2
  } cordic_dst_e;

  typedef enum logic [2:0] {
    DEP_NONE   = 3'd0,
    DEP_RAW    = 3'd1,
    DEP_WAW    = 3'd2,
    DEP_PARAM  = 3'd3,
    DEP_LAYOUT = 3'd4
  } dependency_kind_e;

  // MicrocodeKind (5 bits, values 0..31). RESERVED_23 must never be produced
  // by the compiler and is illegal if encountered in final RTL (no generic
  // AGU datapath exists to service it).
  typedef enum logic [4:0] {
    MK_NONE               = 5'd0,
    MK_FFT_LOAD            = 5'd1,
    MK_FFT_BFLY             = 5'd2,
    MK_FFT_PACK             = 5'd3,
    MK_FIR_X_WINDOW         = 5'd4,
    MK_QR_LOAD              = 5'd5,
    MK_QR_CORDIC            = 5'd6,
    MK_QR_CROT              = 5'd7,
    MK_QR_PACK              = 5'd8,
    MK_FFT_PARAM_LOAD       = 5'd9,
    MK_FIR_AGU_START        = 5'd10,
    MK_FIR_H_VECTOR         = 5'd11,
    MK_FFT_SCATTER          = 5'd12,
    MK_QR_WRITEBACK         = 5'd13,
    MK_FIR_MAC              = 5'd14,
    MK_FIR_REDUCE           = 5'd15,
    MK_FIR_PACK             = 5'd16,
    MK_MM_A_LOAD            = 5'd17,
    MK_MM_A_LATCH           = 5'd18,
    MK_MM_B_LOAD            = 5'd19,
    MK_MM_MAC               = 5'd20,
    MK_MM_REDUCE            = 5'd21,
    MK_MM_PACK              = 5'd22,
    MK_RESERVED_23          = 5'd23,  // illegal: no generic AGU datapath
    MK_FFT_TWIDDLE_FILL     = 5'd24,  // deprecated centralized fill; illegal in V4
    MK_FFT_OPT_CACHE_SEED   = 5'd25,
    MK_FFT_OPT_CACHE_STEP   = 5'd26,
    MK_FFT_OPT_FUSED_BFLY   = 5'd27,
    MK_FFT_OPT_GROUP_COMMIT = 5'd28,
    MK_QR_TOKEN_ACQUIRE     = 5'd29,
    MK_QR_TOKEN_ROTATE      = 5'd30,
    MK_QR_TOKEN_FLUSH       = 5'd31
  } microcode_kind_e;

  // ---------------------------------------------------------------------
  // 94-bit Context RAM payload field offsets
  // ---------------------------------------------------------------------
  localparam int PE_SLOT_BITS = 9;
  localparam int CTX_PE_SLOTS_LO = 0;                                // 4 x 9b, [35:0]

  localparam int CTX_PARAM_ID_LO = 36, CTX_PARAM_ID_HI = 39;
  localparam int CTX_CORDIC_EN_BIT = 40;
  localparam int CTX_CORDIC_PARAM_ID_LO = 41, CTX_CORDIC_PARAM_ID_HI = 44;
  localparam int CTX_CORDIC_SRC_LO = 45, CTX_CORDIC_SRC_HI = 46;
  localparam int CTX_CORDIC_DST_LO = 47, CTX_CORDIC_DST_HI = 48;
  localparam int CTX_CTX_ID_LO = 49, CTX_CTX_ID_HI = 51;
  localparam int CTX_KIND_LO = 52, CTX_KIND_HI = 56;
  localparam int CTX_DEPENDENCY_LO = 57, CTX_DEPENDENCY_HI = 59;
  localparam int CTX_FLAGS_LO = 60, CTX_FLAGS_HI = 63;
  localparam int CTX_ROUND_MODE_LO = 64, CTX_ROUND_MODE_HI = 65;
  localparam int CTX_SATURATION_EN_BIT = 66;
  localparam int CTX_ACCUMULATE_EN_BIT = 67;
  localparam int CTX_RESERVED_ADDRGEN_LO = 68, CTX_RESERVED_ADDRGEN_HI = 70; // must be 0
  localparam int CTX_DMA_SRC_CLUSTER_LO = 71, CTX_DMA_SRC_CLUSTER_HI = 74;
  localparam int CTX_DMA_DST_CLUSTER_LO = 75, CTX_DMA_DST_CLUSTER_HI = 78;
  localparam int CTX_DMA_LEN_VEC_LO = 79, CTX_DMA_LEN_VEC_HI = 86;
  localparam int CTX_DMA_REQUESTER_PE_LO = 87, CTX_DMA_REQUESTER_PE_HI = 88;
  localparam int CTX_DMA_TAG_LO = 89, CTX_DMA_TAG_HI = 92;
  localparam int CTX_IS_DMA_CONTEXT_BIT = 93;

  localparam int CTX_TOTAL_BITS = 94;

endpackage : context_entry_pkg
